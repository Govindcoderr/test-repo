# AI OS Kernel — Platform Architecture & Contracts

This document describes how the **AI Kernel** layer works, what the backend sends and receives, and how future engines (Supervisor, Planning, Agent Runtime, Model, Knowledge, Memory, Tool) plug in.

**Audience:** Backend team, engine developers, platform architects.

---

## 1. Vision

The AI Kernel acts like an **operating system** for agentic AI:

- It is the **only hub** between the backend and all engines.
- Engines **never** talk to each other directly.
- The kernel contains **no business logic** (no RFQ analysis, no proposal writing).
- Business logic lives inside **engines**, registered by capability.

```text
┌─────────────┐         ┌──────────────────────────────────────┐         ┌─────────────┐
│   Backend   │ ──────► │           AI KERNEL (OS)             │ ──────► │   Engines   │
│  (API/App)  │ ◄────── │  route · context · policy · trace    │ ◄────── │ Supervisor  │
└─────────────┘         └──────────────────────────────────────┘         │ Planning    │
                                                                          │ Agent       │
                                                                          │ Model       │
                                                                          │ Knowledge   │
                                                                          │ Memory      │
                                                                          │ Tool        │
                                                                          └─────────────┘
```

Every request follows:

```text
Requester  →  KERNEL  →  Engine  →  KERNEL  →  Requester
```

---

## 2. What the Kernel Does (and Does Not Do)

### Kernel responsibilities

| Responsibility | Description |
|----------------|-------------|
| **Receive** | Accept `ExecutionRequest` from backend |
| **Context** | Create execution ID, session context, accumulate state |
| **Route** | Resolve capability/resource → engine via registries |
| **Dispatch** | Forward request to the selected engine |
| **Correlate** | Match engine response back to the original request |
| **Orchestrate** | Run optional phases (supervisor, planning, prep) based on flags |
| **Policy** | Authorization, timeouts, retries |
| **Trace** | Record every kernel ↔ engine exchange in `activityLogs` |
| **Respond** | Return structured `ExecutionResponse` to backend |

### Kernel does NOT

- Decide business workflows (that is Planning / Supervisor engines)
- Run LLM reasoning (Model / Agent engines)
- Query databases or CRM (Tool / Knowledge engines)
- Store long-term memory (Memory engine)

---

## 3. End-to-End Flow

### 3.1 High-level lifecycle

```text
1. Backend sends ExecutionRequest
2. Kernel creates ExecutionContext (executionId, session, agent, metadata)
3. [Optional] Supervisor Engine  → strategy back to kernel
4. [Optional] Planning Engine    → workflow/DAG back to kernel
5. [Optional] Prep phase         → Model / Knowledge / Memory engines
6. [Optional] Agent Runtime      → agent may request more capabilities via kernel
7. [Optional] Supervisor validation
8. Kernel returns ExecutionResponse to backend
```

### 3.2 Example: Sales Engineer RFQ (future full platform)

User asks: *"Analyze RFQ, compare projects, prepare proposal, generate PPT, email customer."*

To the user it is one request. Internally the kernel mediates many engine calls:

| Step | Who initiates | Kernel action | Engine |
|------|---------------|---------------|--------|
| 1 | Backend | Create context | — |
| 2 | Kernel (orchestration) | Call `supervisor.strategy` | Supervisor |
| 3 | Kernel | Call `planning.create_plan` | Planning |
| 4 | Kernel | Parallel prep | Model, Knowledge, Memory |
| 5 | Agent (via kernel) | `tool.execute` for CRM | Tool |
| 6 | Agent (via kernel) | `model.reason` for proposal | Model |
| 7 | Kernel | `memory.store` | Memory |
| 8 | Kernel | `supervisor.validate` | Supervisor |
| 9 | Kernel | Return final response | Backend |

The backend only sends **one** `ExecutionRequest`. The kernel decides **when** to call each engine based on orchestration flags and registered capabilities.

### 3.3 Engine call pattern (always the same)

```text
KERNEL                          ENGINE
   │  1. REQUEST_RECEIVED          │
   │  2. PROVIDER_RESOLVED          │
   │  3. ENGINE_DISPATCH  ────────► │
   │  4. ENGINE_RESPONSE  ◄──────── │
   │  5. CONTEXT_UPDATED            │
```

This pattern appears in `activityLogs` for every engine interaction.

---

## 4. API Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| `POST` | `/api/v1/kernel/execute` | Full execution (main backend integration) |
| `POST` | `/api/v1/kernel/dispatch` | Single engine call through kernel (testing / advanced) |
| `GET` | `/api/v1/kernel/registry` | List registered capabilities and resources |
| `GET` | `/api/v1/kernel/health` | Health check |
| — | `/docs` | OpenAPI / Swagger UI |

---

## 5. Input Contract — `ExecutionRequest`

**Direction:** Backend → Kernel  
**Model:** `ai_os/app/domain/models/execution.py`  
**Example:** `examples/demo_request.json`

### 5.1 Top-level fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `executionId` | string | No | Unique ID; kernel generates `EXE-*` if omitted |
| `sessionId` | string | Yes | Conversation / session identifier |
| `userId` | string | Yes | User who initiated the request |
| `tenantId` | string | No | Multi-tenant isolation |
| `parentExecutionId` | string | No | Parent execution for nested runs |
| `correlationId` | string | No | Cross-service tracing |
| `requestTimeStamp` | string (ISO) | No | When backend sent the request |
| `userQuery` | string | Yes | User's task or question |
| `attachments` | Attachment[] | No | Files (RFQ PDF, images, etc.) |
| `executionOptions` | object | No | Kernel orchestration flags |
| `metadata` | object | No | Business context |
| `agentDefinition` | object | No | Agent configuration |
| `runtimeConfiguration` | object | No | Runtime limits and behavior |

> **Note:** Legacy field name `agent` is still accepted and mapped to `agentDefinition`.

### 5.2 `executionOptions`

| Field | Default | Description |
|-------|---------|-------------|
| `enableSupervisor` | `true` | Call Supervisor Engine (strategy + validation) |
| `enablePlanning` | `true` | Call Planning Engine (workflow/DAG) |
| `enableKnowledge` | `true` | Retrieve knowledge during prep phase |
| `saveMemory` | `true` | Retrieve/store session memory |
| `enableAgent` | `false` | Invoke Agent Runtime engine |
| `debugMode` | `false` | Verbose tracing |

**Current default mode:** Kernel OS (`enableAgent: false`) — orchestration only, no agent layer.

### 5.3 `metadata`

| Field | Description |
|-------|-------------|
| `department` | e.g. Sales |
| `customer` | e.g. ABC Industries |
| `priority` | e.g. HIGH |
| `region` | Geographic region |
| `businessUnit` | Business unit |
| `project` | Project identifier |
| `customAttribute` | Arbitrary key-value map |

### 5.4 `attachments[]`

| Field | Description |
|-------|-------------|
| `fileId` | File identifier |
| `fileName` | Display name |
| `mimeType` | MIME type |
| `storagePath` | Storage location |
| `size` | Size in bytes |
| `attachmentType` | e.g. RFQ, image |
| `documentId` | Linked document ID |

### 5.5 `agentDefinition`

| Field | Description |
|-------|-------------|
| `agentId` | Unique agent ID |
| `name` | Agent display name |
| `version` | Agent version |
| `description` | What the agent does |
| `responsibility` | Scope of responsibility |
| `memoryPolicy` | Memory behavior `{ enabled }` |
| `modelConfiguration` | LLM settings (see below) |
| `permissions` | Access control arrays |
| `knowledgeSources` | Allowed knowledge sources |
| `allowedTools` | Tools the agent may use |
| `subAgents` | Sub-agent definitions |
| `metadata` | Extra agent metadata |

### 5.6 `modelConfiguration` (inside agentDefinition)

| Field | Description |
|-------|-------------|
| `provider` | e.g. openai |
| `modelName` | Model identifier |
| `temperature` | Sampling temperature |
| `maxTokens` | Token limit |
| `streaming` | Enable streaming |
| `reasoningNode` | Reasoning mode |
| `retry` | Retry count |
| `apiKey` | API key (prefer secret reference in production) |
| `isInternal` | When `true`, ALWAYS routes to the in-house model gateway regardless of `provider` — see `infrastructure/engines/Model/providers/internal_provider.py`. `apiKey` is optional here (forwarded as a bearer token if set); `modelName` tells the gateway which internal model to run |
| `baseUrl` | Overridable endpoint (Azure OpenAI, self-hosted/BYOM); omit for provider default. For `isInternal=true`, this is the full completion endpoint URL — falls back to `INTERNAL_MODEL_BASE_URL` if omitted |
| `timeout` | Request timeout (seconds) |
| `responseFormat` | e.g. text, json |

### 5.7 `permissions[]` (inside agentDefinition)

| Field | Description |
|-------|-------------|
| `databasePermission` | Database access rules |
| `toolPermission` | Tool access rules |
| `knowledgePermission` | Knowledge access rules |
| `memoryPermission` | Memory access rules |
| `modelPermission` | Model access rules |

### 5.8 `subAgents[]`

Same structure as agent (without nested subAgents): `subAgentId`, `name`, `version`, `description`, `responsibility`, `memoryPolicy`, `modelConfiguration`, `permissions`, `knowledgeSources`, `allowedTools`, `metadata`.

### 5.9 `runtimeConfiguration`

| Field | Default | Description |
|-------|---------|-------------|
| `maxExecutionTime` | — | Max execution time (seconds) |
| `maxParallelAgents` | 3 | Parallel agent limit |
| `checkpointsEnabled` | false | Workflow checkpoints |
| `autoRetry` | true | Auto-retry failed steps |
| `streamingEnabled` | false | Stream responses |
| `debugMode` | false | Debug mode |
| `humanApprovalRequired` | false | Require human approval |
| `notificationEnabled` | false | Send notifications |

### 5.10 Sample request

See `examples/demo_request.json` for a complete JSON example.

---

## 6. Output Contract — `ExecutionResponse`

**Direction:** Kernel → Backend  
**Model:** `ai_os/app/domain/models/kernel_output.py`

### 6.1 Top-level fields

| Field | Type | Description |
|-------|------|-------------|
| `executionId` | string | Execution identifier |
| `sessionId` | string | Session reference |
| `status` | string | `COMPLETED`, `FAILED`, etc. |
| `startedOn` | string (ISO) | Start timestamp |
| `completedOn` | string (ISO) | End timestamp |
| `finalResponse` | any | Final result for the backend |
| `artifacts` | Artifact[] | Generated files/documents |
| `agent` | AgentResponse | Agent execution details |
| `activityLogs` | ActivityLog[] | Kernel ↔ engine routing trace |
| `warnings` | string[] | Non-critical issues |
| `errors` | object[] | Error details if failed |
| `executionMetrics` | object | Timing, tokens, costs |
| `executionState` | string | Final kernel state machine value |

### 6.2 `activityLogs[]` — proof of kernel routing

| Field | Description |
|-------|-------------|
| `timeStamp` | When the action occurred |
| `engine` | Engine involved (null for kernel-only steps) |
| `action` | e.g. `ENGINE_DISPATCH`, `ENGINE_RESPONSE`, `PROVIDER_RESOLVED` |
| `status` | SUCCESS / FAILURE |
| `duration` | Duration in ms (if available) |
| `message` | Human-readable description |

**Validate kernel OS behavior:** every engine call should show `PROVIDER_RESOLVED` → `ENGINE_DISPATCH` → `ENGINE_RESPONSE` in `activityLogs`.

### 6.3 `agent` (AgentResponse)

| Field | Description |
|-------|-------------|
| `agentId` | Agent identifier |
| `agentName` | Agent name |
| `status` | Agent execution status |
| `executionTime` | Duration (ms) |
| `response` | Agent's final output |
| `executionSummary` | High-level summary (see below) |
| `executionMetrics` | Per-agent metrics |
| `modelLogs` | LLM call telemetry |
| `toolLogs` | Tool execution telemetry |
| `memoryLogs` | Memory engine interactions |
| `knowledgeLogs` | Knowledge retrieval telemetry |
| `subAgents` | Sub-agent results |

### 6.4 `executionSummary[]`

| Field | Description |
|-------|-------------|
| `goal` | Business goal / user query |
| `workflowName` | Workflow name from planning |
| `executionType` | KERNEL or AGENT |
| `status` | Summary status |
| `toolTasks` / `completedTasks` / `failedTasks` / `skippedTasks` | Task counts |
| `totalAgents` / `totalSubAgents` | Agent counts |
| `totalToolsUsed` / `totalModelsUsed` | Usage counts |
| `executionDuration` | Total duration (ms) |
| `startedOn` / `completedOn` | Timestamps |
| `completedReason` | Why execution ended |
| `finalMessage` | Final message text |

### 6.5 `executionMetrics`

| Field | Description |
|-------|-------------|
| `executionTime` | Total execution time (ms) |
| `planningTime` | Planning engine time |
| `modelTime` | Model engine time |
| `knowledgeTime` | Knowledge engine time |
| `memoryTime` | Memory engine time |
| `toolTime` | Tool engine time |
| `totalTokens` | Aggregated token count |
| `totalCost` | Estimated cost |
| `totalToolCalls` | Number of tool invocations |
| `totalModelCalls` | Number of model invocations |

### 6.6 Log types inside `agent`

**modelLogs:** `provider`, `model`, `promptTokens`, `completionTokens`, `latency`, `cost`, `retryCount`, `finishReason`

**toolLogs:** `toolName`, `action`, `inputSummary`, `outputSummary`, `status`, `duration`, `retryCount`

**memoryLogs:** `operation`, `memoryType`, `source`, `status`, `recordsRetrieved`, `recordsStored`, `duration`, `summary`

**knowledgeLogs:** `knowledgeSource`, `query`, `documentRetrieved`, `chunksRetrieved`, `averageScore`, `status`, `duration`

### 6.7 `artifacts[]`

| Field | Description |
|-------|-------------|
| `artifactId` | Unique artifact ID |
| `artifactType` | e.g. document, pptx |
| `name` | Display name |
| `location` | Storage path or URL |
| `createdBy` | Creator (agent or engine) |
| `createdOn` | Creation timestamp |
| `version` | Version string |

---

## 7. How Engine Registration Works

Engines plug in via **capabilities** and **resources**, not by modifying kernel code.

### 7.1 Capability-based routing

| Capability | Typical engine |
|------------|----------------|
| `supervisor.strategy` | Supervisor Engine |
| `supervisor.validate` | Supervisor Engine |
| `planning.create_plan` | Planning Engine |
| `agent.execute` | Agent Runtime |
| `model.create_client` | Model Engine — creates a standardized ILLMClient from a ModelConfiguration; does not perform inference itself. Supported providers: `openai`, `anthropic`, `gemini` (see `infrastructure/engines/Model/provider_registry.py`) |
| `model.validate_configuration` | Model Engine |
| `knowledge.retrieve` | Knowledge Engine |
| `memory.retrieve` | Memory Engine |
| `memory.store` | Memory Engine |
| `tool.execute` | Tool Engine |

### 7.2 Adding a new engine (future)

1. Implement the engine interface (`execute(request) → response`).
2. Define an **engine manifest** with `engineId`, `capabilities`, `resources`.
3. Register via `PluginLoader` at bootstrap.
4. Kernel automatically routes matching requests — **no kernel changes**.

```python
plugin_loader.load_engine(my_supervisor_engine)
engine_gateway.register_engine("supervisor-engine", my_supervisor_engine)
```

### 7.3 Registry inspection

```http
GET /api/v1/kernel/registry
```

Returns all capabilities and resources the kernel can route to.

---

## 8. Project Structure

```text
ai_os/app/
├── api/                    # FastAPI routes, dependency injection
│   └── routes/kernel_routes.py
├── kernel/                 # OS layer (routing, orchestration, policy)
│   ├── kernel.py           # Main orchestrator
│   ├── registry/           # Capability & resource registries
│   ├── routing/            # Dispatch, resolvers
│   ├── orchestration/      # Supervisor/planning prep pipeline
│   ├── requests/           # Correlation, join, continuation
│   └── response/           # ExecutionResponse builder
├── domain/
│   ├── models/             # ExecutionRequest, ExecutionResponse, etc.
│   └── interfaces/         # Engine, gateway, repository contracts
├── infrastructure/
│   └── engines/            # Mock/generic engine implementations (today)
└── config/                 # Settings
```

---

## 9. Running & Validating

### 9.1 Setup

```powershell
cd ASMA-AI-Agent-Service
pip install -r requirements.txt
$env:PYTHONPATH="."
uvicorn ai_os.app.main:app --reload
```

OpenAPI: http://localhost:8000/docs

### 9.2 Automated tests

```powershell
.\venv\Scripts\python.exe -m pytest tests/ -v
```

16 tests cover registration, routing, orchestration, and end-to-end flows.

### 9.3 Trace demo (visual proof of routing)

```powershell
$env:PYTHONPATH="."
.\venv\Scripts\python.exe scripts\trace_demo.py
```

Uses `examples/demo_request.json`. Inspect `activityLogs` for kernel ↔ engine hops.

### 9.4 Kernel-only demo (no agent)

```powershell
$env:PYTHONPATH="."
.\venv\Scripts\python.exe scripts\kernel_os_demo.py
```

Uses `examples/rfq_kernel_os_flow.json`. Output saved to `examples/last_kernel_os_response.json`.

### 9.5 HTTP execute

```powershell
curl -X POST http://localhost:8000/api/v1/kernel/execute `
  -H "Content-Type: application/json" `
  -d "@examples/demo_request.json"
```

### 9.6 Single engine dispatch (isolated test)

```json
POST /api/v1/kernel/dispatch
{
  "sessionId": "SESSION-TEST",
  "userId": "USER-TEST",
  "dispatch": {
    "stepId": "test-knowledge",
    "requestType": "CAPABILITY_REQUEST",
    "capability": "knowledge.retrieve",
    "payload": { "query": "test lookup" }
  }
}
```

### 9.7 Validation checklist

| Check | Pass criteria |
|-------|---------------|
| Tests pass | `pytest` — 16/16 green |
| Registry populated | `GET /registry` lists capabilities |
| Kernel dispatches | `activityLogs` contain `ENGINE_DISPATCH` |
| Engine responds | `activityLogs` contain `ENGINE_RESPONSE` |
| No direct engine-to-engine | Every engine step sandwiched by kernel actions |
| Response structure | `executionId`, `status`, `agent`, `executionMetrics` present |

---

## 10. Current State vs Future Roadmap

### Implemented today (kernel OS layer)

- ExecutionRequest / ExecutionResponse contracts
- Capability & resource registries
- Request dispatch, correlation, parent/child tracking
- Orchestration pipeline (supervisor, planning, knowledge/memory prep)
- Agent request loop (`enableAgent: true`)
- Activity logging and execution metrics
- Mock/generic engines for development and testing

### Future engines (plug in via registry)

| Engine | Role |
|--------|------|
| **Supervisor** | Strategy, complexity, validation |
| **Planning** | Workflow DAG, parallel tasks |
| **Agent Runtime** | Worker reasoning, tool requests |
| **Model** | Creates/validates/manages LLM clients (ILLMClient) — inference itself is performed by whoever holds the client, not the Model engine |
| **Knowledge** | RAG, document retrieval |
| **Memory** | Session and long-term memory |
| **Tool** | CRM, email, shell, APIs |

When real engines are added, the kernel contract stays the same. Only engine implementations change.

---

## 11. Key Design Principles

1. **Kernel = OS bridge** — all communication goes through it.
2. **Backend sends context, not engine names** — kernel resolves engines by capability.
3. **Registries, not hardcoding** — new engines register capabilities; kernel routes dynamically.
4. **Separation of concerns** — kernel routes; engines execute business logic.
5. **Observable by design** — `activityLogs` prove every routing decision.
6. **Incremental delivery** — ship kernel first, add engines one at a time.

---

## 12. Reference Files

| File | Purpose |
|------|---------|
| `examples/demo_request.json` | Full ExecutionRequest sample |
| `examples/rfq_kernel_os_flow.json` | RFQ scenario (kernel-only, no agent) |
| `examples/last_kernel_os_response.json` | Sample ExecutionResponse output |
| `ai_os/app/domain/models/execution.py` | ExecutionRequest model |
| `ai_os/app/domain/models/kernel_output.py` | ExecutionResponse model |
| `tests/test_kernel.py` | Automated validation |

---

*Document version: aligned with kernel OS layer as of project baseline. Update this file when contracts or orchestration behavior changes.*
