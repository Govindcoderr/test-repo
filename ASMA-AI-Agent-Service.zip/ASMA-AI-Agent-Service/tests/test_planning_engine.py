"""Tests for the Planning engine, focused on its human-in-the-loop path.

Uses a fake ILLMClient (no real network/API calls) so these tests exercise
PlanningEngine's own logic — clarification detection, workflow build, the
resumed-call clarification-context handling — independent of any provider.
"""

import json

import pytest

from ai_os.app.domain.interfaces.llm_client import ILLMClient
from ai_os.app.domain.models.kernel_request import KernelRequest, RequestSource, RequestType
from ai_os.app.domain.models.llm_request import LLMRequest
from ai_os.app.domain.models.llm_response import LLMResponse
from ai_os.app.infrastructure.engines.Planning.planning_engine import PlanningEngine


class FakePlanningLLMClient(ILLMClient):
    """Returns a pre-set JSON payload as the LLM's response.content."""

    def __init__(self, responses: list[dict]) -> None:
        # One dict consumed per call, in order.
        self._responses = list(responses)
        self.calls: list[LLMRequest] = []

    async def generate(self, request: LLMRequest) -> LLMResponse:
        self.calls.append(request)
        payload = self._responses.pop(0)
        return LLMResponse(content=json.dumps(payload), metadata={"provider": "fake", "model": "fake-model"})

    async def stream(self, request):
        raise NotImplementedError

    async def structured_output(self, request, schema):
        return await self.generate(request)

    async def health(self) -> bool:
        return True


def make_request(payload: dict) -> KernelRequest:
    return KernelRequest(
        requestId="REQ-1",
        executionId="EXE-1",
        correlationId="COR-1",
        sessionId="SESSION-1",
        source=RequestSource(type="test", id="test"),
        requestType=RequestType.CAPABILITY_REQUEST,
        capability="planning.create_plan",
        payload=payload,
    )


NORMAL_PLAN_RESPONSE = {
    "tasks": [
        {"taskId": "task-1", "description": "do the first thing", "dependsOn": []},
        {"taskId": "task-2", "description": "do the second thing", "dependsOn": ["task-1"]},
    ],
    "planningRationale": "linear chain",
    "needsClarification": False,
    "clarificationQuestion": "",
}

CLARIFICATION_RESPONSE = {
    "tasks": [],
    "planningRationale": "",
    "needsClarification": True,
    "clarificationQuestion": "Who is the recipient of this email?",
}


@pytest.mark.asyncio
async def test_normal_plan_produces_workflow_and_next_step():
    llm = FakePlanningLLMClient([NORMAL_PLAN_RESPONSE])
    engine = PlanningEngine(llm_client=llm)

    request = make_request({"userQuery": "send a summary email"})
    response = await engine.execute(request)

    assert response.status.value == "SUCCESS"
    assert "humanInputRequired" not in (response.result or {})
    assert response.result["workflow"]["taskCount"] == 2
    assert response.next_step is not None
    assert response.next_step.capability == "supervisor.validate_result"


@pytest.mark.asyncio
async def test_needs_clarification_raises_human_input_signal_not_next_step():
    llm = FakePlanningLLMClient([CLARIFICATION_RESPONSE])
    engine = PlanningEngine(llm_client=llm)

    request = make_request({"userQuery": "send a summary email to the team"})
    response = await engine.execute(request)

    assert response.status.value == "SUCCESS"
    assert response.next_step is None  # no next_step — kernel suspends instead
    signal = response.result["humanInputRequired"]
    assert signal["question"] == "Who is the recipient of this email?"
    assert signal["taskId"] is None
    # workflow must NOT be present — no valid task list was produced
    assert "workflow" not in response.result


@pytest.mark.asyncio
async def test_resumed_call_with_answer_folds_context_into_prompt_and_completes():
    llm = FakePlanningLLMClient([NORMAL_PLAN_RESPONSE])
    engine = PlanningEngine(llm_client=llm)

    # Simulates the kernel's re-dispatch after AIKernel._await_human_input
    # resolves — same capability, payload now carries the answer.
    request = make_request(
        {
            "userQuery": "send a summary email to the team",
            "humanInputAnswer": {"recipient": "finance@example.com"},
            "humanInputQuestion": "Who is the recipient of this email?",
        }
    )
    response = await engine.execute(request)

    assert response.status.value == "SUCCESS"
    assert "humanInputRequired" not in (response.result or {})
    assert response.result["workflow"]["taskCount"] == 2

    # The clarification context must have actually been folded into the
    # prompt sent to the LLM.
    sent_prompt = llm.calls[0].messages[-1].content
    assert "Who is the recipient of this email?" in sent_prompt
    assert "finance@example.com" in sent_prompt

    # Resumed calls are recorded as a "system" turn, not "human" — the
    # user's own query was already recorded on the original dispatch.
    turn = response.result["conversationTurn"]
    assert "system" in turn
    assert "Resuming Planning after clarification" in turn["system"]


@pytest.mark.asyncio
async def test_resumed_call_after_timeout_folds_timeout_note_into_prompt():
    llm = FakePlanningLLMClient([NORMAL_PLAN_RESPONSE])
    engine = PlanningEngine(llm_client=llm)

    request = make_request(
        {
            "userQuery": "send a summary email to the team",
            "humanInputTimedOut": True,
            "humanInputQuestion": "Who is the recipient of this email?",
        }
    )
    response = await engine.execute(request)

    assert response.status.value == "SUCCESS"
    assert "humanInputRequired" not in (response.result or {})

    sent_prompt = llm.calls[0].messages[-1].content
    assert "No answer was received in time" in sent_prompt
    assert "Who is the recipient of this email?" in sent_prompt


@pytest.mark.asyncio
async def test_fresh_call_has_no_clarification_context_in_prompt():
    llm = FakePlanningLLMClient([NORMAL_PLAN_RESPONSE])
    engine = PlanningEngine(llm_client=llm)

    request = make_request({"userQuery": "send a summary email"})
    await engine.execute(request)

    sent_prompt = llm.calls[0].messages[-1].content
    # The template's own placeholder text for "no clarification round-trip"
    assert "none" in sent_prompt.lower()
    assert "Follow-up note" not in sent_prompt
