"""Tests for the internal (self-hosted) model provider adapter and the
isInternal routing precedence in ProviderRegistry.

Mirrors tests/test_model_engine.py's approach: no real network calls,
httpx calls are mocked, and the adapter is checked against the same
normalization/error-mapping contract every provider must satisfy.
"""

import httpx
import pytest

from ai_os.app.domain.interfaces.llm_errors import LLMPermanentError, LLMTransientError
from ai_os.app.domain.models.llm_request import LLMRequest
from ai_os.app.domain.models.llm_response import TokenUsage
from ai_os.app.domain.models.model_configuration import ModelConfiguration
from ai_os.app.infrastructure.engines.Model.client_factory import ClientFactory
from ai_os.app.infrastructure.engines.Model.exceptions import InvalidConfigurationError
from ai_os.app.infrastructure.engines.Model.provider_registry import ProviderRegistry
from ai_os.app.infrastructure.engines.Model.providers.internal_provider import (
    InternalClient,
    InternalProviderFactory,
)
from ai_os.app.infrastructure.engines.Model.providers.openai_provider import OpenAIProviderFactory
from ai_os.app.infrastructure.engines.Model.resilient_client import ResilientLLMClient
from ai_os.app.infrastructure.engines.Model.validators import validate_configuration


# ─── isInternal routing precedence ─────────────────────────────────────────


@pytest.mark.parametrize("provider", ["openai", "anthropic", "gemini", "totally-made-up"])
def test_is_internal_always_wins_over_provider_field(provider):
    """isInternal=true must route to InternalProviderFactory regardless of

    `provider` — including a provider name that isn't even registered,
    since InternalProviderFactory doesn't consult PROVIDER_FACTORIES at
    all.
    """
    registry = ProviderRegistry()
    config = ModelConfiguration(provider=provider, modelName="x", isInternal=True, baseUrl="http://internal.local/chat")
    factory = registry.resolve(config)
    assert isinstance(factory, InternalProviderFactory)


def test_is_internal_false_uses_provider_field():
    registry = ProviderRegistry()
    config = ModelConfiguration(provider="openai", modelName="x", isInternal=False, apiKey="sk-test")
    factory = registry.resolve(config)
    assert isinstance(factory, OpenAIProviderFactory)


def test_client_factory_builds_internal_client_regardless_of_provider():
    factory = ClientFactory()
    config = ModelConfiguration(
        provider="openai",  # deliberately mismatched — must be ignored
        modelName="my-custom-llama",
        isInternal=True,
        baseUrl="http://10.10.20.30/api/chat",
    )
    client = factory.create_client(config)
    assert isinstance(client, ResilientLLMClient)
    assert isinstance(client._primary, InternalClient)


# ─── Validation ─────────────────────────────────────────────────────────────


def test_internal_validate_does_not_require_api_key():
    registry = ProviderRegistry()
    config = ModelConfiguration(provider="openai", modelName="x", isInternal=True, baseUrl="http://internal.local/chat")
    validate_configuration(config, registry)  # should not raise


def test_internal_validate_requires_model_name():
    registry = ProviderRegistry()
    config = ModelConfiguration(modelName="", isInternal=True, baseUrl="http://internal.local/chat")
    with pytest.raises(InvalidConfigurationError):
        validate_configuration(config, registry)


def test_internal_validate_requires_base_url_when_no_default_configured(monkeypatch):
    from ai_os.app.config import settings as settings_module

    monkeypatch.setattr(settings_module.get_settings(), "internal_model_base_url", "")
    registry = ProviderRegistry()
    config = ModelConfiguration(modelName="x", isInternal=True)  # no baseUrl on the config either
    with pytest.raises(InvalidConfigurationError):
        validate_configuration(config, registry)


def test_internal_validate_uses_default_base_url_when_config_omits_it(monkeypatch):
    from ai_os.app.config import settings as settings_module

    monkeypatch.setattr(settings_module.get_settings(), "internal_model_base_url", "http://default-internal.local/chat")
    registry = ProviderRegistry()
    config = ModelConfiguration(modelName="x", isInternal=True)  # relies on the default
    validate_configuration(config, registry)  # should not raise


# ─── InternalClient: request/response normalization ────────────────────────


@pytest.mark.asyncio
async def test_internal_client_generate_normalizes_response(monkeypatch):
    client = InternalClient(base_url="http://internal.local/chat", model="llama-70b-internal")

    async def _fake_post(url, json):
        assert url == "http://internal.local/chat"
        assert json["model"] == "llama-70b-internal"
        assert json["messages"] == [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "user"},
        ]
        return httpx.Response(
            200,
            json={
                "content": "hello from internal model",
                "finishReason": "stop",
                "usage": {"promptTokens": 12, "completionTokens": 6, "totalTokens": 18},
            },
            request=httpx.Request("POST", url),
        )

    monkeypatch.setattr(client._http_client, "post", _fake_post)

    response = await client.generate(LLMRequest.from_system_user("sys", "user"))

    assert response.content == "hello from internal model"
    assert response.finish_reason == "stop"
    assert response.usage == TokenUsage(promptTokens=12, completionTokens=6, totalTokens=18)
    assert response.latency_ms is not None
    # Self-hosted inference is left unpriced (never a false $0.00).
    assert response.cost is None


@pytest.mark.asyncio
async def test_internal_client_forwards_api_key_as_bearer_token():
    client = InternalClient(base_url="http://internal.local/chat", model="x", api_key="secret-token")
    assert client._http_client.headers["authorization"] == "Bearer secret-token"


@pytest.mark.asyncio
async def test_internal_client_no_api_key_sends_no_auth_header():
    client = InternalClient(base_url="http://internal.local/chat", model="x")
    assert "authorization" not in client._http_client.headers


@pytest.mark.asyncio
async def test_internal_client_maps_4xx_to_permanent(monkeypatch):
    client = InternalClient(base_url="http://internal.local/chat", model="x")

    async def _fake_post(url, json):
        return httpx.Response(400, json={"error": "bad request"}, request=httpx.Request("POST", url))

    monkeypatch.setattr(client._http_client, "post", _fake_post)

    with pytest.raises(LLMPermanentError):
        await client.generate(LLMRequest.from_system_user("s", "u"))


@pytest.mark.asyncio
async def test_internal_client_maps_429_and_5xx_to_transient(monkeypatch):
    client = InternalClient(base_url="http://internal.local/chat", model="x")

    for status in (429, 500, 503):
        async def _fake_post(url, json, _status=status):
            return httpx.Response(_status, json={"error": "unavailable"}, request=httpx.Request("POST", url))

        monkeypatch.setattr(client._http_client, "post", _fake_post)
        with pytest.raises(LLMTransientError):
            await client.generate(LLMRequest.from_system_user("s", "u"))


@pytest.mark.asyncio
async def test_internal_client_maps_connection_error_to_transient(monkeypatch):
    client = InternalClient(base_url="http://internal.local/chat", model="x")

    async def _fake_post(url, json):
        raise httpx.ConnectError("connection refused")

    monkeypatch.setattr(client._http_client, "post", _fake_post)

    with pytest.raises(LLMTransientError):
        await client.generate(LLMRequest.from_system_user("s", "u"))


@pytest.mark.asyncio
async def test_internal_client_stream_not_implemented():
    client = InternalClient(base_url="http://internal.local/chat", model="x")
    with pytest.raises(NotImplementedError):
        async for _ in client.stream(LLMRequest.from_system_user("s", "u")):
            pass


@pytest.mark.asyncio
async def test_internal_client_malformed_response_is_permanent_error(monkeypatch):
    client = InternalClient(base_url="http://internal.local/chat", model="x")

    async def _fake_post(url, json):
        return httpx.Response(200, json={"unexpected": "shape"}, request=httpx.Request("POST", url))

    monkeypatch.setattr(client._http_client, "post", _fake_post)

    with pytest.raises(LLMPermanentError):
        await client.generate(LLMRequest.from_system_user("s", "u"))


# ─── Resilience still applies (timeout/retry/fallback are provider-agnostic) ─


@pytest.mark.asyncio
async def test_internal_client_wrapped_in_resilient_client_retries_transient(monkeypatch):
    config = ModelConfiguration(modelName="x", isInternal=True, baseUrl="http://internal.local/chat", retry=1)
    factory = ClientFactory()
    client = factory.create_client(config)

    call_count = {"n": 0}

    async def _fake_post(url, json):
        call_count["n"] += 1
        if call_count["n"] == 1:
            return httpx.Response(503, json={"error": "busy"}, request=httpx.Request("POST", url))
        return httpx.Response(
            200,
            json={"content": "ok", "usage": {"promptTokens": 1, "completionTokens": 1, "totalTokens": 2}},
            request=httpx.Request("POST", url),
        )

    monkeypatch.setattr(client._primary._http_client, "post", _fake_post)

    response = await client.generate(LLMRequest.from_system_user("s", "u"))

    assert response.content == "ok"
    assert call_count["n"] == 2
