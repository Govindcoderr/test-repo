"""Tests for the Anthropic and Gemini provider adapters.

Mirrors tests/test_model_engine.py's approach for OpenAI: no real network
calls, SDK calls are mocked/faked, and each adapter is checked against the
same normalization/error-mapping/streaming/cost contract every provider
must satisfy.
"""

from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from anthropic.types import Message, Usage

from ai_os.app.domain.interfaces.llm_errors import LLMPermanentError, LLMTransientError
from ai_os.app.domain.models.llm_request import LLMRequest
from ai_os.app.domain.models.llm_response import LLMResponse, TokenUsage
from ai_os.app.domain.models.model_configuration import ModelConfiguration
from ai_os.app.infrastructure.engines.Model.client_factory import ClientFactory
from ai_os.app.infrastructure.engines.Model.exceptions import InvalidConfigurationError
from ai_os.app.infrastructure.engines.Model.pricing import estimate_cost
from ai_os.app.infrastructure.engines.Model.provider_registry import ProviderRegistry
from ai_os.app.infrastructure.engines.Model.providers.anthropic_provider import (
    AnthropicClient,
    AnthropicProviderFactory,
)
from ai_os.app.infrastructure.engines.Model.providers.gemini_provider import (
    GeminiClient,
    GeminiProviderFactory,
)
from ai_os.app.infrastructure.engines.Model.resilient_client import ResilientLLMClient
from ai_os.app.infrastructure.engines.Model.validators import validate_configuration


# ─── Provider registry: both new providers are registered ─────────────────


def test_registry_includes_anthropic_and_gemini():
    registry = ProviderRegistry()
    assert registry.is_supported("anthropic")
    assert registry.is_supported("gemini")
    assert isinstance(registry.get("anthropic"), AnthropicProviderFactory)
    assert isinstance(registry.get("gemini"), GeminiProviderFactory)
    assert set(registry.list_supported()) == {"openai", "anthropic", "gemini"}


@pytest.mark.parametrize("provider", ["anthropic", "gemini"])
def test_validators_reject_missing_api_key(provider):
    registry = ProviderRegistry()
    config = ModelConfiguration(provider=provider, modelName="some-model")
    with pytest.raises(InvalidConfigurationError):
        validate_configuration(config, registry)


@pytest.mark.parametrize("provider", ["anthropic", "gemini"])
def test_client_factory_builds_resilient_wrapped_client(provider):
    factory = ClientFactory()
    config = ModelConfiguration(provider=provider, modelName="x", apiKey="fake-key")
    client = factory.create_client(config)
    assert isinstance(client, ResilientLLMClient)


# ─── Anthropic adapter ──────────────────────────────────────────────────────


def _make_anthropic_message(text="hello", input_tokens=10, output_tokens=5, model="claude-3-5-sonnet-20241022"):
    return Message.model_construct(
        id="msg_1",
        content=[SimpleNamespace(type="text", text=text)],
        model=model,
        role="assistant",
        stop_reason="end_turn",
        stop_sequence=None,
        type="message",
        usage=Usage.model_construct(input_tokens=input_tokens, output_tokens=output_tokens),
    )


@pytest.mark.asyncio
async def test_anthropic_client_generate_normalizes_response(monkeypatch):
    client = AnthropicClient(api_key="sk-ant-test", model="claude-3-5-sonnet-20241022")
    mock_create = AsyncMock(return_value=_make_anthropic_message("hi there"))
    monkeypatch.setattr(client._sdk_client.messages, "create", mock_create)

    response = await client.generate(LLMRequest.from_system_user("sys", "user"))

    assert isinstance(response, LLMResponse)
    assert response.content == "hi there"
    assert response.finish_reason == "end_turn"
    assert response.usage == TokenUsage(promptTokens=10, completionTokens=5, totalTokens=15)
    assert response.latency_ms is not None
    assert response.cost == estimate_cost("anthropic", "claude-3-5-sonnet-20241022", response.usage)
    assert response.cost is not None

    # System message must be split out of `messages` into Anthropic's
    # separate `system` param, not sent as a role="system" message.
    _, kwargs = mock_create.call_args
    assert kwargs["system"] == "sys"
    assert all(m["role"] != "system" for m in kwargs["messages"])


@pytest.mark.asyncio
async def test_anthropic_client_maps_permanent_and_transient_errors(monkeypatch):
    import httpx
    from anthropic import AuthenticationError, RateLimitError

    client = AnthropicClient(api_key="bad", model="claude-3-5-sonnet-20241022")
    fake_response = httpx.Response(status_code=401, request=httpx.Request("POST", "https://api.anthropic.com"))

    monkeypatch.setattr(
        client._sdk_client.messages,
        "create",
        AsyncMock(side_effect=AuthenticationError(message="bad key", response=fake_response, body=None)),
    )
    with pytest.raises(LLMPermanentError):
        await client.generate(LLMRequest.from_system_user("s", "u"))

    fake_response_429 = httpx.Response(status_code=429, request=httpx.Request("POST", "https://api.anthropic.com"))
    monkeypatch.setattr(
        client._sdk_client.messages,
        "create",
        AsyncMock(side_effect=RateLimitError(message="rate limited", response=fake_response_429, body=None)),
    )
    with pytest.raises(LLMTransientError):
        await client.generate(LLMRequest.from_system_user("s", "u"))


class _FakeAnthropicStream:
    """Minimal async-context-manager stand-in for AsyncMessageStreamManager."""

    def __init__(self, events, final_message):
        self._events = events
        self._final_message = final_message

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc_info):
        return False

    def __aiter__(self):
        return self._iter()

    async def _iter(self):
        for event in self._events:
            yield event

    async def get_final_message(self):
        return self._final_message


@pytest.mark.asyncio
async def test_anthropic_client_stream_yields_deltas_then_final_usage(monkeypatch):
    client = AnthropicClient(api_key="sk-ant-test", model="claude-3-5-sonnet-20241022")

    def _delta_event(text):
        return SimpleNamespace(
            type="content_block_delta",
            delta=SimpleNamespace(type="text_delta", text=text),
        )

    events = [_delta_event("Hel"), _delta_event("lo")]
    final_message = _make_anthropic_message(input_tokens=7, output_tokens=2)

    def _fake_stream(**kwargs):
        return _FakeAnthropicStream(events, final_message)

    monkeypatch.setattr(client._sdk_client.messages, "stream", _fake_stream)

    chunks = [c async for c in client.stream(LLMRequest.from_system_user("sys", "user"))]

    assert [c.content for c in chunks] == ["Hel", "lo", ""]
    assert chunks[-1].metadata.get("final") is True
    assert chunks[-1].usage == TokenUsage(promptTokens=7, completionTokens=2, totalTokens=9)
    assert chunks[-1].cost is not None


# ─── Gemini adapter ─────────────────────────────────────────────────────────


def _make_genai_response(text="hello", prompt_tokens=5, completion_tokens=3, finish_reason="STOP"):
    from google.genai import types as genai_types

    fr = genai_types.FinishReason(finish_reason) if finish_reason else None
    return genai_types.GenerateContentResponse.model_construct(
        candidates=[
            genai_types.Candidate.model_construct(
                content=genai_types.Content(role="model", parts=[genai_types.Part(text=text)]),
                finish_reason=fr,
                index=0,
            )
        ],
        usage_metadata=genai_types.GenerateContentResponseUsageMetadata.model_construct(
            prompt_token_count=prompt_tokens,
            candidates_token_count=completion_tokens,
            total_token_count=prompt_tokens + completion_tokens,
        ),
    )


@pytest.mark.asyncio
async def test_gemini_client_generate_normalizes_response(monkeypatch):
    client = GeminiClient(api_key="fake-key", model="gemini-2.0-flash")
    mock_generate = AsyncMock(return_value=_make_genai_response("hi there"))
    monkeypatch.setattr(client._sdk_client.aio.models, "generate_content", mock_generate)

    response = await client.generate(LLMRequest.from_system_user("sys", "user"))

    assert response.content == "hi there"
    assert response.finish_reason == "STOP"
    assert response.usage == TokenUsage(promptTokens=5, completionTokens=3, totalTokens=8)
    assert response.latency_ms is not None
    assert response.cost == estimate_cost("gemini", "gemini-2.0-flash", response.usage)
    assert response.cost is not None

    _, kwargs = mock_generate.call_args
    assert kwargs["config"].system_instruction == "sys"


@pytest.mark.asyncio
async def test_gemini_client_maps_permanent_and_transient_errors(monkeypatch):
    from google.genai import errors as genai_errors

    client = GeminiClient(api_key="bad", model="gemini-2.0-flash")

    monkeypatch.setattr(
        client._sdk_client.aio.models,
        "generate_content",
        AsyncMock(
            side_effect=genai_errors.ClientError(
                code=401, response_json={"error": {"message": "bad key"}}
            )
        ),
    )
    with pytest.raises(LLMPermanentError):
        await client.generate(LLMRequest.from_system_user("s", "u"))

    monkeypatch.setattr(
        client._sdk_client.aio.models,
        "generate_content",
        AsyncMock(
            side_effect=genai_errors.ClientError(
                code=429, response_json={"error": {"message": "rate limited"}}
            )
        ),
    )
    with pytest.raises(LLMTransientError):
        await client.generate(LLMRequest.from_system_user("s", "u"))


@pytest.mark.asyncio
async def test_gemini_client_stream_yields_deltas_then_final_usage(monkeypatch):
    client = GeminiClient(api_key="fake-key", model="gemini-2.0-flash")

    async def _fake_stream(**kwargs):
        async def _gen():
            yield _make_genai_response("Hel", prompt_tokens=1, completion_tokens=1)
            yield _make_genai_response("lo", prompt_tokens=4, completion_tokens=2)

        return _gen()

    monkeypatch.setattr(client._sdk_client.aio.models, "generate_content_stream", _fake_stream)

    chunks = [c async for c in client.stream(LLMRequest.from_system_user("sys", "user"))]

    # Two content chunks (each chunk's own .text) plus one final usage-only chunk.
    assert [c.content for c in chunks[:-1]] == ["Hel", "lo"]
    assert chunks[-1].content == ""
    assert chunks[-1].metadata.get("final") is True
    # Final chunk's usage reflects the LAST chunk's usage_metadata snapshot.
    assert chunks[-1].usage == TokenUsage(promptTokens=4, completionTokens=2, totalTokens=6)
