"""Tests for the Supervisor engine, focused on execution-path decisions
and the human-in-the-loop clarification path.

Uses a fake ILLMClient (no real network/API calls) so these tests exercise
SupervisorEngine's own logic — the deterministic risk-vs-clarification
precedence in _decide_execution_path, and the needs_clarification /
resumed-call handling in _understand_goal — independent of any provider.
"""

import json

import pytest

from ai_os.app.domain.interfaces.llm_client import ILLMClient
from ai_os.app.domain.models.kernel_request import KernelRequest, RequestSource, RequestType
from ai_os.app.domain.models.llm_request import LLMRequest
from ai_os.app.domain.models.llm_response import LLMResponse
from ai_os.app.infrastructure.engines.Supervisor.schemas import GoalAnalysis
from ai_os.app.infrastructure.engines.Supervisor.supervisor_engine import SupervisorEngine


class FakeSupervisorLLMClient(ILLMClient):
    """Returns a pre-set JSON payload as the LLM's response.content."""

    def __init__(self, responses: list[dict]) -> None:
        self._responses = list(responses)
        self.calls: list[LLMRequest] = []

    async def generate(self, request: LLMRequest) -> LLMResponse:
        self.calls.append(request)
        payload = self._responses.pop(0)
        return LLMResponse(content=json.dumps(payload), metadata={"provider": "fake", "model": "fake-model"})

    async def stream(self, request):
        raise NotImplementedError

    async def structured_output(self, request, schema):
        return await self.generate(request)

    async def health(self) -> bool:
        return True


def make_request(payload: dict) -> KernelRequest:
    return KernelRequest(
        requestId="REQ-1",
        executionId="EXE-1",
        correlationId="COR-1",
        sessionId="SESSION-1",
        source=RequestSource(type="test", id="test"),
        requestType=RequestType.CAPABILITY_REQUEST,
        capability="supervisor.understand_goal",
        payload=payload,
    )


def make_analysis(**overrides) -> GoalAnalysis:
    defaults = dict(
        goal="x",
        intent="x",
        riskLevel="low",
        executionPath="requires_planning",
        directResponse="",
        clarificationQuestion="",
    )
    defaults.update(overrides)
    return GoalAnalysis.model_validate(defaults)


# ─── Unit tests: _decide_execution_path precedence ─────────────────────────


@pytest.mark.parametrize("risk_level", ["low", "medium", "high"])
def test_needs_clarification_honored_at_every_risk_level(risk_level):
    """The core fix: asking the user is never risky, so risk must never

    suppress a well-formed needs_clarification pick, regardless of risk
    level.
    """
    engine = SupervisorEngine(llm_client=FakeSupervisorLLMClient([]))
    analysis = make_analysis(
        riskLevel=risk_level, executionPath="needs_clarification", clarificationQuestion="Which report?"
    )
    assert engine._decide_execution_path(analysis) == "needs_clarification"


@pytest.mark.parametrize("risk_level", ["low", "medium"])
def test_malformed_needs_clarification_falls_back_to_planning(risk_level):
    """needs_clarification with no actual question is malformed output —

    never trusted, regardless of risk level.
    """
    engine = SupervisorEngine(llm_client=FakeSupervisorLLMClient([]))
    analysis = make_analysis(riskLevel=risk_level, executionPath="needs_clarification", clarificationQuestion="")
    assert engine._decide_execution_path(analysis) == "requires_planning"


@pytest.mark.parametrize("risk_level", ["medium", "high"])
def test_direct_response_forced_to_planning_at_medium_high_risk(risk_level):
    """direct_response still can't skip Planning at medium/high risk —

    this override is unchanged by the fix.
    """
    engine = SupervisorEngine(llm_client=FakeSupervisorLLMClient([]))
    analysis = make_analysis(riskLevel=risk_level, executionPath="direct_response", directResponse="the answer")
    assert engine._decide_execution_path(analysis) == "requires_planning"


def test_direct_response_allowed_at_low_risk_with_answer():
    engine = SupervisorEngine(llm_client=FakeSupervisorLLMClient([]))
    analysis = make_analysis(riskLevel="low", executionPath="direct_response", directResponse="hello")
    assert engine._decide_execution_path(analysis) == "direct_response"


def test_direct_response_without_answer_falls_back_to_planning():
    engine = SupervisorEngine(llm_client=FakeSupervisorLLMClient([]))
    analysis = make_analysis(riskLevel="low", executionPath="direct_response", directResponse="")
    assert engine._decide_execution_path(analysis) == "requires_planning"


def test_requires_planning_passes_through_unchanged():
    engine = SupervisorEngine(llm_client=FakeSupervisorLLMClient([]))
    analysis = make_analysis(riskLevel="low", executionPath="requires_planning")
    assert engine._decide_execution_path(analysis) == "requires_planning"


# ─── Integration tests: _understand_goal end-to-end via execute() ──────────


AMBIGUOUS_MEDIUM_RISK_RESPONSE = {
    "goal": "Send a report to some recipients",
    "intent": "task_automation",
    "riskLevel": "medium",
    "executionPath": "needs_clarification",
    "clarificationQuestion": "Which report should I send, and who are the recipients?",
    "directResponse": "",
}

CLEAR_LOW_RISK_PLANNING_RESPONSE = {
    "goal": "Summarize the Q3 report",
    "intent": "task_automation",
    "riskLevel": "low",
    "executionPath": "requires_planning",
    "clarificationQuestion": "",
    "directResponse": "",
}


@pytest.mark.asyncio
async def test_understand_goal_raises_human_input_even_at_medium_risk():
    """End-to-end regression test for the reported bug: a query like

    "Send that report to them" — genuinely ambiguous, medium risk — must
    raise humanInputRequired at the Supervisor stage instead of silently
    being forced into requires_planning and leaking the ambiguity to
    Planning.
    """
    llm = FakeSupervisorLLMClient([AMBIGUOUS_MEDIUM_RISK_RESPONSE])
    engine = SupervisorEngine(llm_client=llm)

    request = make_request({"userQuery": "Send that report to them"})
    response = await engine.execute(request)

    assert response.status.value == "SUCCESS"
    assert response.next_step is None  # suspended for human input, not routed to Planning
    signal = response.result["humanInputRequired"]
    assert signal["question"] == "Which report should I send, and who are the recipients?"
    assert signal["taskId"] is None
    # strategy.executionPath must reflect the actually-taken path
    assert response.result["strategy"]["executionPath"] == "needs_clarification"


@pytest.mark.asyncio
async def test_understand_goal_routes_to_planning_when_clear():
    llm = FakeSupervisorLLMClient([CLEAR_LOW_RISK_PLANNING_RESPONSE])
    engine = SupervisorEngine(llm_client=llm)

    request = make_request({"userQuery": "Summarize the Q3 report"})
    response = await engine.execute(request)

    assert response.status.value == "SUCCESS"
    assert "humanInputRequired" not in (response.result or {})
    assert response.next_step is not None
    assert response.next_step.capability == "planning.create_plan"


@pytest.mark.asyncio
async def test_resumed_call_after_clarification_answer_proceeds_to_planning():
    llm = FakeSupervisorLLMClient([CLEAR_LOW_RISK_PLANNING_RESPONSE])
    engine = SupervisorEngine(llm_client=llm)

    # Simulates the kernel's re-dispatch after AIKernel._await_human_input
    # resolves — same capability, payload now carries the answer.
    request = make_request(
        {
            "userQuery": "Send that report to them",
            "humanInputAnswer": {"report": "Q3 report", "recipients": "finance@example.com"},
            "humanInputQuestion": "Which report should I send, and who are the recipients?",
        }
    )
    response = await engine.execute(request)

    assert response.status.value == "SUCCESS"
    assert "humanInputRequired" not in (response.result or {})
    assert response.next_step.capability == "planning.create_plan"

    sent_prompt = llm.calls[0].messages[-1].content
    assert "Which report should I send" in sent_prompt
    assert "finance@example.com" in sent_prompt

    # Resumed calls are recorded as a "system" turn, not "human".
    turn = response.result["conversationTurn"]
    assert "system" in turn
    assert "Resuming after clarification" in turn["system"]
