"""Tests for the pricing table: $/million-token rates, and the on-disk
override mechanism (Settings.model_pricing_overrides_path).
"""

import json

import pytest

from ai_os.app.domain.models.llm_response import TokenUsage
from ai_os.app.infrastructure.engines.Model import pricing


def test_default_pricing_returns_expected_rate():
    usage = TokenUsage(promptTokens=1_000_000, completionTokens=1_000_000, totalTokens=2_000_000)
    cost = pricing.estimate_cost("openai", "gpt-4.1", usage)
    # DEFAULT_PRICING_TABLE["openai"]["gpt-4.1"] = (2.00, 8.00) $/million
    assert cost == pytest.approx(2.00 + 8.00)


def test_unknown_model_returns_none_not_zero():
    usage = TokenUsage(promptTokens=100, completionTokens=100, totalTokens=200)
    assert pricing.estimate_cost("openai", "not-a-real-model", usage) is None


def test_override_file_takes_precedence_over_default(tmp_path, monkeypatch):
    override_path = tmp_path / "overrides.json"
    override_path.write_text(json.dumps({"openai": {"gpt-4.1": [1.0, 2.0]}}), encoding="utf-8")

    from ai_os.app.config.settings import get_settings

    monkeypatch.setattr(get_settings(), "model_pricing_overrides_path", str(override_path))

    usage = TokenUsage(promptTokens=1_000_000, completionTokens=1_000_000, totalTokens=2_000_000)
    cost = pricing.estimate_cost("openai", "gpt-4.1", usage)
    assert cost == pytest.approx(1.0 + 2.0)  # override rate, not the default (2.00, 8.00)


def test_override_file_falls_back_to_default_for_unlisted_model(tmp_path, monkeypatch):
    override_path = tmp_path / "overrides.json"
    override_path.write_text(json.dumps({"openai": {"gpt-4.1": [1.0, 2.0]}}), encoding="utf-8")

    from ai_os.app.config.settings import get_settings

    monkeypatch.setattr(get_settings(), "model_pricing_overrides_path", str(override_path))

    usage = TokenUsage(promptTokens=1_000_000, completionTokens=1_000_000, totalTokens=2_000_000)
    # gpt-4o-mini isn't in the override file -> falls back to DEFAULT_PRICING_TABLE
    cost = pricing.estimate_cost("openai", "gpt-4o-mini", usage)
    assert cost == pytest.approx(0.15 + 0.60)


def test_missing_override_path_falls_back_to_default(monkeypatch):
    from ai_os.app.config.settings import get_settings

    monkeypatch.setattr(get_settings(), "model_pricing_overrides_path", "/does/not/exist.json")

    usage = TokenUsage(promptTokens=1_000_000, completionTokens=1_000_000, totalTokens=2_000_000)
    cost = pricing.estimate_cost("openai", "gpt-4.1", usage)
    assert cost == pytest.approx(2.00 + 8.00)


def test_malformed_override_entries_are_skipped_not_fatal(tmp_path, monkeypatch):
    override_path = tmp_path / "overrides.json"
    override_path.write_text(
        json.dumps(
            {
                "_comment": "this is a string, not a provider dict -- must be skipped",
                "openai": {
                    "gpt-4.1": [1.0, 2.0],
                    "bad-entry": "not-a-pair",
                },
            }
        ),
        encoding="utf-8",
    )

    from ai_os.app.config.settings import get_settings

    monkeypatch.setattr(get_settings(), "model_pricing_overrides_path", str(override_path))

    usage = TokenUsage(promptTokens=1_000_000, completionTokens=1_000_000, totalTokens=2_000_000)
    # Valid entry still works.
    assert pricing.estimate_cost("openai", "gpt-4.1", usage) == pytest.approx(1.0 + 2.0)
    # Malformed entry is skipped -> falls back to default table (no price there either).
    assert pricing.estimate_cost("openai", "bad-entry", usage) is None


def test_empty_override_path_uses_default_only():
    from ai_os.app.config.settings import get_settings

    # Default state: model_pricing_overrides_path is "" (no override configured).
    assert get_settings().model_pricing_overrides_path == ""
    usage = TokenUsage(promptTokens=1_000_000, completionTokens=1_000_000, totalTokens=2_000_000)
    assert pricing.estimate_cost("openai", "gpt-4.1", usage) == pytest.approx(2.00 + 8.00)
