"""Tests for the Model engine against the stated acceptance criteria:

    - Common model interface works
    - Provider-specific code is isolated
    - Responses are normalized
    - Streaming works
    - Timeout/retry/fallback work
    - Usage, latency, and cost are captured

No real network calls are made — AsyncOpenAI's `chat.completions.create`
is mocked, and resilience behavior (retry/timeout/fallback) is tested
against small fake ILLMClient stubs rather than the real OpenAI adapter,
so that layer's tests don't depend on OpenAI SDK internals at all.
"""

import asyncio
from collections.abc import AsyncIterator
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from ai_os.app.domain.interfaces.llm_client import ILLMClient
from ai_os.app.domain.interfaces.llm_errors import LLMPermanentError, LLMTransientError
from ai_os.app.domain.models.kernel_request import KernelRequest, RequestSource, RequestType
from ai_os.app.domain.models.llm_request import LLMRequest
from ai_os.app.domain.models.llm_response import LLMResponse, TokenUsage
from ai_os.app.domain.models.model_configuration import ModelConfiguration
from ai_os.app.infrastructure.engines.Model.client_factory import ClientFactory
from ai_os.app.infrastructure.engines.Model.exceptions import (
    InvalidConfigurationError,
    UnsupportedProviderError,
)
from ai_os.app.infrastructure.engines.Model.model_engine import ModelEngine
from ai_os.app.infrastructure.engines.Model.pricing import estimate_cost
from ai_os.app.infrastructure.engines.Model.provider_registry import ProviderRegistry
from ai_os.app.infrastructure.engines.Model.providers.openai_provider import (
    OpenAIClient,
    OpenAIProviderFactory,
)
from ai_os.app.infrastructure.engines.Model.resilient_client import (
    LLMRetryExhaustedError,
    ResilientLLMClient,
)
from ai_os.app.infrastructure.engines.Model.validators import validate_configuration


def make_config(**overrides) -> ModelConfiguration:
    defaults = dict(provider="openai", modelName="gpt-4.1", apiKey="sk-test", retry=2, timeout=5)
    defaults.update(overrides)
    return ModelConfiguration(**defaults)


def make_kernel_request(capability: str, payload: dict) -> KernelRequest:
    return KernelRequest(
        requestId="REQ-1",
        executionId="EXE-1",
        correlationId="COR-1",
        sessionId="SESSION-1",
        source=RequestSource(type="test", id="test"),
        requestType=RequestType.CAPABILITY_REQUEST,
        capability=capability,
        payload=payload,
    )


# ─── Provider registry / validators: provider isolation ────────────────────


def test_provider_registry_resolves_openai():
    registry = ProviderRegistry()
    factory = registry.get("openai")
    assert isinstance(factory, OpenAIProviderFactory)
    assert registry.is_supported("openai")
    assert "openai" in registry.list_supported()


def test_provider_registry_unsupported_provider_raises():
    registry = ProviderRegistry()
    with pytest.raises(UnsupportedProviderError):
        registry.get("does-not-exist")


def test_validate_configuration_rejects_bad_temperature():
    registry = ProviderRegistry()
    config = make_config(temperature=5.0)
    with pytest.raises(InvalidConfigurationError):
        validate_configuration(config, registry)


def test_validate_configuration_rejects_missing_api_key_for_openai():
    registry = ProviderRegistry()
    config = ModelConfiguration(provider="openai", modelName="gpt-4.1")
    with pytest.raises(InvalidConfigurationError):
        validate_configuration(config, registry)


def test_validate_configuration_internal_config_without_api_key_needs_base_url():
    """isInternal=true now routes to InternalProviderFactory (see

    tests/test_internal_provider.py for full coverage) — it never needs
    apiKey, but it does need a resolvable baseUrl (either on the config or
    via INTERNAL_MODEL_BASE_URL).
    """
    registry = ProviderRegistry()
    config = ModelConfiguration(provider="openai", modelName="gpt-4.1", isInternal=True, baseUrl="http://internal.local/v1/chat")
    validate_configuration(config, registry)  # should not raise


# ─── Common interface + response normalization (OpenAI adapter) ────────────


def _make_openai_chat_response(content: str, prompt_tokens=10, completion_tokens=5):
    return SimpleNamespace(
        choices=[SimpleNamespace(message=SimpleNamespace(content=content), finish_reason="stop")],
        usage=SimpleNamespace(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=prompt_tokens + completion_tokens,
        ),
        model="gpt-4.1",
    )


@pytest.mark.asyncio
async def test_openai_client_generate_normalizes_response(monkeypatch):
    client = OpenAIClient(api_key="sk-test", model="gpt-4.1")
    mock_create = AsyncMock(return_value=_make_openai_chat_response("hello world"))
    monkeypatch.setattr(client._sdk_client.chat.completions, "create", mock_create)

    response = await client.generate(LLMRequest.from_system_user("sys", "user"))

    assert isinstance(response, LLMResponse)
    assert response.content == "hello world"
    assert response.finish_reason == "stop"
    assert response.usage == TokenUsage(promptTokens=10, completionTokens=5, totalTokens=15)
    assert response.latency_ms is not None and response.latency_ms >= 0
    assert response.cost == estimate_cost("openai", "gpt-4.1", response.usage)
    assert response.cost is not None
    # raw_response carries the provider-native object but is excluded from
    # serialization — callers must not need it for normal use.
    assert response.raw_response is not None
    assert "rawResponse" not in response.model_dump(by_alias=True)


@pytest.mark.asyncio
async def test_openai_client_unknown_model_has_no_cost(monkeypatch):
    client = OpenAIClient(api_key="sk-test", model="not-a-real-model")
    mock_create = AsyncMock(return_value=_make_openai_chat_response("hi"))
    monkeypatch.setattr(client._sdk_client.chat.completions, "create", mock_create)

    response = await client.generate(LLMRequest.from_system_user("sys", "user"))

    assert response.cost is None  # never silently 0.0 for an unpriced model


@pytest.mark.asyncio
async def test_openai_client_maps_permanent_error(monkeypatch):
    import httpx
    from openai import AuthenticationError

    client = OpenAIClient(api_key="bad-key", model="gpt-4.1")
    fake_response = httpx.Response(status_code=401, request=httpx.Request("POST", "https://api.openai.com"))
    mock_create = AsyncMock(
        side_effect=AuthenticationError(message="invalid api key", response=fake_response, body=None)
    )
    monkeypatch.setattr(client._sdk_client.chat.completions, "create", mock_create)

    with pytest.raises(LLMPermanentError):
        await client.generate(LLMRequest.from_system_user("sys", "user"))


@pytest.mark.asyncio
async def test_openai_client_maps_transient_error(monkeypatch):
    import httpx
    from openai import RateLimitError

    client = OpenAIClient(api_key="sk-test", model="gpt-4.1")
    fake_response = httpx.Response(status_code=429, request=httpx.Request("POST", "https://api.openai.com"))
    mock_create = AsyncMock(
        side_effect=RateLimitError(message="rate limited", response=fake_response, body=None)
    )
    monkeypatch.setattr(client._sdk_client.chat.completions, "create", mock_create)

    with pytest.raises(LLMTransientError):
        await client.generate(LLMRequest.from_system_user("sys", "user"))


# ─── Streaming ───────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_openai_client_stream_yields_deltas_then_final_usage(monkeypatch):
    client = OpenAIClient(api_key="sk-test", model="gpt-4.1")

    def _delta_chunk(text: str, finish_reason=None):
        return SimpleNamespace(
            choices=[SimpleNamespace(delta=SimpleNamespace(content=text), finish_reason=finish_reason)],
            usage=None,
        )

    def _final_chunk():
        return SimpleNamespace(
            choices=[],
            usage=SimpleNamespace(prompt_tokens=8, completion_tokens=3, total_tokens=11),
        )

    async def _fake_stream():
        yield _delta_chunk("Hel")
        yield _delta_chunk("lo", finish_reason="stop")
        yield _final_chunk()

    async def _fake_create(**kwargs):
        assert kwargs["stream"] is True
        return _fake_stream()

    monkeypatch.setattr(client._sdk_client.chat.completions, "create", _fake_create)

    chunks = [chunk async for chunk in client.stream(LLMRequest.from_system_user("sys", "user"))]

    assert [c.content for c in chunks] == ["Hel", "lo", ""]
    assert chunks[-1].metadata.get("final") is True
    assert chunks[-1].usage == TokenUsage(promptTokens=8, completionTokens=3, totalTokens=11)
    assert chunks[-1].cost is not None


# ─── ResilientLLMClient: timeout / retry / fallback ────────────────────────


class FakeLLMClient(ILLMClient):
    """Minimal ILLMClient stub for exercising ResilientLLMClient in isolation."""

    def __init__(self, behaviors=None, tag="primary", delay: float = 0.0):
        # `behaviors` is a list consumed one-per-call: an LLMResponse to
        # return, or an exception instance to raise.
        self._behaviors = list(behaviors or [])
        self.tag = tag
        self.delay = delay
        self.call_count = 0

    async def generate(self, request: LLMRequest) -> LLMResponse:
        self.call_count += 1
        if self.delay:
            await asyncio.sleep(self.delay)
        behavior = self._behaviors.pop(0)
        if isinstance(behavior, Exception):
            raise behavior
        return behavior

    async def stream(self, request: LLMRequest) -> AsyncIterator[LLMResponse]:
        self.call_count += 1
        behavior = self._behaviors.pop(0)
        if isinstance(behavior, Exception):
            raise behavior
        for chunk in behavior:
            yield chunk

    async def structured_output(self, request: LLMRequest, schema: dict) -> LLMResponse:
        return await self.generate(request)

    async def health(self) -> bool:
        return True


def _ok_response(text="ok") -> LLMResponse:
    return LLMResponse(content=text)


@pytest.mark.asyncio
async def test_resilient_client_retries_transient_then_succeeds():
    primary = FakeLLMClient(behaviors=[LLMTransientError("rate limited"), _ok_response("done")])
    config = make_config(retry=2)
    client = ResilientLLMClient(primary=primary, config=config)

    response = await client.generate(LLMRequest.from_system_user("s", "u"))

    assert response.content == "done"
    assert primary.call_count == 2


@pytest.mark.asyncio
async def test_resilient_client_permanent_error_is_not_retried():
    primary = FakeLLMClient(behaviors=[LLMPermanentError("bad api key")])
    config = make_config(retry=3)
    client = ResilientLLMClient(primary=primary, config=config)

    with pytest.raises(LLMPermanentError):
        await client.generate(LLMRequest.from_system_user("s", "u"))

    assert primary.call_count == 1  # never retried


@pytest.mark.asyncio
async def test_resilient_client_gives_up_after_retries_exhausted_without_fallback():
    primary = FakeLLMClient(
        behaviors=[LLMTransientError("1"), LLMTransientError("2"), LLMTransientError("3")]
    )
    config = make_config(retry=2)  # 1 initial attempt + 2 retries = 3 total
    client = ResilientLLMClient(primary=primary, config=config)

    with pytest.raises(LLMRetryExhaustedError):
        await client.generate(LLMRequest.from_system_user("s", "u"))

    assert primary.call_count == 3


@pytest.mark.asyncio
async def test_resilient_client_falls_back_after_retries_exhausted():
    primary = FakeLLMClient(behaviors=[LLMTransientError("1"), LLMTransientError("2")])
    fallback = FakeLLMClient(behaviors=[_ok_response("from-fallback")], tag="fallback")
    config = make_config(retry=1, fallback=make_config(modelName="gpt-4o-mini"))

    client = ResilientLLMClient(
        primary=primary,
        config=config,
        fallback_factory=lambda _cfg: fallback,
    )

    response = await client.generate(LLMRequest.from_system_user("s", "u"))

    assert response.content == "from-fallback"
    assert primary.call_count == 2  # 1 initial + 1 retry, both transient
    assert fallback.call_count == 1


@pytest.mark.asyncio
async def test_resilient_client_timeout_triggers_retry_then_raises():
    primary = FakeLLMClient(behaviors=[_ok_response(), _ok_response()], delay=0.2)
    config = make_config(retry=1, timeout=0)  # falls back to DEFAULT via 0 -> but 0 truthy check
    # timeout=0 is falsy in `float(config.timeout) if config.timeout else DEFAULT`,
    # so use a tiny nonzero timeout instead to force a real timeout.
    config = make_config(retry=1, timeout=1)
    client = ResilientLLMClient(primary=primary, config=config)
    client._timeout_seconds = 0.01  # force timeout deterministically, faster than sleeping 1s

    with pytest.raises(LLMRetryExhaustedError):
        await client.generate(LLMRequest.from_system_user("s", "u"))

    assert primary.call_count == 2  # 1 initial + 1 retry, both timed out


@pytest.mark.asyncio
async def test_resilient_client_stream_establishes_with_retry_then_yields_all_chunks():
    chunks = [LLMResponse(content="a"), LLMResponse(content="b")]
    primary = FakeLLMClient(behaviors=[LLMTransientError("first attempt fails"), chunks])
    config = make_config(retry=1)
    client = ResilientLLMClient(primary=primary, config=config)

    received = [c async for c in client.stream(LLMRequest.from_system_user("s", "u"))]

    assert [c.content for c in received] == ["a", "b"]
    assert primary.call_count == 2


# ─── Usage/latency/cost capture end-to-end through ClientFactory ──────────


@pytest.mark.asyncio
async def test_client_factory_wraps_provider_client_with_resilience(monkeypatch):
    factory = ClientFactory()
    config = make_config()

    client = factory.create_client(config)

    assert isinstance(client, ResilientLLMClient)
    # Underneath, the raw client is still a real OpenAIClient — provider
    # isolation means ClientFactory/ResilientLLMClient never construct
    # anything OpenAI-specific themselves.
    assert isinstance(client._primary, OpenAIClient)


@pytest.mark.asyncio
async def test_client_factory_fallback_config_builds_single_hop_only(monkeypatch):
    factory = ClientFactory()
    nested_fallback = make_config(modelName="gpt-4o-mini", fallback=make_config(modelName="gpt-4.1"))
    config = make_config(fallback=nested_fallback)

    client = factory.create_client(config)
    fallback_client = client._get_fallback_client()

    assert isinstance(fallback_client, ResilientLLMClient)
    # The fallback client's own config must not carry a further fallback —
    # only one hop is ever attempted.
    assert fallback_client._config.fallback is None


# ─── ModelEngine: capability surface + fixed input/output contract ────────


def test_model_engine_create_client_from_config_returns_illm_client():
    engine = ModelEngine()
    client = engine.create_client_from_config(make_config())
    assert isinstance(client, ILLMClient)


@pytest.mark.asyncio
async def test_model_engine_create_client_capability_success():
    engine = ModelEngine()
    request = make_kernel_request(
        "model.create_client", {"modelConfiguration": make_config().model_dump(by_alias=True)}
    )
    response = await engine.execute(request)

    assert response.status.value == "SUCCESS"
    assert isinstance(response.result["client"], ILLMClient)
    assert response.result["provider"] == "openai"


@pytest.mark.asyncio
async def test_model_engine_create_client_capability_missing_config_fails():
    engine = ModelEngine()
    request = make_kernel_request("model.create_client", {})
    response = await engine.execute(request)

    assert response.status.value == "FAILURE"
    assert response.errors[0]["code"] == "INVALID_MODEL_CONFIGURATION"


@pytest.mark.asyncio
async def test_model_engine_validate_configuration_capability_unsupported_provider():
    engine = ModelEngine()
    request = make_kernel_request(
        "model.validate_configuration",
        {"modelConfiguration": {"provider": "not-real", "modelName": "x"}},
    )
    response = await engine.execute(request)

    assert response.status.value == "FAILURE"
    assert response.errors[0]["code"] == "INVALID_MODEL_CONFIGURATION"


@pytest.mark.asyncio
async def test_model_engine_unsupported_capability():
    engine = ModelEngine()
    request = make_kernel_request("model.generate", {})
    response = await engine.execute(request)

    assert response.status.value == "FAILURE"
    assert response.errors[0]["code"] == "UNSUPPORTED_CAPABILITY"
