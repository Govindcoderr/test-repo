import pytest
import pytest_asyncio

from ai_os.app.api.dependencies import KernelContainer
from ai_os.app.domain.models.dispatch_plan import DispatchPlan, EngineDispatchItem
from ai_os.app.domain.models.engine import EngineManifest, EngineStatus
from ai_os.app.domain.models.execution import ExecutionRequest
from ai_os.app.domain.models.execution_state import ExecutionState, can_transition
from ai_os.app.domain.models.kernel_request import KernelRequest, RequestSource, RequestType, ResourceRef
from ai_os.app.domain.models.kernel_response import KernelResponse, ResponseStatus
from ai_os.app.infrastructure.engines.base_engine import BaseEngine
from ai_os.app.kernel.errors.kernel_errors import KernelException


# ─── Test Engine Fixtures ────────────────────────────────────────────────────


class StubModelEngine(BaseEngine):
    """Stub engine providing model capabilities for tests."""

    def __init__(self):
        super().__init__(
            EngineManifest(
                engineId="model-engine",
                name="Test Model Engine",
                version="1.0.0",
                capabilities=["model.reason", "model.summarize"],
                resources=[],
                priority=100,
            )
        )

    async def execute(self, request: KernelRequest) -> KernelResponse:
        query = request.payload.get("userQuery", "")
        return self._success(request, {
            "response": f"Model response for: {query}",
            "provider": "test",
            "modelName": "test-model",
        })


class StubKnowledgeEngine(BaseEngine):
    """Stub engine providing knowledge retrieval for tests."""

    def __init__(self):
        super().__init__(
            EngineManifest(
                engineId="knowledge-engine",
                name="Test Knowledge Engine",
                version="1.0.0",
                capabilities=["knowledge.retrieve", "knowledge.search"],
                resources=["document", "RFQ"],
                priority=100,
            )
        )

    async def execute(self, request: KernelRequest) -> KernelResponse:
        resource_type = request.resource.type if request.resource else "knowledge"
        resource_id = request.resource.id if request.resource else "N/A"
        return self._success(request, {
            "content": f"Retrieved {resource_type} {resource_id}",
            "resourceType": resource_type,
            "resourceId": resource_id,
            "documentsRetrieved": 1,
        })


class StubToolEngine(BaseEngine):
    """Stub engine providing tool execution for tests."""

    def __init__(self):
        super().__init__(
            EngineManifest(
                engineId="tool-engine",
                name="Test Tool Engine",
                version="1.0.0",
                capabilities=["tool.execute"],
                resources=[],
                priority=50,
            )
        )

    async def execute(self, request: KernelRequest) -> KernelResponse:
        tool = request.payload.get("tool", "unknown")
        return self._success(request, {
            "tool": tool,
            "result": f"Tool {tool} executed",
        })


# ─── Fixtures ────────────────────────────────────────────────────────────────


@pytest.fixture
def container():
    return KernelContainer()


@pytest_asyncio.fixture
async def bootstrapped_container(container):
    engines = [StubModelEngine(), StubKnowledgeEngine(), StubToolEngine()]
    await container.bootstrap(engines)
    return container


SAMPLE_REQUEST = {
    "sessionId": "SESSION-1001",
    "userId": "USER-1001",
    "userQuery": "Analyze the RFQ.",
}


# ─── Engine Registration Tests ───────────────────────────────────────────────


@pytest.mark.asyncio
async def test_engine_registration(bootstrapped_container):
    engines = bootstrapped_container.engine_registry.list_engines()
    engine_ids = {e.engine_id for e in engines}
    assert "model-engine" in engine_ids
    assert "knowledge-engine" in engine_ids
    assert "tool-engine" in engine_ids


@pytest.mark.asyncio
async def test_capability_registration(bootstrapped_container):
    registry = bootstrapped_container.capability_registry
    assert registry.is_available("model.reason")
    assert registry.is_available("knowledge.retrieve")
    assert registry.is_available("tool.execute")
    providers = registry.find_providers("model.reason")
    assert any(p.engine_id == "model-engine" for p in providers)


@pytest.mark.asyncio
async def test_resource_registration(bootstrapped_container):
    registry = bootstrapped_container.resource_registry
    assert registry.is_available("RFQ")
    assert registry.is_available("document")
    providers = registry.find_providers("RFQ")
    assert any(p.engine_id == "knowledge-engine" for p in providers)


@pytest.mark.asyncio
async def test_dynamic_engine_registration(bootstrapped_container):
    """Engines can be registered at runtime without modifying the kernel."""

    class DocumentEngine(BaseEngine):
        def __init__(self):
            super().__init__(
                EngineManifest(
                    engineId="document-engine",
                    name="Document Engine",
                    capabilities=["document.extract"],
                    resources=["pdf"],
                    status=EngineStatus.ACTIVE,
                )
            )

        async def execute(self, request: KernelRequest) -> KernelResponse:
            return self._success(request, {"extracted": True})

    engine = DocumentEngine()
    await bootstrapped_container.register_and_initialize_engine(engine)

    assert bootstrapped_container.capability_registry.is_available("document.extract")
    assert bootstrapped_container.resource_registry.is_available("pdf")

    # Dispatch to the newly registered engine
    context = await bootstrapped_container.execution_manager.create_execution(
        ExecutionRequest(**SAMPLE_REQUEST)
    )
    request = KernelRequest(
        requestId="REQ-DOC",
        executionId=context.execution_id,
        correlationId="REQ-DOC",
        sessionId=context.session_id,
        source=RequestSource(type="test", id="test"),
        requestType=RequestType.CAPABILITY_REQUEST,
        capability="document.extract",
    )
    response = await bootstrapped_container.request_dispatcher.dispatch(request, context)
    assert response.status == ResponseStatus.SUCCESS
    assert response.result["extracted"] is True


# ─── Routing & Resolution Tests ──────────────────────────────────────────────


@pytest.mark.asyncio
async def test_capability_resolution(bootstrapped_container):
    context = await bootstrapped_container.execution_manager.create_execution(
        ExecutionRequest(**SAMPLE_REQUEST)
    )
    request = KernelRequest(
        requestId="REQ-TEST1",
        executionId=context.execution_id,
        correlationId="REQ-TEST1",
        sessionId=context.session_id,
        source=RequestSource(type="test", id="test"),
        requestType=RequestType.CAPABILITY_REQUEST,
        capability="model.reason",
    )
    selection = await bootstrapped_container.capability_resolver.resolve(
        "model.reason", request, context
    )
    assert selection.provider.engine_id == "model-engine"


@pytest.mark.asyncio
async def test_resource_resolution(bootstrapped_container):
    context = await bootstrapped_container.execution_manager.create_execution(
        ExecutionRequest(**SAMPLE_REQUEST)
    )
    request = KernelRequest(
        requestId="REQ-TEST2",
        executionId=context.execution_id,
        correlationId="REQ-TEST2",
        sessionId=context.session_id,
        source=RequestSource(type="test", id="test"),
        requestType=RequestType.RESOURCE_REQUEST,
        resource=ResourceRef(type="RFQ", id="RFQ-1001"),
    )
    selection = await bootstrapped_container.resource_resolver.resolve("RFQ", request, context)
    assert selection.provider.engine_id == "knowledge-engine"


@pytest.mark.asyncio
async def test_unresolvable_capability_raises(bootstrapped_container):
    context = await bootstrapped_container.execution_manager.create_execution(
        ExecutionRequest(**SAMPLE_REQUEST)
    )
    request = KernelRequest(
        requestId="REQ-MISSING",
        executionId=context.execution_id,
        correlationId="REQ-MISSING",
        sessionId=context.session_id,
        source=RequestSource(type="test", id="test"),
        requestType=RequestType.CAPABILITY_REQUEST,
        capability="nonexistent.capability",
    )
    with pytest.raises(KernelException) as exc_info:
        await bootstrapped_container.request_dispatcher.dispatch(request, context)
    assert exc_info.value.error.code == "CAPABILITY_NOT_FOUND"


# ─── Dispatch Tests ──────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_dispatch_capability_request(bootstrapped_container):
    context = await bootstrapped_container.execution_manager.create_execution(
        ExecutionRequest(**SAMPLE_REQUEST)
    )
    request = KernelRequest(
        requestId="REQ-CAP",
        executionId=context.execution_id,
        correlationId="REQ-CAP",
        sessionId=context.session_id,
        source=RequestSource(type="test", id="test"),
        requestType=RequestType.CAPABILITY_REQUEST,
        capability="model.reason",
        payload={"userQuery": "What is AI?"},
    )
    response = await bootstrapped_container.request_dispatcher.dispatch(request, context)
    assert response.status == ResponseStatus.SUCCESS
    assert "response" in response.result


@pytest.mark.asyncio
async def test_dispatch_resource_request(bootstrapped_container):
    context = await bootstrapped_container.execution_manager.create_execution(
        ExecutionRequest(**SAMPLE_REQUEST)
    )
    request = KernelRequest(
        requestId="REQ-RES",
        executionId=context.execution_id,
        correlationId="REQ-RES",
        sessionId=context.session_id,
        source=RequestSource(type="test", id="test"),
        requestType=RequestType.RESOURCE_REQUEST,
        resource=ResourceRef(type="RFQ", id="RFQ-1001"),
    )
    response = await bootstrapped_container.request_dispatcher.dispatch(request, context)
    assert response.status == ResponseStatus.SUCCESS
    assert response.result["resourceId"] == "RFQ-1001"


@pytest.mark.asyncio
async def test_single_dispatch_via_kernel(bootstrapped_container):
    """Test the kernel.dispatch() method for single engine calls."""
    kernel = bootstrapped_container.kernel
    dispatch_item = EngineDispatchItem(
        requestType="CAPABILITY_REQUEST",
        capability="model.reason",
        payload={"userQuery": "What is 2+2?"},
    )
    response = await kernel.dispatch(dispatch_item)
    assert response.status == ResponseStatus.SUCCESS
    assert "response" in response.result


# ─── Execution Lifecycle Tests ───────────────────────────────────────────────


@pytest.mark.asyncio
async def test_kernel_execute_creates_execution(bootstrapped_container):
    kernel = bootstrapped_container.kernel
    request = ExecutionRequest(**SAMPLE_REQUEST)
    response = await kernel.execute(request)
    assert response.execution_id.startswith("EXE-")
    assert response.status == "COMPLETED"


@pytest.mark.asyncio
async def test_kernel_execute_with_dispatch_plan(bootstrapped_container):
    """Execute a multi-step dispatch plan through the kernel."""
    kernel = bootstrapped_container.kernel
    request = ExecutionRequest(
        sessionId="SESSION-PLAN",
        userId="USER-PLAN",
        userQuery="Full analysis flow",
        metadata={
            "dispatchPlan": {
                "phases": [
                    {
                        "stepId": "step-1",
                        "stepName": "retrieve_document",
                        "requestType": "RESOURCE_REQUEST",
                        "resource": {"type": "RFQ", "id": "RFQ-2001"},
                    },
                    {
                        "stepId": "step-2",
                        "stepName": "reason_about_it",
                        "requestType": "CAPABILITY_REQUEST",
                        "capability": "model.reason",
                        "payload": {"userQuery": "Analyze the retrieved document"},
                    },
                ]
            }
        },
    )
    response = await kernel.execute(request)
    assert response.status == "COMPLETED"
    assert response.final_response is not None
    assert len(response.activity_logs) >= 2


@pytest.mark.asyncio
async def test_kernel_dispatch_plan_method(bootstrapped_container):
    """Test the kernel.dispatch_plan() method directly."""
    kernel = bootstrapped_container.kernel
    plan = DispatchPlan(phases=[
        {
            "stepId": "s1",
            "stepName": "get_knowledge",
            "requestType": "RESOURCE_REQUEST",
            "resource": {"type": "document", "id": "DOC-1"},
        },
        {
            "stepId": "s2",
            "stepName": "reason",
            "requestType": "CAPABILITY_REQUEST",
            "capability": "model.reason",
        },
    ])
    responses = await kernel.dispatch_plan(plan)
    assert len(responses) == 2
    assert all(r.status == ResponseStatus.SUCCESS for r in responses)


@pytest.mark.asyncio
async def test_kernel_dispatch_plan_with_parallel(bootstrapped_container):
    """Test parallel dispatch within a plan."""
    kernel = bootstrapped_container.kernel
    plan = DispatchPlan(phases=[
        {
            "parallel": [
                {"requestType": "RESOURCE_REQUEST", "resource": {"type": "RFQ", "id": "RFQ-1"}},
                {"requestType": "CAPABILITY_REQUEST", "capability": "tool.execute", "payload": {"tool": "search"}},
            ]
        },
        {
            "requestType": "CAPABILITY_REQUEST",
            "capability": "model.reason",
        },
    ])
    responses = await kernel.dispatch_plan(plan)
    assert len(responses) == 3
    assert all(r.status == ResponseStatus.SUCCESS for r in responses)


# ─── Correlator Tests ────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_response_correlator_updates_context(bootstrapped_container):
    context = await bootstrapped_container.execution_manager.create_execution(
        ExecutionRequest(**SAMPLE_REQUEST)
    )
    request = KernelRequest(
        requestId="REQ-CORR",
        executionId=context.execution_id,
        correlationId="REQ-CORR",
        sessionId=context.session_id,
        source=RequestSource(type="test", id="test"),
        requestType=RequestType.RESOURCE_REQUEST,
        resource=ResourceRef(type="RFQ", id="RFQ-1001"),
    )
    response = await bootstrapped_container.request_dispatcher.dispatch(request, context)
    await bootstrapped_container.response_correlator.correlate(response, context, request)

    assert context.steps_executed >= 1
    assert len(context.completed_requests) >= 1
    assert len(context.execution_logs) >= 1


# ─── State Machine Tests ─────────────────────────────────────────────────────


def test_execution_state_transitions():
    assert can_transition(ExecutionState.CREATED, ExecutionState.INITIALIZING)
    assert can_transition(ExecutionState.INITIALIZING, ExecutionState.VALIDATING)
    assert can_transition(ExecutionState.VALIDATING, ExecutionState.EXECUTING)
    assert can_transition(ExecutionState.EXECUTING, ExecutionState.VALIDATING_RESULT)
    assert can_transition(ExecutionState.VALIDATING_RESULT, ExecutionState.COMPLETED)
    assert not can_transition(ExecutionState.COMPLETED, ExecutionState.EXECUTING)
    assert not can_transition(ExecutionState.FAILED, ExecutionState.EXECUTING)


# ─── Health & Registry Tests ─────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_registry_lists_all_capabilities(bootstrapped_container):
    capabilities = bootstrapped_container.capability_registry.list_capabilities()
    assert "model.reason" in capabilities
    assert "knowledge.retrieve" in capabilities
    assert "tool.execute" in capabilities


@pytest.mark.asyncio
async def test_registry_lists_all_resources(bootstrapped_container):
    resources = bootstrapped_container.resource_registry.list_resource_types()
    assert "RFQ" in resources
    assert "document" in resources


@pytest.mark.asyncio
async def test_engine_health_check(bootstrapped_container):
    healthy = await bootstrapped_container.engine_registry.health_check("model-engine")
    assert healthy is True
