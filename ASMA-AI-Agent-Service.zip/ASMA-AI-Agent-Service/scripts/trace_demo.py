"""Run a demo execution and print the kernel routing trace step by step."""

import asyncio
import json
from pathlib import Path

from ai_os.app.api.dependencies import KernelContainer
from ai_os.app.domain.models.execution import ExecutionRequest


async def main() -> None:
    container = KernelContainer()
    await container.bootstrap()

    demo_path = Path(__file__).parent.parent / "examples" / "demo_request.json"
    payload = json.loads(demo_path.read_text(encoding="utf-8"))
    request = ExecutionRequest(**payload)

    print("=" * 70)
    print("AI KERNEL EXECUTION TRACE")
    print("=" * 70)
    print(f"User Query: {request.user_query}\n")

    response = await container.kernel.execute(request)

    print("ACTIVITY LOGS:")
    print("-" * 70)
    for i, log in enumerate(response.activity_logs, 1):
        print(f"{i:02d}. [{log.engine or 'kernel'}] {log.action}")
        print(f"    {log.message}")
        if log.duration is not None:
            print(f"    duration={log.duration}ms")
        print()

    print("=" * 70)
    print("FINAL RESULT")
    print("=" * 70)
    print(f"Status:         {response.status}")
    print(f"ExecutionState: {response.execution_state}")
    print(f"Final Response: {response.final_response}")
    if response.agent:
        print(f"Model Logs:     {len(response.agent.model_logs)}")
        print(f"Tool Logs:      {len(response.agent.tool_logs)}")
        summary = response.agent.execution_summary[0] if response.agent.execution_summary else None
        if summary:
            print(f"Completed Tasks:{summary.completed_tasks}")


if __name__ == "__main__":
    asyncio.run(main())
