"""Demonstrate the AI Kernel OS layer with backend ExecutionRequest / ExecutionResponse."""

import asyncio
import json
import sys
from pathlib import Path

from ai_os.app.api.dependencies import KernelContainer
from ai_os.app.domain.models.execution import ExecutionRequest


async def main() -> None:
    example = Path(__file__).parent.parent / "examples" / "rfq_kernel_os_flow.json"
    payload = json.loads(example.read_text(encoding="utf-8"))

    if len(sys.argv) > 1:
        payload["userQuery"] = " ".join(sys.argv[1:])

    request = ExecutionRequest(**payload)
    container = KernelContainer()
    await container.bootstrap()
    response = await container.kernel.execute(request)

    print("=" * 72)
    print("AI KERNEL — ExecutionResponse to backend")
    print("=" * 72)
    print(f"Execution ID:   {response.execution_id}")
    print(f"Status:         {response.status}")
    print(f"ExecutionState: {response.execution_state}")
    print(f"Started On:     {response.started_on}")
    print(f"Completed On:   {response.completed_on}")
    print(f"Final Response: {response.final_response}")

    print("\nActivity Logs")
    print("-" * 72)
    for i, log in enumerate(response.activity_logs[:15], 1):
        print(f"{i:02d}. [{log.engine or 'kernel'}] {log.action} — {log.status}")

    if response.agent:
        print("\nAgent")
        print(f"  ID:     {response.agent.agent_id}")
        print(f"  Name:   {response.agent.agent_name}")
        print(f"  Models: {len(response.agent.model_logs)}  Tools: {len(response.agent.tool_logs)}")
        print(f"  Memory: {len(response.agent.memory_logs)}  Knowledge: {len(response.agent.knowledge_logs)}")

    print("\nExecution Metrics")
    m = response.execution_metrics
    print(f"  Duration: {m.execution_time}ms  Model calls: {m.total_model_calls}  Tool calls: {m.total_tool_calls}")

    out = Path("examples") / "last_kernel_os_response.json"
    out.write_text(json.dumps(response.model_dump(by_alias=True), indent=2), encoding="utf-8")
    print(f"\nSaved: {out}")


if __name__ == "__main__":
    asyncio.run(main())
