import asyncio
import json
import sys
from pathlib import Path

from ai_os.app.api.dependencies import KernelContainer
from ai_os.app.config.settings import Settings
from ai_os.app.domain.models.execution import ExecutionRequest


def build_request(query: str, enable_orchestration: bool = False) -> ExecutionRequest:
    return ExecutionRequest(
        sessionId="SESSION-LIVE",
        userId="USER-LIVE",
        userQuery=query,
        agent={
            "agentId": "AGENT-LIVE",
            "name": "Live Query Agent",
            "enabled": True,
            "subAgents": [],
        },
        executionOptions={
            "saveMemory": enable_orchestration,
            "enableKnowledge": enable_orchestration,
            "enablePlanning": enable_orchestration,
            "enableSupervisor": enable_orchestration,
            "debugMode": True,
        },
    )


def print_trace(response) -> None:
    print("\nKERNEL ROUTING TRACE")
    print("-" * 72)
    for i, log in enumerate(response.activity_logs, 1):
        print(f"{i:02d}. [{log.get('step')}] {log.get('message')}")
        if log.get("engineId"):
            print(f"     engine={log['engineId']}")
        if log.get("nextIntents"):
            print(f"     nextIntents={log['nextIntents']}")
        if log.get("resultSummary"):
            print(f"     result={log['resultSummary']}")
    print("-" * 72)
    print(f"Status:         {response.status}")
    print(f"Final Response: {response.final_response}")
    if response.execution_summary:
        print(f"Engines Used:   {response.execution_summary.engines_used}")
        print(f"Capabilities:   {response.execution_summary.capabilities_used}")


async def main() -> None:
    args = sys.argv[1:]
    enable_orchestration = "--orchestrate" in args
    if enable_orchestration:
        args = [arg for arg in args if arg != "--orchestrate"]

    query = " ".join(args).strip() if args else input("Enter your query: ").strip()
    if not query:
        print("No query provided.")
        return

    settings = Settings()
    if not settings.supervisor_model_api_key:
        print("ERROR: Set SUPERVISOR_MODEL_API_KEY in .env for dynamic query testing.")
        print("Copy .env.example to .env and add your key.")
        sys.exit(1)

    print("=" * 72)
    print("AI KERNEL - DYNAMIC QUERY TEST")
    print("=" * 72)
    print(f"Model:          {settings.supervisor_model_name}")
    print(f"Orchestration:  {enable_orchestration}")
    print(f"Query:          {query}")

    container = KernelContainer(settings=settings)
    await container.bootstrap()

    caps = container.capability_registry.list_capabilities()
    resources = container.resource_registry.list_resource_types()
    print(f"\nRegistered capabilities: {caps}")
    print(f"Registered resources:    {resources}")

    response = await container.kernel.execute(build_request(query, enable_orchestration))
    print_trace(response)

    out = Path("examples") / "last_dynamic_response.json"
    out.write_text(json.dumps(response.model_dump(by_alias=True), indent=2), encoding="utf-8")
    print(f"\nFull response saved to: {out}")


if __name__ == "__main__":
    asyncio.run(main())
