from datetime import datetime

from ai_os.app.domain.models.execution import ExecutionContext
from ai_os.app.domain.models.execution_state import ExecutionState
from ai_os.app.domain.models.kernel_output import (
    ActivityLog,
    AgentResponse,
    Artifact,
    ExecutionMetrics,
    ExecutionResponse,
    ExecutionSummary,
    KnowledgeLogEntry,
    MemoryLogEntry,
    ModelLogEntry,
    SubAgentResponse,
    ToolLogEntry,
)


class ResponseBuilder:
    def build_execution_response(self, context: ExecutionContext) -> ExecutionResponse:
        duration_ms = self._duration_ms(context)
        execution_metrics = self._build_execution_metrics(context, duration_ms)
        activity_logs = self._build_activity_logs(context)
        agent = self._build_agent_response(context, execution_metrics)

        return ExecutionResponse(
            executionId=context.execution_id,
            sessionId=context.session_id,
            memoryId=context.memory_id,
            status=context.current_state.value,
            startedOn=context.started_at,
            completedOn=context.completed_at,
            finalResponse=context.final_response,
            artifacts=self._build_artifacts(context),
            agent=agent,
            activityLogs=activity_logs,
            stepResults=context.step_results,
            warnings=context.warnings,
            errors=context.errors,
            executionMetrics=execution_metrics,
            executionState=context.current_state.value,
        )

    def _duration_ms(self, context: ExecutionContext) -> float | None:
        if not context.started_at or not context.completed_at:
            return None
        start_dt = datetime.fromisoformat(context.started_at)
        end_dt = datetime.fromisoformat(context.completed_at)
        return (end_dt - start_dt).total_seconds() * 1000

    def _build_execution_metrics(self, context: ExecutionContext, duration_ms: float | None) -> ExecutionMetrics:
        total_tokens = sum(m.input_tokens + m.output_tokens for m in context.model_logs)
        # Sum only known costs — a model_log with cost=None (unpriced model,
        # see pricing.py) contributes nothing rather than being treated as
        # $0, and totalCost stays None (not 0.0) if NO call had a known
        # price, so "no cost data" is never confused with "free".
        known_costs = [m.cost for m in context.model_logs if m.cost is not None]
        return ExecutionMetrics(
            executionTime=duration_ms,
            modelTime=sum(m.latency or 0 for m in context.model_logs) or None,
            knowledgeTime=sum(k.latency or 0 for k in context.knowledge_logs) or None,
            memoryTime=None,
            toolTime=sum(t.duration or 0 for t in context.tool_logs) or None,
            totalTokens=total_tokens,
            totalCost=sum(known_costs) if known_costs else None,
            totalToolCalls=len(context.tool_logs),
            totalModelCalls=len(context.model_logs),
        )

    def _build_activity_logs(self, context: ExecutionContext) -> list[ActivityLog]:
        logs: list[ActivityLog] = []

        for entry in context.activity_logs:
            logs.append(
                ActivityLog(
                    timeStamp=entry.get("timestamp", ""),
                    engine=entry.get("engineId"),
                    action=entry.get("step", "KERNEL_ACTION"),
                    status=entry.get("status", "SUCCESS"),
                    duration=entry.get("duration"),
                    message=entry.get("message", ""),
                )
            )

        for step in context.execution_logs:
            # Use `or` rather than dict.get(key, default) — these keys may be
            # present with an explicit None value, which .get()'s default
            # would not catch, and ActivityLog.action requires a str.
            action = step.get("stepName") or step.get("stepId") or "ENGINE_CALL"
            message = step.get("outputData")
            if message is None:
                message = step.get("stepId") or ""
            logs.append(
                ActivityLog(
                    timeStamp=context.started_at or "",
                    engine=step.get("engineName"),
                    action=action,
                    status=step.get("status", "SUCCESS"),
                    duration=step.get("duration"),
                    message=str(message)[:500],
                )
            )

        return logs

    def _build_artifacts(self, context: ExecutionContext) -> list[Artifact]:
        artifacts: list[Artifact] = []
        for i, raw in enumerate(context.artifacts):
            artifacts.append(
                Artifact(
                    artifactId=raw.get("artifactId", raw.get("id", f"ART-{i}")),
                    artifactType=raw.get("artifactType", raw.get("type", "document")),
                    name=raw.get("name", raw.get("artifactName", "")),
                    location=raw.get("location", raw.get("storagePath")),
                    createdBy=raw.get("createdBy", context.agent.agent_id),
                    createdOn=raw.get("createdOn", context.completed_at),
                    version=raw.get("version"),
                )
            )
        return artifacts

    def _build_model_logs(self, context: ExecutionContext) -> list[ModelLogEntry]:
        return [
            ModelLogEntry(
                provider=m.model_provider,
                model=m.model_name,
                promptTokens=m.input_tokens,
                completionTokens=m.output_tokens,
                latency=m.latency,
                cost=m.cost,
                retryCount=context.retry_count,
                finishReason=m.finish_reason,
            )
            for m in context.model_logs
        ]

    def _build_tool_logs(self, context: ExecutionContext) -> list[ToolLogEntry]:
        return [
            ToolLogEntry(
                toolName=t.tool_name,
                action=t.operation,
                inputSummary=t.parameters_summary,
                outputSummary=t.error or "SUCCESS",
                status=t.status,
                duration=t.duration,
            )
            for t in context.tool_logs
        ]

    def _build_memory_logs(self, context: ExecutionContext) -> list[MemoryLogEntry]:
        return [
            MemoryLogEntry(
                operation=m.operation,
                memoryType=m.memory_type,
                source=context.session_id,
                status=m.status,
                recordsRetrieved=m.records_read,
                recordsStored=m.records_written,
            )
            for m in context.memory_logs
        ]

    def _build_knowledge_logs(self, context: ExecutionContext) -> list[KnowledgeLogEntry]:
        return [
            KnowledgeLogEntry(
                knowledgeSource=k.source,
                query=k.query,
                documentRetrieved=k.documents_retrieved,
                chunksRetrieved=k.chunks_retrieved,
                status=k.status,
                duration=k.latency,
            )
            for k in context.knowledge_logs
        ]

    def _build_execution_summary(self, context: ExecutionContext, duration_ms: float | None) -> ExecutionSummary:
        workflow = context.workflow_plan if isinstance(context.workflow_plan, dict) else {}
        return ExecutionSummary(
            goal=context.strategy.get("goal") or context.user_query,
            workflowName=workflow.get("name") or workflow.get("workflowName"),
            executionType="AGENT" if context.execution_options.enable_agent else "KERNEL",
            status=context.current_state.value,
            completedTasks=context.steps_executed,
            failedTasks=len(context.failed_requests),
            totalAgents=1 if context.agent else 0,
            totalSubAgents=len(context.agent.sub_agents) if context.agent else 0,
            totalToolsUsed=len(context.tool_logs),
            totalModelsUsed=len(context.model_logs),
            executionDuration=duration_ms,
            startedOn=context.started_at,
            completedOn=context.completed_at,
            completedReason=context.strategy.get("validation", {}).get("reason")
            if isinstance(context.strategy.get("validation"), dict)
            else None,
            finalMessage=str(context.final_response) if context.final_response else None,
        )

    def _build_sub_agents(self, context: ExecutionContext) -> list[SubAgentResponse]:
        sub_agents: list[SubAgentResponse] = []
        for sub in context.agent.sub_agents:
            sub_id = sub.sub_agent_id if hasattr(sub, "sub_agent_id") else sub.get("subAgentId", "")
            sub_name = sub.name if hasattr(sub, "name") else sub.get("name", "")
            result = context.sub_agent_results.get(sub_id, {})
            sub_agents.append(
                SubAgentResponse(
                    subAgentId=sub_id,
                    subAgentName=sub_name,
                    status=result.get("status", "COMPLETED"),
                    response=result.get("response"),
                )
            )
        return sub_agents

    def _build_agent_response(
        self, context: ExecutionContext, metrics: ExecutionMetrics
    ) -> AgentResponse | None:
        if not context.agent:
            return None

        duration_ms = metrics.execution_time
        status = (
            ExecutionState.FAILED.value
            if context.current_state == ExecutionState.FAILED
            else ExecutionState.COMPLETED.value
        )

        return AgentResponse(
            agentId=context.agent.agent_id,
            agentName=context.agent.name,
            status=status,
            executionTime=duration_ms,
            response=context.final_response,
            executionSummary=[self._build_execution_summary(context, duration_ms)],
            executionMetrics=metrics,
            modelLogs=self._build_model_logs(context),
            toolLogs=self._build_tool_logs(context),
            memoryLogs=self._build_memory_logs(context),
            knowledgeLogs=self._build_knowledge_logs(context),
            subAgents=self._build_sub_agents(context),
        )
