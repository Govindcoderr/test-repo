import uuid
from datetime import datetime, timezone
from typing import Any

from ai_os.app.domain.interfaces.observability import ObservabilityService
from ai_os.app.domain.interfaces.repository import ExecutionRepository, EventRepository
from ai_os.app.domain.models.agent import AgentDefinition
from ai_os.app.domain.models.events import KernelEventType
from ai_os.app.domain.models.execution import ExecutionContext, ExecutionOptions, ExecutionRequest
from ai_os.app.domain.models.execution_state import ExecutionState, can_transition
from ai_os.app.domain.models.metadata import RequestMetadata
from ai_os.app.domain.models.permissions import Permissions
from ai_os.app.kernel.errors.kernel_errors import ErrorType, KernelError, KernelException


class ExecutionManager:
    def __init__(
        self,
        execution_repository: ExecutionRepository,
        event_repository: EventRepository,
        observability: ObservabilityService,
    ) -> None:
        self._execution_repository = execution_repository
        self._event_repository = event_repository
        self._observability = observability

    def _normalize_metadata(self, metadata: RequestMetadata | dict[str, Any]) -> dict[str, Any]:
        if isinstance(metadata, RequestMetadata):
            return metadata.model_dump(by_alias=True, exclude_none=True)
        return metadata or {}

    async def create_execution(self, request: ExecutionRequest) -> ExecutionContext:
        execution_id = request.execution_id or f"EXE-{uuid.uuid4().hex[:8].upper()}"
        now = request.request_timestamp or datetime.now(timezone.utc).isoformat()

        agent = request.agent_definition or AgentDefinition(
            agentId="KERNEL-OS", name="Kernel OS Runtime", enabled=True
        )
        permissions = agent.permissions or []

        model_config = None
        if agent.model_configuration:
            model_config = agent.model_configuration.model_dump(by_alias=True)

        runtime = request.runtime_configuration
        execution_options = request.execution_options
        if runtime.debug_mode:
            execution_options.debug_mode = True

        context = ExecutionContext(
            executionId=execution_id,
            sessionId=request.session_id,
            userId=request.user_id,
            tenantId=request.tenant_id,
            parentExecutionId=request.parent_execution_id,
            correlationId=request.correlation_id or execution_id,
            requestTimeStamp=now,
            agent=agent,
            subAgents=[s.model_dump(by_alias=True) for s in agent.sub_agents],
            userQuery=request.user_query,
            attachments=request.attachments,
            executionOptions=execution_options,
            metadata=self._normalize_metadata(request.metadata),
            memoryId=request.memory_id,
            permissions=permissions,
            runtimeConfiguration=runtime,
            modelConfiguration=model_config,
            currentState=ExecutionState.CREATED,
            startedAt=now,
        )

        await self._execution_repository.save_context(context)
        await self._observability.emit(
            KernelEventType.EXECUTION_CREATED,
            execution_id=execution_id,
            payload={
                "sessionId": request.session_id,
                "userId": request.user_id,
                "tenantId": request.tenant_id,
            },
        )
        return context

    async def load_execution(self, execution_id: str) -> ExecutionContext:
        context = await self._execution_repository.get_context(execution_id)
        if not context:
            raise KernelException(
                KernelError(
                    code="EXECUTION_NOT_FOUND",
                    message=f"Execution '{execution_id}' not found",
                    type=ErrorType.KERNEL_ERROR,
                    execution_id=execution_id,
                )
            )
        return context

    async def transition_state(self, context: ExecutionContext, new_state: ExecutionState) -> None:
        if not can_transition(context.current_state, new_state):
            raise KernelException(
                KernelError(
                    code="INVALID_STATE_TRANSITION",
                    message=f"Cannot transition from {context.current_state.value} to {new_state.value}",
                    type=ErrorType.STATE_ERROR,
                    execution_id=context.execution_id,
                )
            )
        context.current_state = new_state
        await self._execution_repository.save_context(context)
        await self._observability.emit(
            KernelEventType.STATE_CHANGED,
            execution_id=context.execution_id,
            payload={"from": context.current_state.value, "to": new_state.value},
        )

    async def complete_execution(self, context: ExecutionContext) -> None:
        context.completed_at = datetime.now(timezone.utc).isoformat()
        await self.transition_state(context, ExecutionState.COMPLETED)
        await self._execution_repository.save_context(context)
        await self._observability.emit(
            KernelEventType.EXECUTION_COMPLETED,
            execution_id=context.execution_id,
        )

    async def fail_execution(self, context: ExecutionContext, error: KernelError) -> None:
        context.errors.append(error.model_dump(by_alias=True))
        context.current_state = ExecutionState.FAILED
        context.completed_at = datetime.now(timezone.utc).isoformat()
        await self._execution_repository.save_context(context)
        await self._observability.emit(
            KernelEventType.EXECUTION_FAILED,
            execution_id=context.execution_id,
            payload={"error": error.model_dump(by_alias=True)},
        )

    async def update_context(self, context: ExecutionContext) -> None:
        await self._execution_repository.save_context(context)
