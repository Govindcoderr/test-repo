import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any, TypeVar

T = TypeVar("T")


@dataclass
class ScheduledTask:
    task_id: str
    operation: Callable[[], Awaitable[T]]
    dependencies: list[str] = field(default_factory=list)
    priority: int = 100


class ExecutionScheduler:
    async def run_sequential(self, operations: list[Callable[[], Awaitable[T]]]) -> list[T]:
        results: list[T] = []
        for op in operations:
            results.append(await op())
        return results

    async def run_parallel(self, operations: list[Callable[[], Awaitable[T]]]) -> list[T]:
        return list(await asyncio.gather(*[op() for op in operations]))

    async def run_with_dependencies(self, tasks: list[ScheduledTask]) -> dict[str, Any]:
        completed: dict[str, Any] = {}
        pending = {t.task_id: t for t in tasks}

        while pending:
            ready = [
                t for t in pending.values()
                if all(dep in completed for dep in t.dependencies)
            ]
            if not ready:
                raise RuntimeError("Circular dependency detected in scheduled tasks")

            results = await asyncio.gather(*[t.operation() for t in ready])
            for task, result in zip(ready, results):
                completed[task.task_id] = result
                del pending[task.task_id]

        return completed
