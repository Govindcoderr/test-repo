import uuid

from ai_os.app.domain.models.dispatch_plan import EngineDispatchItem
from ai_os.app.domain.models.execution import ExecutionContext
from ai_os.app.domain.models.kernel_request import (
    KernelRequest,
    Priority,
    RequestSource,
    RequestType,
    ResourceRef,
)


class IntentManager:
    """Creates KernelRequest objects from dispatch items.

    This is the kernel's request factory. It translates external dispatch
    descriptions into properly structured internal KernelRequest envelopes
    that the RequestDispatcher can route to engines.
    """

    def create_from_dispatch_item(self, context: ExecutionContext, item: EngineDispatchItem) -> KernelRequest:
        """Create a KernelRequest from an EngineDispatchItem.

        This is the primary method used by the kernel to convert dispatch
        instructions into routable requests.
        """
        request_id = f"REQ-{uuid.uuid4().hex[:8].upper()}"

        resource = None
        if item.resource:
            resource = ResourceRef(
                type=item.resource.get("type", ""),
                id=item.resource.get("id"),
                metadata=item.resource.get("metadata", {}),
            )

        return KernelRequest(
            requestId=request_id,
            executionId=context.execution_id,
            parentRequestId=None,
            correlationId=request_id,
            sessionId=context.session_id,
            source=RequestSource(type=item.source_type, id=item.source_id),
            requestType=RequestType(item.request_type),
            capability=item.capability,
            resource=resource,
            payload={
                "userQuery": context.user_query,
                **item.payload,
            },
            metadata={
                "stepId": item.step_id,
                "stepName": item.step_name,
            },
            timeout=item.timeout,
        )

    def create_capability_request(
        self,
        context: ExecutionContext,
        capability: str,
        payload: dict | None = None,
        source_type: str = "kernel",
        source_id: str = "ai-kernel",
    ) -> KernelRequest:
        """Create a capability request directly (used by engines or internal kernel calls)."""
        request_id = f"REQ-{uuid.uuid4().hex[:8].upper()}"
        return KernelRequest(
            requestId=request_id,
            executionId=context.execution_id,
            parentRequestId=None,
            correlationId=request_id,
            sessionId=context.session_id,
            source=RequestSource(type=source_type, id=source_id),
            requestType=RequestType.CAPABILITY_REQUEST,
            capability=capability,
            payload=payload or {"userQuery": context.user_query},
            metadata={},
            priority=Priority.NORMAL,
            timeout=30,
        )

    def create_resource_request(
        self,
        context: ExecutionContext,
        resource_type: str,
        resource_id: str | None = None,
        payload: dict | None = None,
        source_type: str = "kernel",
        source_id: str = "ai-kernel",
    ) -> KernelRequest:
        """Create a resource request directly."""
        request_id = f"REQ-{uuid.uuid4().hex[:8].upper()}"
        return KernelRequest(
            requestId=request_id,
            executionId=context.execution_id,
            parentRequestId=None,
            correlationId=request_id,
            sessionId=context.session_id,
            source=RequestSource(type=source_type, id=source_id),
            requestType=RequestType.RESOURCE_REQUEST,
            capability=None,
            resource=ResourceRef(type=resource_type, id=resource_id),
            payload=payload or {"userQuery": context.user_query},
            metadata={},
            priority=Priority.NORMAL,
            timeout=30,
        )
