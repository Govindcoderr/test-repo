from typing import Any

from ai_os.app.domain.interfaces.observability import ObservabilityService
from ai_os.app.domain.models.dispatch_plan import DispatchPlan, EngineDispatchItem
from ai_os.app.domain.models.execution import ExecutionContext, ExecutionRequest
from ai_os.app.domain.models.kernel_output import ExecutionResponse
from ai_os.app.domain.models.execution_state import ExecutionState
from datetime import datetime, timezone
from ai_os.app.domain.models.kernel_request import KernelRequest, RequestType
from ai_os.app.domain.models.kernel_response import KernelResponse, NextStep, ResponseStatus
from ai_os.app.kernel.errors.kernel_errors import ErrorType, KernelError, KernelException
from ai_os.app.kernel.execution.execution_manager import ExecutionManager
from ai_os.app.kernel.execution.execution_scheduler import ExecutionScheduler
from ai_os.app.kernel.intents.intent_manager import IntentManager
from ai_os.app.kernel.observability.execution_tracer import ExecutionTracer
from ai_os.app.kernel.orchestration.dispatch_plan_executor import DispatchPlanExecutor
from ai_os.app.kernel.policies.policy_manager import PolicyManager
from ai_os.app.kernel.registry.capability_registry import CapabilityRegistry
from ai_os.app.kernel.registry.resource_registry import ResourceRegistry
from ai_os.app.kernel.requests.request_correlator import ResponseCorrelator
from ai_os.app.kernel.response.response_builder import ResponseBuilder
from ai_os.app.kernel.routing.request_dispatcher import RequestDispatcher
from ai_os.app.infrastructure.memory.json_memory_store import JsonMemoryStore
from ai_os.app.infrastructure.notifications.notification_service import (
    LoggingNotificationService,
    NotificationService,
)
from ai_os.app.kernel.human_input.pending_input_registry import PendingInputRegistry


class AIKernel:
    """AI OS Kernel — central runtime that routes requests to engines.

    The kernel is a pure routing and dispatch layer (like an OS kernel).
    It does NOT contain business logic or intent recognition. It:

    - Creates execution context for tracking
    - Receives dispatch requests from the API or other engines
    - Resolves providers via capability/resource registries
    - Dispatches to the appropriate engine
    - Follows nextStep directives from engines to drive execution flow
    - Supports parallel dispatch when engines return nextSteps
    - Correlates responses back and builds the final output

    The execution flow is entirely engine-driven:
    1. Kernel dispatches to an initial engine (e.g. supervisor)
    2. Engine returns result + nextStep (what to call next)
    3. Kernel dispatches to that nextStep
    4. Repeat until an engine returns no nextStep (done)

    Engines are responsible for their own logic (intent recognition,
    planning, reasoning, etc.). The kernel simply connects them.
    """

    MAX_ITERATIONS = 100

    def __init__(
        self,
        execution_manager: ExecutionManager,
        intent_manager: IntentManager,
        request_dispatcher: RequestDispatcher,
        response_correlator: ResponseCorrelator,
        response_builder: ResponseBuilder,
        policy_manager: PolicyManager,
        scheduler: ExecutionScheduler,
        observability: ObservabilityService,
        dispatch_plan_executor: DispatchPlanExecutor,
        capability_registry: CapabilityRegistry,
        resource_registry: ResourceRegistry,
        tracer: ExecutionTracer | None = None,
        memory_store: JsonMemoryStore | None = None,
        pending_input_registry: PendingInputRegistry | None = None,
        notification_service: NotificationService | None = None,
        human_input_timeout_seconds: float = 300.0,
    ) -> None:
        self._execution_manager = execution_manager
        self._intent_manager = intent_manager
        self._dispatcher = request_dispatcher
        self._correlator = response_correlator
        self._response_builder = response_builder
        self._policy_manager = policy_manager
        self._scheduler = scheduler
        self._observability = observability
        self._dispatch_plan_executor = dispatch_plan_executor
        self._capability_registry = capability_registry
        self._resource_registry = resource_registry
        self._tracer = tracer or ExecutionTracer()
        # Dev-phase fallback memory store (see infrastructure/memory/). The
        # kernel calls this directly rather than dispatching a "memory.*"
        # capability, since no Memory engine exists yet. This is a
        # deliberate, temporary layering shortcut — once a real Memory
        # engine is built, MEMORY_REQUIRED_PREFIXES handling below should
        # be replaced with normal capability dispatch and this constructor
        # arg removed.
        self._memory_store = memory_store
        # Human-in-the-loop: in-process suspension registry + outbound
        # notifier — see kernel/human_input/pending_input_registry.py and
        # AIKernel._await_human_input. A single registry instance is
        # shared for the process's lifetime (same tier as memory_store).
        self._pending_input_registry = pending_input_registry or PendingInputRegistry()
        self._notification_service = notification_service or LoggingNotificationService()
        self._human_input_timeout_seconds = human_input_timeout_seconds

    def _enrich_platform_metadata(self, context: ExecutionContext) -> None:
        """Inject available platform capabilities and resources into context metadata."""
        context.metadata["platformCapabilities"] = self._capability_registry.list_capabilities()
        context.metadata["platformResources"] = self._resource_registry.list_resource_types()

    async def execute(self, execution_request: ExecutionRequest) -> ExecutionResponse:
        """Execute a full request lifecycle with dynamic engine-driven flow.

        The kernel determines the initial entry point based on execution options:
        - If enableSupervisor=true: starts with "supervisor.understand_goal"
        - If a dispatchPlan is provided in metadata: executes the static plan
        - Otherwise: no-op (returns empty execution)

        After the initial dispatch, the kernel follows nextStep directives
        from each engine response, creating a fully dynamic execution chain.

        This is the primary entry point for the /execute API endpoint.
        """
        context = await self._execution_manager.create_execution(execution_request)
        self._enrich_platform_metadata(context)
        if self._memory_store:
            context.memory_id = await self._memory_store.get_or_create_memory_id(context.memory_id)
        self._tracer.trace_execution_started(context)

        try:
            await self._execution_manager.transition_state(context, ExecutionState.INITIALIZING)
            await self._execution_manager.transition_state(context, ExecutionState.VALIDATING)

            if not await self._policy_manager.can_execute(context):
                raise KernelException(
                    KernelError(
                        code="EXECUTION_NOT_ALLOWED",
                        message="Execution not permitted by policy",
                        type=ErrorType.AUTHORIZATION_ERROR,
                        execution_id=context.execution_id,
                    )
                )

            await self._execution_manager.transition_state(context, ExecutionState.EXECUTING)

            # Determine execution mode
            initial_step = self._resolve_initial_step(context)

            if initial_step:
                # Dynamic engine-driven execution loop
                await self._execute_dynamic_loop(initial_step, context)
            else:
                # Static dispatch plan (backward compatible)
                dispatch_plan = context.metadata.get("dispatchPlan")
                if dispatch_plan:
                    plan = DispatchPlan(**dispatch_plan) if isinstance(dispatch_plan, dict) else dispatch_plan
                    await self._dispatch_plan_executor.execute(context, plan)

            await self._execution_manager.transition_state(context, ExecutionState.VALIDATING_RESULT)
            await self._execution_manager.complete_execution(context)
            self._tracer.trace_execution_completed(context)

        except KernelException as exc:
            await self._execution_manager.fail_execution(context, exc.error)
        except Exception as exc:
            await self._execution_manager.fail_execution(
                context,
                KernelError(
                    code="UNEXPECTED_ERROR",
                    message=str(exc),
                    type=ErrorType.KERNEL_ERROR,
                    execution_id=context.execution_id,
                ),
            )

        return self._response_builder.build_execution_response(context)

    def _resolve_initial_step(self, context: ExecutionContext) -> NextStep | None:
        """Determine the initial engine entry point based on execution options.

        Only starts a dynamic flow if the required capability is actually
        registered in the kernel. Otherwise returns None (use static plan or no-op).
        """
        # Check for explicit initial step in metadata
        initial = context.metadata.get("initialStep")
        if initial:
            return NextStep(**initial) if isinstance(initial, dict) else initial

        # If supervisor is enabled AND registered, start with supervisor
        if context.execution_options.enable_supervisor and self._capability_registry.is_available(
            "supervisor.understand_goal"
        ):
            return NextStep(
                capability="supervisor.understand_goal",
                payload={
                    "userQuery": context.user_query,
                    "agentDefinition": context.agent.model_dump(by_alias=True) if context.agent else None,
                    "attachments": [a.model_dump(by_alias=True) for a in context.attachments],
                    "executionOptions": context.execution_options.model_dump(by_alias=True),
                },
            )

        # If agent is enabled AND registered, start with agent runtime
        if context.execution_options.enable_agent and self._capability_registry.is_available(
            "agent.spawn_workers"
        ):
            return NextStep(
                capability="agent.spawn_workers",
                payload={
                    "userQuery": context.user_query,
                    "agentDefinition": context.agent.model_dump(by_alias=True) if context.agent else None,
                    "subAgents": context.sub_agents,
                },
            )

        # No dynamic flow — use static dispatch plan or no-op
        return None

    # Capability that every workflow must pass through before returning to
    # the user — both on the happy path (engines chain to it themselves)
    # and as the kernel's forced fallback when something breaks mid-flow.
    VALIDATION_CAPABILITY = "supervisor.validate_result"

    # Capability prefixes that require conversation memory to be loaded
    # before dispatch and saved after — i.e. "conversational" engines
    # (Supervisor, Planning, worker/Agent Runtime). Engines outside this
    # map (tool.*, knowledge.*) are not memory-aware; knowledge retrieval
    # is a separate, engine-initiated concern, not kernel-mandated memory.
    #
    # Maps capability prefix -> agent key used to partition the fallback
    # memory store (see infrastructure/memory/json_memory_store.py).
    MEMORY_REQUIRED_PREFIXES: dict[str, str] = {
        "supervisor.": "supervisor",
        "planning.": "planning",
        "agent.": "workers",
    }

    def _memory_agent_key(self, capability: str | None) -> str | None:
        """Return the memory partition key for a capability, or None if not memory-required."""
        if not capability:
            return None
        for prefix, agent_key in self.MEMORY_REQUIRED_PREFIXES.items():
            if capability.startswith(prefix):
                return agent_key
        return None

    # ─── Task-dependency resolution (prepared for Agent Runtime) ──────────
    #
    # Planning's output (planning.create_plan's "workflow") now includes,
    # per task: dependsOn, inputContract, executionSteps, outputContract
    # (see infrastructure/engines/Planning/schemas.py::PlannedTask). Once
    # Agent Runtime exists and starts dispatching individual tasks from
    # that workflow, this is the mechanism that connects a task's declared
    # dependencies to its dependents' actual runtime input — the concrete
    # implementation of "return the result to the kernel so it can pass it
    # to the next dependent task."
    #
    # The intended flow, once Agent Runtime dispatches a task:
    #   1. Agent Runtime's dispatched NextStep for a task carries the
    #      task's own taskId and dependsOn list in its payload (mirroring
    #      the shape already present in the workflow Planning produced).
    #   2. Before dispatching that step, the kernel (in _dispatch_step,
    #      alongside the existing memory-injection logic) calls
    #      _resolve_task_dependencies(task_payload, context) to look up
    #      each dependency's stored result from context.task_results and
    #      inject them into the payload as `dependencyResults`.
    #   3. After the worker responds, the kernel calls
    #      context.record_task_result(task_id, result) so later tasks that
    #      depend on this one can resolve it in turn.
    #
    # Not yet wired into _dispatch_step/_resolve_next_step because no
    # engine dispatches task-level NextSteps yet — this method exists so
    # that plumbing is ready and doesn't need to be redesigned later.
    def _resolve_task_dependencies(
        self, task_payload: dict, context: ExecutionContext
    ) -> dict[str, Any]:
        """Look up a task's declared dependencies' results by taskId.

        `task_payload` is expected to carry `dependsOn: list[str]` (the
        same task IDs Planning assigned). Returns a dict suitable for
        injection as `payload["dependencyResults"]`, mapping each
        dependency's taskId to whatever result was recorded for it via
        context.record_task_result(). Dependencies with no recorded result
        yet (shouldn't happen if the DAG's execution order is respected,
        but guarded against) are simply omitted rather than raising.
        """
        depends_on = task_payload.get("dependsOn", [])
        return {
            dep_id: context.task_results[dep_id]
            for dep_id in depends_on
            if dep_id in context.task_results
        }

    # Capabilities that receive the literal, unmodified user query as their
    # input — i.e. the actual entry points a human's words reach directly.
    # Everything else that's memory-required (supervisor.validate_result,
    # supervisor.monitor_execution, agent.* workers, etc.) is invoked with
    # kernel- or engine-constructed input (error summaries, merged results,
    # revision briefs...) that was never something the user typed, so its
    # turn is recorded with role "system" rather than "human".
    HUMAN_TURN_CAPABILITIES: set[str] = {
        "supervisor.understand_goal",
        "planning.create_plan",
    }

    # Capabilities whose COMPLETION triggers a mid-workflow monitoring
    # checkpoint — i.e. "Planning just produced a plan; sanity-check it
    # before executing." This is deliberately narrow (checkpoints, not a
    # gate on every step) — see AIKernel._run_monitoring_checkpoint and the
    # hybrid monitoring design: cheap deterministic checks run on every
    # step regardless, but the LLM-based supervisor.monitor_execution call
    # is reserved for these specific checkpoints.
    MONITOR_CHECKPOINT_CAPABILITIES: set[str] = {
        "planning.create_plan",
    }

    # Only run the (LLM-costing) monitoring checkpoint when the workflow's
    # own complexity rating (set by supervisor.understand_goal) is at or
    # above this set. Simple/low-complexity workflows skip checkpoints
    # entirely — the final supervisor.validate_result gate still applies
    # regardless, so nothing goes unchecked, it's just not double-checked
    # mid-flight for cheap queries.
    MONITOR_COMPLEXITY_LEVELS: set[str] = {"medium", "high"}

    async def _execute_dynamic_loop(self, initial_step: NextStep, context: ExecutionContext) -> None:
        """Execute the dynamic engine-driven loop.

        Dispatches to the initial engine, then follows nextStep/nextSteps
        directives from each response until an engine returns no next step.

        If an engine fails, or the request fails to dispatch entirely (e.g.
        no provider registered, timeout, retries exhausted), the loop does
        NOT simply abort. Instead it force-routes to
        `supervisor.validate_result` with the error context attached, so
        Supervisor always gets the final say on what — if anything — is
        returned to the user. This only happens once per failure chain; if
        validate_result itself is the step that fails, or is unreachable,
        the kernel gives up and lets the failure propagate as a real abort
        (see _handle_break).
        """
        current_step: NextStep | None = initial_step

        while current_step and context.iteration_count < self.MAX_ITERATIONS:
            context.iteration_count += 1

            try:
                response = await self._dispatch_step(current_step, context)
            except KernelException as exc:
                current_step = self._handle_break(
                    context,
                    failed_capability=current_step.capability,
                    error_details={"code": exc.error.code, "message": exc.error.message},
                )
                if current_step is None:
                    raise
                continue

            if response.status == ResponseStatus.FAILURE:
                current_step = self._handle_break(
                    context,
                    failed_capability=current_step.capability,
                    error_details={"errors": response.errors},
                )
                if current_step is None:
                    break
                continue

            # Human-in-the-loop: a worker signals it needs input/approval
            # before this task can actually be considered done, by setting
            # result["humanInputRequired"]. The worker has NOT completed
            # its task yet — the kernel suspends itself in-place (NOT the
            # whole HTTP request; execute() is expected to be run as a
            # background task by the caller for this to be meaningful) and
            # waits, then re-dispatches the SAME step (same capability,
            # same payload) with the human's answer merged in — or, if the
            # timeout elapses first, re-dispatches it with a marker noting
            # no answer was received, per the project's "continue without
            # approval after N minutes" design. See _await_human_input.
            human_input_signal = (response.result or {}).get("humanInputRequired") if response.result else None
            if human_input_signal:
                current_step = await self._await_human_input(human_input_signal, current_step, context)
                continue

            # Record step result for subsequent engines
            completed_capability = current_step.capability or "unknown"
            context.record_step_result(completed_capability, response.result or {})

            # Determine what's next
            next_step = await self._resolve_next_step(response, context)

            # Mid-workflow monitoring checkpoint — only for specific
            # capability completions, and only when complexity warrants it.
            # See MONITOR_CHECKPOINT_CAPABILITIES / MONITOR_COMPLEXITY_LEVELS.
            if next_step and self._should_checkpoint(completed_capability, context):
                next_step = await self._run_monitoring_checkpoint(
                    completed_capability, response.result or {}, next_step, context
                )

            current_step = next_step

        # Safety check: if we hit max iterations, record a warning
        if context.iteration_count >= self.MAX_ITERATIONS:
            context.warnings.append(
                f"Execution loop reached maximum iterations ({self.MAX_ITERATIONS})"
            )

        await self._execution_manager.update_context(context)

    def _handle_break(
        self,
        context: ExecutionContext,
        failed_capability: str | None,
        error_details: dict,
    ) -> NextStep | None:
        """Decide how to respond when a step fails (engine failure or dispatch error).

        Returns a NextStep pointing at supervisor.validate_result to force a
        graceful, Supervisor-mediated response instead of a hard abort — or
        None if the kernel should give up and let the failure propagate as
        a real abort. The latter happens when:
        - the step that just failed WAS validate_result itself (nothing left
          to fall back to), or
        - validate_result isn't even registered in this kernel.
        """
        context.warnings.append(
            f"Step '{failed_capability}' failed; routing to {self.VALIDATION_CAPABILITY} for review."
        )

        if failed_capability == self.VALIDATION_CAPABILITY:
            return None
        if not self._capability_registry.is_available(self.VALIDATION_CAPABILITY):
            return None

        return self._build_validation_step(
            context, {**error_details, "failedCapability": failed_capability}
        )

    def _build_validation_step(self, context: ExecutionContext, error_details: dict) -> NextStep:
        """Build a NextStep that forces a supervisor.validate_result pass.

        Shared by _handle_break (engine/dispatch failures) and
        _run_monitoring_checkpoint (a monitoring checkpoint escalating a
        concern) — both cases need Supervisor to make the final call
        instead of the workflow continuing or aborting silently.
        """
        context.forced_validation = True
        return NextStep(
            capability=self.VALIDATION_CAPABILITY,
            payload={
                "userQuery": context.user_query,
                "strategy": context.strategy,
                "errorDetails": error_details,
                "executionContext": {
                    "stepResults": context.step_results,
                    "strategy": context.strategy,
                    "revisionCount": context.revision_count,
                },
            },
        )

    def _should_checkpoint(self, completed_capability: str, context: ExecutionContext) -> bool:
        """Decide whether a mid-workflow monitoring checkpoint should run.

        Checkpoints are reserved for specific capability completions (see
        MONITOR_CHECKPOINT_CAPABILITIES) and only fire when the workflow's
        own complexity rating (set by supervisor.understand_goal) warrants
        the extra LLM call — cheap/low-complexity workflows skip checkpoints
        entirely and rely on the mandatory final validate_result gate.
        """
        if completed_capability not in self.MONITOR_CHECKPOINT_CAPABILITIES:
            return False
        if not self._capability_registry.is_available("supervisor.monitor_execution"):
            return False
        complexity = context.strategy.get("complexity", "medium")
        return complexity in self.MONITOR_COMPLEXITY_LEVELS

    def _deterministic_concerns(self, pending_step: NextStep, context: ExecutionContext) -> list[str]:
        """Cheap, non-LLM checks run before every monitoring checkpoint.

        Currently checks whether a pending tool.* step names a tool outside
        the executing agent's declared allowed_tools. This is a best-effort
        check — Agent Runtime/Tool engines don't exist yet, so the payload
        shape this expects (a "tool" or "toolName" key) is speculative and
        should be revisited once those engines define their real contract.
        Returns a list of human-readable concern strings (empty if none).
        """
        concerns: list[str] = []
        capability = pending_step.capability or ""
        if capability.startswith("tool."):
            requested_tool = pending_step.payload.get("tool") or pending_step.payload.get("toolName")
            allowed = context.agent.allowed_tools if context.agent else []
            allowed_names = {a if isinstance(a, str) else a.get("name") for a in allowed}
            if requested_tool and allowed_names and requested_tool not in allowed_names:
                concerns.append(
                    f"Requested tool '{requested_tool}' is not in the executing agent's allowed_tools."
                )
        return concerns

    async def _run_monitoring_checkpoint(
        self,
        checkpoint_capability: str,
        checkpoint_result: dict,
        pending_next_step: NextStep,
        context: ExecutionContext,
    ) -> NextStep:
        """Run a mid-workflow monitoring checkpoint and act on its verdict.

        Dispatches supervisor.monitor_execution directly (not as part of
        the normal next_step chain) with what just happened and what's
        about to happen next. On "continue", returns pending_next_step
        unchanged. On "escalate", returns a forced supervisor.validate_result
        step instead. If the checkpoint call itself fails for any reason,
        this fails open — logs a warning and continues with the pending
        step rather than blocking the workflow on a monitoring failure.
        """
        kernel_concerns = self._deterministic_concerns(pending_next_step, context)

        checkpoint_step = NextStep(
            capability="supervisor.monitor_execution",
            payload={
                "strategy": context.strategy,
                "checkpointCapability": checkpoint_capability,
                "checkpointResult": checkpoint_result,
                "stepResults": context.step_results,
                "pendingNextStep": {
                    "capability": pending_next_step.capability,
                    "payload": pending_next_step.payload,
                },
                "kernelConcerns": kernel_concerns,
            },
        )

        try:
            response = await self._dispatch_step(checkpoint_step, context)
        except KernelException as exc:
            context.warnings.append(f"Monitoring checkpoint failed to dispatch: {exc.error.message}")
            return pending_next_step

        if response.status != ResponseStatus.SUCCESS:
            context.warnings.append("Monitoring checkpoint did not succeed; continuing without it.")
            return pending_next_step

        # Recorded for traceability (visible in ExecutionResponse.stepResults)
        # even though this checkpoint isn't part of the main next_step chain.
        context.record_step_result("supervisor.monitor_execution", response.result or {})

        verdict = (response.result or {}).get("monitorVerdict", {})
        decision = verdict.get("decision")

        if decision == "escalate":
            context.warnings.append(
                f"Monitoring checkpoint after '{checkpoint_capability}' escalated: "
                f"{verdict.get('feedback', '')}"
            )
            return self._build_validation_step(
                context,
                {
                    "reason": "monitoring_checkpoint_escalation",
                    "checkpointCapability": checkpoint_capability,
                    "monitorFeedback": verdict.get("feedback", ""),
                    "monitorConcerns": verdict.get("concerns", []),
                    "kernelConcerns": kernel_concerns,
                },
            )

        return pending_next_step

    async def _await_human_input(
        self,
        signal: dict,
        blocked_step: NextStep,
        context: ExecutionContext,
    ) -> NextStep:
        """Suspend the execution in-place while a worker's task awaits a human.

        `signal` is the `humanInputRequired` payload a worker's result set —
        expected shape: {"question": str, "taskId": str | None}. This method:
        1. Registers a pending-input record and notifies the backend (via
           NotificationService — a separate HTTP service, per the project's
           architecture) that a human's input is needed.
        2. Transitions the execution to WAITING and `await`s the request's
           future DIRECTLY — this is the actual suspension. The coroutine
           running this loop is parked by the event loop, not destroyed;
           nothing is serialized. See PendingInputRegistry's docstring for
           the constraints this implies (single-process, no crash-safety).
        3. Waits up to `human_input_timeout_seconds` (default 300s / 5min
           per the project's decision). If the human answers in time, the
           answer is merged into the blocked step's payload as
           `humanInputAnswer` and the execution transitions WAITING ->
           RESUMING -> EXECUTING. If the timeout elapses first, the step is
           re-dispatched anyway with `humanInputTimedOut: true` instead —
           the worker decides for itself how to proceed without an answer.

        Per the project's decision to halt the whole execution while
        waiting (not let sibling branches continue), this is called
        directly in the main loop rather than only for the specific
        blocked branch — the entire dynamic loop pauses here.
        """
        question = signal.get("question", "Human input required.")
        task_id = signal.get("taskId")

        record = self._pending_input_registry.create(context.execution_id, task_id, question)
        context.pending_human_input = {
            "requestId": record.request_id,
            "taskId": task_id,
            "question": question,
            "raisedAt": datetime.now(timezone.utc).isoformat(),
        }
        await self._execution_manager.transition_state(context, ExecutionState.WAITING)
        await self._execution_manager.update_context(context)

        await self._notification_service.notify_human_input_required(
            execution_id=context.execution_id,
            request_id=record.request_id,
            task_id=task_id,
            question=question,
        )

        # The actual suspension — this coroutine (and everything it's
        # running as part of, i.e. the whole dynamic loop) is parked here
        # by the event loop until PendingInputRegistry.resolve() is called
        # (via the /human-input/{requestId} route) or the timeout elapses.
        answer = await self._pending_input_registry.wait_for_answer(
            record, timeout_seconds=self._human_input_timeout_seconds
        )

        context.pending_human_input = None
        await self._execution_manager.transition_state(context, ExecutionState.RESUMING)
        await self._execution_manager.transition_state(context, ExecutionState.EXECUTING)

        resumed_step = blocked_step.model_copy()
        # humanInputQuestion is echoed back alongside the answer/timeout so
        # whatever raised the request (any engine, not just Supervisor) can
        # recall what it originally asked without having to have stashed it
        # somewhere itself — the question only ever existed in the response
        # that triggered this pause, not in blocked_step's own payload.
        if answer is not None:
            resumed_step.payload = {
                **resumed_step.payload,
                "humanInputAnswer": answer,
                "humanInputQuestion": question,
            }
            context.warnings.append(
                f"Human input received for request '{record.request_id}'; resuming task '{task_id}'."
            )
        else:
            resumed_step.payload = {
                **resumed_step.payload,
                "humanInputTimedOut": True,
                "humanInputQuestion": question,
            }
            context.warnings.append(
                f"No human input received for request '{record.request_id}' within "
                f"{self._human_input_timeout_seconds:.0f}s; continuing task '{task_id}' without it."
            )
        await self._execution_manager.update_context(context)
        return resumed_step

    async def _resolve_next_step(self, response: KernelResponse, context: ExecutionContext) -> NextStep | None:
        """Determine the next step from an engine response.

        Handles three cases:
        1. nextStep (single) — dispatch one engine next
        2. nextSteps (parallel) — dispatch multiple engines, then afterParallel
        3. Neither — execution is complete
        """
        # Case 1: Parallel steps
        if response.next_steps:
            merged_results = await self._execute_parallel_steps(response.next_steps, context)

            # After parallel completion, continue with afterParallel directive
            if response.after_parallel:
                # Inject merged results into the afterParallel payload
                after_step = response.after_parallel.model_copy()
                after_step.payload = {
                    **after_step.payload,
                    "parallelResults": merged_results,
                    "previousResult": context.last_step_result,
                }
                return after_step

            return None

        # Case 2: Single next step
        if response.next_step:
            # supervisor.validate_result marks its needs_more_planning
            # hand-off with metadata.isRevisionLoop so the kernel can track
            # how many times the workflow has looped back to Planning.
            if response.next_step.metadata.get("isRevisionLoop"):
                context.revision_count += 1

            # Enrich the next step's payload with the previous result
            step = response.next_step.model_copy()
            step.payload = {
                **step.payload,
                "previousResult": response.result,
                "executionContext": {
                    "stepResults": context.step_results,
                    "memoryContext": context.memory_context,
                    "knowledgeContext": context.knowledge_context,
                    "toolResults": context.tool_results,
                    "workerStates": context.worker_states,
                    "strategy": context.strategy,
                    "workflowPlan": context.workflow_plan,
                    "revisionCount": context.revision_count,
                    # Advisory-only capability category catalog (name
                    # strings, not tool schemas) — see design decision:
                    # Planning may want to sanity-check feasibility against
                    # what's actually registered, but never receives tool-
                    # level definitions; those stay scoped to the worker
                    # that executes a task at runtime.
                    "platformCapabilities": context.metadata.get("platformCapabilities", []),
                },
            }
            return step

        # Case 3: No next step — done
        return None

    async def _execute_parallel_steps(
        self, steps: list[NextStep], context: ExecutionContext
    ) -> list[dict]:
        """Execute multiple steps in parallel and return their results."""

        async def _dispatch_one(step: NextStep):
            return await self._dispatch_step(step, context)

        responses = await self._scheduler.run_parallel(
            [lambda s=step: _dispatch_one(s) for step in steps]
        )

        merged_results = []
        for step, response in zip(steps, responses):
            capability = step.capability or "unknown"
            result = response.result or {}
            context.record_step_result(capability, result)
            merged_results.append({"capability": capability, "result": result})

        return merged_results

    async def _dispatch_step(self, step: NextStep, context: ExecutionContext) -> KernelResponse:
        """Dispatch a single NextStep through the kernel routing infrastructure.

        If the target capability is memory-required (see
        MEMORY_REQUIRED_PREFIXES), this loads that agent's prior
        conversation turns from the fallback memory store first, injects
        them into the step's payload, and — after a successful response —
        appends the new turn back into the store.
        """
        memory_agent_key = self._memory_agent_key(step.capability)
        payload = step.payload
        if memory_agent_key and self._memory_store and context.memory_id:
            memory_context = await self._memory_store.get_context(context.memory_id, memory_agent_key)
            payload = {
                **payload,
                "memoryId": context.memory_id,
                "memoryContext": memory_context,
            }

        # Convert NextStep to a dispatch item and route through the standard path
        request_type = "RESOURCE_REQUEST" if step.resource else "CAPABILITY_REQUEST"

        dispatch_item = EngineDispatchItem(
            requestType=request_type,
            capability=step.capability,
            resource=step.resource,
            payload=payload,
            sourceType="kernel",
            sourceId="execution-loop",
        )

        request = self._intent_manager.create_from_dispatch_item(context, dispatch_item)
        response = await self._dispatcher.dispatch(request, context)
        await self._correlator.correlate(response, context, request)

        if (
            memory_agent_key
            and self._memory_store
            and context.memory_id
            and response.status == ResponseStatus.SUCCESS
        ):
            await self._save_memory_turn(context.memory_id, memory_agent_key, step.capability, payload, response)

        return response

    async def _save_memory_turn(
        self,
        memory_id: str,
        agent_key: str,
        capability: str | None,
        payload: dict,
        response: KernelResponse,
    ) -> None:
        """Persist the input/AI turn for this step into the fallback memory store.

        Engines may return an explicit `result["conversationTurn"] =
        {"human": ..., "ai": ...}` (legacy/simple case, always treated as a
        human turn) or `result["conversationTurn"] = {"system": ..., "ai":
        ...}` to explicitly mark the input side as kernel/engine-generated
        rather than literal user input. If neither is provided, falls back
        to the dispatched userQuery as input and the response's
        finalResponse as the AI side.

        The role defaults based on `capability`: only capabilities in
        HUMAN_TURN_CAPABILITIES (the ones that receive the raw user query
        directly) are recorded as "human" turns by default — everything
        else defaults to "system", since its input was constructed by the
        kernel or a previous engine, not typed by the user.
        """
        result = response.result or {}
        turn = result.get("conversationTurn")
        default_role = "human" if capability in self.HUMAN_TURN_CAPABILITIES else "system"

        if isinstance(turn, dict):
            if "system" in turn:
                input_content = turn.get("system")
                input_role = "system"
            else:
                input_content = turn.get("human")
                input_role = default_role
            ai = turn.get("ai")
        else:
            input_content = payload.get("userQuery")
            input_role = default_role
            ai = result.get("finalResponse")

        if not self._memory_store:
            return
        await self._memory_store.append_turn(memory_id, agent_key, input_content, ai, input_role=input_role)

    # ─── Human-in-the-loop resolution (called by the /human-input route) ──

    def resolve_human_input(self, request_id: str, answer: dict) -> bool:
        """Deliver a human's answer to a pending human-input request.

        Called by the POST /api/v1/kernel/human-input/{requestId} route —
        this is the "backend calls back into the kernel" hop. Returns
        False if request_id is unknown or the request already resolved/
        timed out (e.g. answered after the 5-minute window), in which case
        the caller should surface a clear "too late or invalid" response.
        """
        return self._pending_input_registry.resolve(request_id, answer)

    # ─── Public dispatch methods (unchanged) ─────────────────────────────

    async def dispatch(
        self,
        dispatch_item: EngineDispatchItem,
        execution_id: str | None = None,
        session_id: str = "SESSION-DISPATCH",
        user_id: str = "USER-DISPATCH",
    ) -> KernelResponse:
        """Dispatch a single engine request through the kernel.

        This is the primary routing mechanism. Takes a dispatch item describing
        what capability or resource is needed, resolves the engine, dispatches,
        and returns the response.

        Can operate standalone (creates a temporary execution context) or
        within an existing execution (pass execution_id).
        """
        if execution_id:
            context = await self._execution_manager.load_execution(execution_id)
        else:
            context = await self._execution_manager.create_execution(
                ExecutionRequest(
                    sessionId=session_id,
                    userId=user_id,
                    userQuery="",
                )
            )
            self._enrich_platform_metadata(context)

        request = self._intent_manager.create_from_dispatch_item(context, dispatch_item)
        response = await self._dispatcher.dispatch(request, context)
        await self._correlator.correlate(response, context, request)
        await self._execution_manager.update_context(context)
        return response

    async def dispatch_plan(
        self,
        plan: DispatchPlan,
        execution_id: str | None = None,
        session_id: str = "SESSION-PLAN",
        user_id: str = "USER-PLAN",
    ) -> list[KernelResponse]:
        """Execute a multi-step dispatch plan through the kernel.

        A dispatch plan is a sequence of phases. Each phase is either a single
        engine call or a set of parallel engine calls. The kernel resolves and
        dispatches each step, accumulating results in the execution context.
        """
        if execution_id:
            context = await self._execution_manager.load_execution(execution_id)
        else:
            context = await self._execution_manager.create_execution(
                ExecutionRequest(
                    sessionId=session_id,
                    userId=user_id,
                    userQuery="",
                )
            )
            self._enrich_platform_metadata(context)

        responses = await self._dispatch_plan_executor.execute(context, plan)
        await self._execution_manager.update_context(context)
        return responses
