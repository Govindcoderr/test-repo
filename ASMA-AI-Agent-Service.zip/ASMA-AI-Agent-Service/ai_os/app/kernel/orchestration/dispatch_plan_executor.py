from ai_os.app.domain.models.dispatch_plan import DispatchPlan, EngineDispatchItem
from ai_os.app.domain.models.execution import ExecutionContext
from ai_os.app.domain.models.kernel_request import KernelRequest
from ai_os.app.domain.models.kernel_response import KernelResponse, ResponseStatus
from ai_os.app.kernel.execution.execution_scheduler import ExecutionScheduler
from ai_os.app.kernel.intents.intent_manager import IntentManager
from ai_os.app.kernel.requests.request_correlator import ResponseCorrelator
from ai_os.app.kernel.routing.request_dispatcher import RequestDispatcher


class DispatchPlanExecutor:
    """Executes backend-provided engine dispatch plans through the kernel."""

    def __init__(
        self,
        intent_manager: IntentManager,
        request_dispatcher: RequestDispatcher,
        response_correlator: ResponseCorrelator,
        scheduler: ExecutionScheduler,
    ) -> None:
        self._intent_manager = intent_manager
        self._dispatcher = request_dispatcher
        self._correlator = response_correlator
        self._scheduler = scheduler

    async def execute(self, context: ExecutionContext, plan: DispatchPlan) -> list[KernelResponse]:
        responses: list[KernelResponse] = []

        for phase in plan.phases:
            if "parallel" in phase:
                items = [EngineDispatchItem(**item) for item in phase["parallel"]]
                requests = [self._intent_manager.create_from_dispatch_item(context, item) for item in items]
                parallel_responses = await self._scheduler.run_parallel(
                    [lambda r=req: self._dispatch_and_correlate(r, context) for req in requests]
                )
                responses.extend(parallel_responses)
            else:
                item = EngineDispatchItem(**phase)
                request = self._intent_manager.create_from_dispatch_item(context, item)
                response = await self._dispatch_and_correlate(request, context)
                responses.append(response)

        if responses:
            last = responses[-1]
            if last.status == ResponseStatus.SUCCESS and last.result:
                context.final_response = (
                    last.result.get("finalResponse")
                    or last.result.get("response")
                    or last.result.get("result")
                    or str(last.result)
                )

        return responses

    async def _dispatch_and_correlate(self, request: KernelRequest, context: ExecutionContext) -> KernelResponse:
        response = await self._dispatcher.dispatch(request, context)
        return await self._correlator.correlate(response, context, request)
