from ai_os.app.domain.interfaces.engine import Engine
from ai_os.app.kernel.plugin_loader import PluginLoader
from ai_os.app.kernel.registry.engine_registry import EngineRegistry


class EngineFactory:
    @staticmethod
    def create_from_engines(engines: list[Engine]) -> list[Engine]:
        return engines

    @staticmethod
    async def bootstrap(plugin_loader: PluginLoader, engines: list[Engine]) -> None:
        plugin_loader.load_engines(engines)
        await plugin_loader.initialize_all()


class LifecycleManager:
    def __init__(self, plugin_loader: PluginLoader, engine_registry: EngineRegistry) -> None:
        self._plugin_loader = plugin_loader
        self._engine_registry = engine_registry

    async def startup(self, engines: list[Engine]) -> None:
        await EngineFactory.bootstrap(self._plugin_loader, engines)

    async def shutdown(self) -> None:
        await self._plugin_loader.shutdown_all()

    async def health_check_all(self) -> dict[str, bool]:
        results = {}
        for manifest in self._engine_registry.list_engines():
            results[manifest.engine_id] = await self._engine_registry.health_check(manifest.engine_id)
        return results
