from ai_os.app.domain.interfaces.engine import Engine
from ai_os.app.kernel.registry.capability_registry import CapabilityRegistry
from ai_os.app.kernel.registry.engine_registry import EngineRegistry
from ai_os.app.kernel.registry.resource_registry import ResourceRegistry


class PluginLoader:
    def __init__(
        self,
        engine_registry: EngineRegistry,
        capability_registry: CapabilityRegistry,
        resource_registry: ResourceRegistry,
    ) -> None:
        self._engine_registry = engine_registry
        self._capability_registry = capability_registry
        self._resource_registry = resource_registry

    def load_engine(self, engine: Engine) -> None:
        self._engine_registry.register(engine)
        manifest = engine.manifest
        self._capability_registry.register_from_engine_manifest(
            manifest.engine_id,
            manifest.capabilities,
            priority=manifest.priority,
        )
        self._resource_registry.register_from_engine_manifest(
            manifest.engine_id,
            manifest.resources,
            priority=manifest.priority,
        )

    def load_engines(self, engines: list[Engine]) -> None:
        for engine in engines:
            self.load_engine(engine)

    async def initialize_all(self) -> None:
        await self._engine_registry.initialize_all()

    async def shutdown_all(self) -> None:
        await self._engine_registry.shutdown_all()
