"""In-process human-in-the-loop suspension mechanism.

See pending_input_registry.py for the concrete implementation.
"""

from ai_os.app.kernel.human_input.pending_input_registry import (
    PendingInputRegistry,
    PendingInputTimeout,
)

__all__ = ["PendingInputRegistry", "PendingInputTimeout"]
