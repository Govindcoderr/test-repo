"""In-process registry for suspending and resuming a running execution
while it waits on a human's approval/input.

This is the mechanism behind the human-in-the-loop design: rather than
tearing an execution down and reconstructing it later from persisted
state, the kernel's dynamic loop simply `await`s an `asyncio.Future` right
where it is. The coroutine is suspended by the event loop — not destroyed
— so nothing needs to be serialized or rebuilt. When the human's answer
arrives (via the /human-input/{requestId} route) or the timeout elapses,
whichever comes first resolves the future and the SAME suspended coroutine
resumes exactly where it left off.

Constraints this implies (see AIKernel._await_human_input for how these
are respected):
- Single-process only: the Future lives in this process's memory. If the
  kernel ever runs as multiple replicas, the process that receives the
  human's answer must be the same one holding the suspended execution.
- A crash or restart loses any in-flight pause — there is nothing to
  reload, because nothing was written down. This is a deliberate trade
  documented in AIKernel; if that durability matters, this mechanism
  would need to be replaced with a persisted-checkpoint design instead.
"""

import asyncio
import time
import uuid
from dataclasses import dataclass, field
from typing import Any


class PendingInputTimeout(Exception):
    """Raised internally when a pending input's wait time is exhausted.

    Callers of `wait_for_answer` should generally prefer its return-value
    contract (returns None on timeout) rather than catching this directly
    — see wait_for_answer's docstring.
    """


@dataclass
class PendingInputRecord:
    """Metadata about a single outstanding human-input request.

    Kept separate from ExecutionContext because this is process-local,
    ephemeral coordination state (a Future can't be persisted), not part
    of the execution's durable data.
    """

    request_id: str
    execution_id: str
    task_id: str | None
    question: str
    raised_at: float = field(default_factory=time.time)
    future: "asyncio.Future[dict[str, Any] | None]" = field(default_factory=asyncio.Future)


class PendingInputRegistry:
    """Tracks outstanding human-input requests for the current process.

    One instance lives for the lifetime of the KernelContainer (see
    api/dependencies.py), shared by every execution running in this
    process — mirroring how JsonMemoryStore is a single, shared instance.
    """

    def __init__(self) -> None:
        self._pending: dict[str, PendingInputRecord] = {}

    def create(self, execution_id: str, task_id: str | None, question: str) -> PendingInputRecord:
        """Register a new pending input request and return its record.

        The caller (AIKernel) is responsible for awaiting `record.future`
        (via wait_for_answer, which also handles the timeout) and for
        eventually removing the record via `resolve`/`expire`.
        """
        request_id = f"HITL-{uuid.uuid4().hex[:12].upper()}"
        record = PendingInputRecord(
            request_id=request_id,
            execution_id=execution_id,
            task_id=task_id,
            question=question,
        )
        self._pending[request_id] = record
        return record

    def get(self, request_id: str) -> PendingInputRecord | None:
        return self._pending.get(request_id)

    def resolve(self, request_id: str, answer: dict[str, Any]) -> bool:
        """Deliver a human's answer to a pending request.

        Returns False if the request_id is unknown or was already
        resolved/timed out (e.g. the human answered after the 5-minute
        window already elapsed and the kernel moved on) — the caller
        (the /human-input route) should surface that as a clear "too late
        or invalid" response rather than silently succeeding.
        """
        record = self._pending.get(request_id)
        if record is None or record.future.done():
            return False
        record.future.set_result(answer)
        return True

    async def wait_for_answer(
        self, record: PendingInputRecord, timeout_seconds: float
    ) -> dict[str, Any] | None:
        """Suspend until the human answers or the timeout elapses.

        Returns the human's answer dict if resolved in time, or None if
        the timeout elapsed first — the None case is the expected,
        non-exceptional path for "continue without approval after N
        minutes" per the project's design, so callers should treat it as
        a normal outcome, not an error. Always cleans up the record from
        the registry before returning, regardless of outcome.
        """
        try:
            return await asyncio.wait_for(record.future, timeout=timeout_seconds)
        except asyncio.TimeoutError:
            return None
        finally:
            self._pending.pop(record.request_id, None)
