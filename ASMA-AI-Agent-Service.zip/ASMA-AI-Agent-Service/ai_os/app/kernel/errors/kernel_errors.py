from abc import ABC, abstractmethod
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

from ai_os.app.domain.models.execution import ExecutionContext
from ai_os.app.domain.models.kernel_request import KernelRequest
from ai_os.app.domain.models.kernel_response import KernelResponse
from ai_os.app.domain.models.engine import EngineManifest


class ErrorType(str, Enum):
    VALIDATION_ERROR = "VALIDATION_ERROR"
    PROVIDER_ERROR = "PROVIDER_ERROR"
    AUTHORIZATION_ERROR = "AUTHORIZATION_ERROR"
    TIMEOUT_ERROR = "TIMEOUT_ERROR"
    ENGINE_ERROR = "ENGINE_ERROR"
    KERNEL_ERROR = "KERNEL_ERROR"
    STATE_ERROR = "STATE_ERROR"


class KernelError(BaseModel):
    code: str
    message: str
    type: ErrorType
    source: str = "kernel"
    request_id: str | None = Field(default=None, alias="requestId")
    execution_id: str | None = Field(default=None, alias="executionId")
    retryable: bool = False
    details: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class KernelException(Exception):
    def __init__(self, error: KernelError):
        self.error = error
        super().__init__(error.message)
