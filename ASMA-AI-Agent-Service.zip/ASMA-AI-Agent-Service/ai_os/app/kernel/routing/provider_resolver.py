from ai_os.app.domain.models.engine import ProviderInfo, EngineStatus
from ai_os.app.kernel.errors.kernel_errors import ErrorType, KernelError, KernelException
from ai_os.app.kernel.policies.authorization import AuthorizationService
from ai_os.app.kernel.policies.policy_manager import PolicyManager
from ai_os.app.kernel.registry.engine_registry import EngineRegistry
from ai_os.app.kernel.routing.requirement import ProviderSelection, Requirement


class ProviderResolver:
    def __init__(
        self,
        engine_registry: EngineRegistry,
        policy_manager: PolicyManager,
        authorization_service: AuthorizationService,
    ) -> None:
        self._engine_registry = engine_registry
        self._policy_manager = policy_manager
        self._authorization = authorization_service

    async def select_provider(
        self,
        providers: list[ProviderInfo],
        requirement: Requirement,
    ) -> ProviderSelection:
        if not providers:
            raise KernelException(
                KernelError(
                    code="NO_PROVIDER_FOUND",
                    message="No provider available for the given requirement",
                    type=ErrorType.PROVIDER_ERROR,
                    retryable=False,
                )
            )

        eligible: list[ProviderInfo] = []
        for provider in providers:
            if provider.status not in (EngineStatus.ACTIVE, EngineStatus.DEGRADED):
                continue
            healthy = await self._engine_registry.health_check(provider.engine_id)
            if not healthy:
                continue
            if requirement.context and requirement.request:
                authorized = await self._authorization.authorize(
                    user_id=requirement.context.user_id,
                    agent_id=requirement.context.agent.agent_id if requirement.context.agent else "KERNEL-OS",
                    capability=requirement.capability,
                    resource_type=requirement.resource_type,
                    context=requirement.context,
                )
                if not authorized:
                    continue
            eligible.append(provider)

        if not eligible:
            raise KernelException(
                KernelError(
                    code="NO_ELIGIBLE_PROVIDER",
                    message="No eligible provider passed health and authorization checks",
                    type=ErrorType.PROVIDER_ERROR,
                    retryable=True,
                )
            )

        eligible.sort(key=lambda p: p.priority, reverse=True)
        selected = await self._policy_manager.select_provider(eligible, requirement)
        fallbacks = [p for p in eligible if p.engine_id != selected.engine_id]
        return ProviderSelection(provider=selected, fallback_providers=fallbacks)
