from ai_os.app.domain.models.execution import ExecutionContext
from ai_os.app.domain.models.kernel_request import KernelRequest
from ai_os.app.kernel.errors.kernel_errors import ErrorType, KernelError, KernelException
from ai_os.app.kernel.policies.authorization import AuthorizationService
from ai_os.app.kernel.registry.capability_registry import CapabilityRegistry
from ai_os.app.kernel.routing.provider_resolver import ProviderResolver
from ai_os.app.kernel.routing.requirement import Requirement


class CapabilityResolver:
    def __init__(
        self,
        capability_registry: CapabilityRegistry,
        provider_resolver: ProviderResolver,
        authorization_service: AuthorizationService,
    ) -> None:
        self._capability_registry = capability_registry
        self._provider_resolver = provider_resolver
        self._authorization = authorization_service

    async def resolve(
        self,
        capability: str,
        request: KernelRequest,
        context: ExecutionContext,
    ):
        if not self._capability_registry.is_available(capability):
            raise KernelException(
                KernelError(
                    code="CAPABILITY_NOT_FOUND",
                    message=f"No provider registered for capability '{capability}'",
                    type=ErrorType.PROVIDER_ERROR,
                    request_id=request.request_id,
                    execution_id=request.execution_id,
                )
            )

        providers = self._capability_registry.find_providers(capability)
        requirement = Requirement(capability=capability, request=request, context=context)
        return await self._provider_resolver.select_provider(providers, requirement)
