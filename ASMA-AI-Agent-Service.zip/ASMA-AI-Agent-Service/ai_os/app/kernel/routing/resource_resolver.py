from ai_os.app.domain.models.execution import ExecutionContext
from ai_os.app.domain.models.kernel_request import KernelRequest
from ai_os.app.kernel.errors.kernel_errors import ErrorType, KernelError, KernelException
from ai_os.app.kernel.policies.authorization import AuthorizationService
from ai_os.app.kernel.registry.resource_registry import ResourceRegistry
from ai_os.app.kernel.routing.provider_resolver import ProviderResolver
from ai_os.app.kernel.routing.requirement import Requirement


class ResourceResolver:
    def __init__(
        self,
        resource_registry: ResourceRegistry,
        provider_resolver: ProviderResolver,
        authorization_service: AuthorizationService,
    ) -> None:
        self._resource_registry = resource_registry
        self._provider_resolver = provider_resolver
        self._authorization = authorization_service

    async def resolve(
        self,
        resource_type: str,
        request: KernelRequest,
        context: ExecutionContext,
    ):
        if not self._resource_registry.is_available(resource_type):
            raise KernelException(
                KernelError(
                    code="RESOURCE_NOT_FOUND",
                    message=f"No provider registered for resource type '{resource_type}'",
                    type=ErrorType.PROVIDER_ERROR,
                    request_id=request.request_id,
                    execution_id=request.execution_id,
                )
            )

        providers = self._resource_registry.find_providers(resource_type)
        requirement = Requirement(resource_type=resource_type, request=request, context=context)
        return await self._provider_resolver.select_provider(providers, requirement)
