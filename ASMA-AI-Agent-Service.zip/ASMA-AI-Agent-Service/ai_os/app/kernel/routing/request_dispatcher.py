import asyncio
import uuid
from datetime import datetime, timezone

from ai_os.app.config.settings import Settings
from ai_os.app.domain.interfaces.gateway import EngineGateway
from ai_os.app.domain.interfaces.observability import ObservabilityService
from ai_os.app.domain.interfaces.repository import RequestRepository
from ai_os.app.domain.models.events import KernelEventType
from ai_os.app.domain.models.execution import ExecutionContext
from ai_os.app.domain.models.kernel_request import KernelRequest, RequestTarget, RequestType
from ai_os.app.domain.models.kernel_response import KernelResponse, ResponseStatus
from ai_os.app.kernel.errors.kernel_errors import ErrorType, KernelError, KernelException
from ai_os.app.kernel.observability.execution_tracer import ExecutionTracer
from ai_os.app.kernel.resilience.retry_manager import RetryManager
from ai_os.app.kernel.resilience.timeout_manager import TimeoutManager
from ai_os.app.kernel.routing.capability_resolver import CapabilityResolver
from ai_os.app.kernel.routing.resource_resolver import ResourceResolver


class RequestDispatcher:
    def __init__(
        self,
        capability_resolver: CapabilityResolver,
        resource_resolver: ResourceResolver,
        engine_gateway: EngineGateway,
        request_repository: RequestRepository,
        observability: ObservabilityService,
        retry_manager: RetryManager,
        timeout_manager: TimeoutManager,
        settings: Settings,
        tracer: ExecutionTracer | None = None,
    ) -> None:
        self._capability_resolver = capability_resolver
        self._resource_resolver = resource_resolver
        self._gateway = engine_gateway
        self._request_repository = request_repository
        self._observability = observability
        self._retry_manager = retry_manager
        self._timeout_manager = timeout_manager
        self._settings = settings
        self._tracer = tracer or ExecutionTracer()

    async def dispatch(self, request: KernelRequest, context: ExecutionContext) -> KernelResponse:
        await self._request_repository.save_request(request)
        context.pending_requests.append(request)
        self._tracer.trace_request_received(context, request)

        await self._observability.emit(
            KernelEventType.REQUEST_RECEIVED,
            execution_id=request.execution_id,
            request_id=request.request_id,
            payload={"requestType": request.request_type.value},
        )

        if request.request_type == RequestType.CAPABILITY_REQUEST:
            if not request.capability:
                raise KernelException(
                    KernelError(
                        code="MISSING_CAPABILITY",
                        message="CAPABILITY_REQUEST requires capability field",
                        type=ErrorType.VALIDATION_ERROR,
                        request_id=request.request_id,
                        execution_id=request.execution_id,
                    )
                )
            selection = await self._capability_resolver.resolve(request.capability, request, context)
            context.record_capability_use(request.capability)
            self._tracer.trace_provider_resolved(
                context, request, selection.provider.engine_id, "CapabilityRegistry"
            )
            await self._observability.emit(
                KernelEventType.CAPABILITY_RESOLVED,
                execution_id=request.execution_id,
                request_id=request.request_id,
                payload={"capability": request.capability},
            )
        elif request.request_type == RequestType.RESOURCE_REQUEST:
            if not request.resource:
                raise KernelException(
                    KernelError(
                        code="MISSING_RESOURCE",
                        message="RESOURCE_REQUEST requires resource field",
                        type=ErrorType.VALIDATION_ERROR,
                        request_id=request.request_id,
                        execution_id=request.execution_id,
                    )
                )
            selection = await self._resource_resolver.resolve(request.resource.type, request, context)
            self._tracer.trace_provider_resolved(
                context, request, selection.provider.engine_id, "ResourceRegistry"
            )
            await self._observability.emit(
                KernelEventType.RESOURCE_RESOLVED,
                execution_id=request.execution_id,
                request_id=request.request_id,
                payload={"resourceType": request.resource.type},
            )
        elif request.request_type == RequestType.EXECUTION_REQUEST:
            # Use the request's capability if provided, otherwise fall back to agent.execute
            capability = request.capability or "agent.execute"
            selection = await self._capability_resolver.resolve(capability, request, context)
            context.record_capability_use(capability)
            self._tracer.trace_provider_resolved(
                context, request, selection.provider.engine_id, "CapabilityRegistry"
            )
        elif request.request_type == RequestType.SUB_AGENT_EXECUTION:
            capability = request.capability or "agent.execute"
            selection = await self._capability_resolver.resolve(capability, request, context)
            context.record_capability_use(capability)
            context.active_scope = "sub_agent"
            self._tracer.trace_provider_resolved(
                context, request, selection.provider.engine_id, "CapabilityRegistry"
            )
        else:
            raise KernelException(
                KernelError(
                    code="UNSUPPORTED_REQUEST_TYPE",
                    message=f"Unsupported request type: {request.request_type}",
                    type=ErrorType.VALIDATION_ERROR,
                    request_id=request.request_id,
                    execution_id=request.execution_id,
                )
            )

        providers_to_try = [selection.provider] + selection.fallback_providers
        last_error: KernelException | None = None

        for provider in providers_to_try:
            request.target = RequestTarget(engineId=provider.engine_id)
            context.record_engine_use(provider.engine_id)

            await self._observability.emit(
                KernelEventType.PROVIDER_SELECTED,
                execution_id=request.execution_id,
                request_id=request.request_id,
                payload={"engineId": provider.engine_id},
            )
            self._tracer.trace_dispatch(context, request, provider.engine_id)

            try:
                response = await self._retry_manager.execute_with_retry(
                    lambda eng=provider.engine_id: self._send_with_timeout(eng, request, context),
                    request.retry_policy,
                    context,
                )
                return response
            except KernelException as exc:
                last_error = exc
                if not exc.error.retryable:
                    break
                context.retry_count += 1

        if last_error:
            raise last_error

        raise KernelException(
            KernelError(
                code="DISPATCH_FAILED",
                message="Request dispatch failed with no response",
                type=ErrorType.ENGINE_ERROR,
                request_id=request.request_id,
                execution_id=request.execution_id,
            )
        )

    async def _send_with_timeout(
        self, engine_id: str, request: KernelRequest, context: ExecutionContext
    ) -> KernelResponse:
        timeout = request.timeout or self._settings.default_request_timeout_seconds

        async def _send() -> KernelResponse:
            await self._observability.emit(
                KernelEventType.REQUEST_DISPATCHED,
                execution_id=request.execution_id,
                request_id=request.request_id,
                payload={"engineId": engine_id},
            )
            response = await self._gateway.send(engine_id, request)
            self._tracer.trace_engine_response(context, request, response, engine_id)
            await self._observability.emit(
                KernelEventType.ENGINE_RESPONSE_RECEIVED,
                execution_id=request.execution_id,
                request_id=request.request_id,
                payload={"status": response.status.value},
            )
            return response

        return await self._timeout_manager.execute_with_timeout(_send, timeout, request)
