from dataclasses import dataclass

from ai_os.app.domain.models.engine import ProviderInfo
from ai_os.app.domain.models.execution import ExecutionContext
from ai_os.app.domain.models.kernel_request import KernelRequest


@dataclass
class Requirement:
    capability: str | None = None
    resource_type: str | None = None
    request: KernelRequest | None = None
    context: ExecutionContext | None = None


@dataclass
class ProviderSelection:
    provider: ProviderInfo
    fallback_providers: list[ProviderInfo]
