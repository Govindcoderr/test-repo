from datetime import datetime, timezone
from typing import Any

from ai_os.app.domain.models.execution import ExecutionContext
from ai_os.app.domain.models.kernel_request import KernelRequest
from ai_os.app.domain.models.kernel_response import KernelResponse, NextIntent


class ExecutionTracer:
    """Records a human-readable step-by-step trace of kernel routing decisions."""

    def _now(self) -> str:
        return datetime.now(timezone.utc).isoformat()

    def _append(self, context: ExecutionContext, step: str, details: dict[str, Any]) -> None:
        context.activity_logs.append(
            {
                "timestamp": self._now(),
                "step": step,
                **details,
            }
        )

    def trace_execution_started(self, context: ExecutionContext) -> None:
        self._append(
            context,
            "EXECUTION_STARTED",
            {
                "message": f"Kernel received user query: '{context.user_query}'",
                "executionId": context.execution_id,
                "agentId": context.agent.agent_id,
            },
        )

    def trace_request_received(self, context: ExecutionContext, request: KernelRequest) -> None:
        source = f"{request.source.type}:{request.source.id}"
        need = self._describe_need(request)
        self._append(
            context,
            "REQUEST_RECEIVED",
            {
                "message": f"Kernel received request from {source} - needs {need}",
                "requestId": request.request_id,
                "parentRequestId": request.parent_request_id,
                "requestType": request.request_type.value,
                "source": source,
                "need": need,
            },
        )

    def trace_provider_resolved(
        self,
        context: ExecutionContext,
        request: KernelRequest,
        engine_id: str,
        resolution_type: str,
    ) -> None:
        need = self._describe_need(request)
        self._append(
            context,
            "PROVIDER_RESOLVED",
            {
                "message": f"Kernel resolved {need} -> provider '{engine_id}' (via {resolution_type})",
                "requestId": request.request_id,
                "engineId": engine_id,
                "resolutionType": resolution_type,
            },
        )

    def trace_dispatch(self, context: ExecutionContext, request: KernelRequest, engine_id: str) -> None:
        self._append(
            context,
            "ENGINE_DISPATCH",
            {
                "message": f"Kernel -> {engine_id}: dispatching request {request.request_id}",
                "requestId": request.request_id,
                "engineId": engine_id,
                "direction": "KERNEL_TO_ENGINE",
            },
        )

    def trace_engine_response(
        self,
        context: ExecutionContext,
        request: KernelRequest,
        response: KernelResponse,
        engine_id: str,
    ) -> None:
        next_intents = [self._describe_intent(i) for i in response.next_intents]
        self._append(
            context,
            "ENGINE_RESPONSE",
            {
                "message": f"{engine_id} -> Kernel: response for {request.request_id}",
                "requestId": request.request_id,
                "engineId": engine_id,
                "direction": "ENGINE_TO_KERNEL",
                "status": response.status.value,
                "resultSummary": self._summarize_result(response.result),
                "nextIntents": next_intents,
            },
        )

    def trace_context_updated(self, context: ExecutionContext, request: KernelRequest, engine_id: str) -> None:
        self._append(
            context,
            "CONTEXT_UPDATED",
            {
                "message": f"Kernel updated ExecutionContext after {engine_id} response",
                "requestId": request.request_id,
                "engineId": engine_id,
                "knowledgeContextKeys": list(context.knowledge_context.keys()),
                "hasModelLogs": len(context.model_logs) > 0,
                "hasToolResults": len(context.tool_results) > 0,
            },
        )

    def trace_agent_continuation(
        self,
        context: ExecutionContext,
        parent_request_id: str,
        from_engine: str,
    ) -> None:
        self._append(
            context,
            "AGENT_CONTINUATION",
            {
                "message": f"Kernel resuming agent-runtime with data from {from_engine}",
                "parentRequestId": parent_request_id,
                "fromEngine": from_engine,
                "direction": "KERNEL_TO_AGENT",
            },
        )

    def trace_child_intent_created(
        self,
        context: ExecutionContext,
        parent_request_id: str,
        child_request: KernelRequest,
        from_engine: str,
    ) -> None:
        self._append(
            context,
            "CHILD_REQUEST_CREATED",
            {
                "message": f"Kernel created child request from {from_engine} intent: {self._describe_need(child_request)}",
                "parentRequestId": parent_request_id,
                "childRequestId": child_request.request_id,
                "fromEngine": from_engine,
            },
        )

    def trace_execution_completed(self, context: ExecutionContext) -> None:
        self._append(
            context,
            "EXECUTION_COMPLETED",
            {
                "message": f"Kernel completed execution - finalResponse: '{context.final_response}'",
                "executionId": context.execution_id,
                "enginesUsed": context.engines_used,
                "stepsExecuted": context.steps_executed,
            },
        )

    def _describe_need(self, request: KernelRequest) -> str:
        if request.request_type.value == "RESOURCE_REQUEST" and request.resource:
            return f"resource '{request.resource.type}' (id={request.resource.id})"
        if request.request_type.value == "CAPABILITY_REQUEST" and request.capability:
            return f"capability '{request.capability}'"
        if request.capability:
            return f"execution '{request.capability}'"
        return request.request_type.value

    def _describe_intent(self, intent: NextIntent) -> str:
        if intent.intent_type == "RESOURCE_REQUEST" and intent.resource:
            return f"RESOURCE_REQUEST:{intent.resource.get('type')}"
        if intent.intent_type == "CAPABILITY_REQUEST" and intent.capability:
            return f"CAPABILITY_REQUEST:{intent.capability}"
        return intent.intent_type

    def _summarize_result(self, result: dict | None) -> str:
        if not result:
            return "(empty)"
        if "content" in result:
            return f"content='{str(result['content'])[:80]}...'"
        if "response" in result:
            return f"response='{result['response']}'"
        if "finalResponse" in result:
            return f"finalResponse='{result['finalResponse']}'"
        return str(list(result.keys()))
