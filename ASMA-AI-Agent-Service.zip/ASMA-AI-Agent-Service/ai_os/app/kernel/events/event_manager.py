import uuid
from datetime import datetime, timezone

from ai_os.app.domain.interfaces.observability import ObservabilityService
from ai_os.app.domain.interfaces.repository import EventRepository
from ai_os.app.domain.models.events import KernelEvent, KernelEventType


class EventManager:
    def __init__(
        self,
        event_repository: EventRepository,
        observability: ObservabilityService,
    ) -> None:
        self._event_repository = event_repository
        self._observability = observability
        self._subscribers: list = []

    async def publish(
        self,
        event_type: KernelEventType,
        execution_id: str | None = None,
        request_id: str | None = None,
        source: str = "kernel",
        payload: dict | None = None,
    ) -> KernelEvent:
        event = KernelEvent(
            eventId=f"EVT-{uuid.uuid4().hex[:8].upper()}",
            eventType=event_type,
            timestamp=datetime.now(timezone.utc).isoformat(),
            executionId=execution_id,
            requestId=request_id,
            source=source,
            payload=payload or {},
        )
        await self._event_repository.save_event(event)
        await self._observability.emit(
            event_type,
            execution_id=execution_id,
            request_id=request_id,
            payload=payload,
        )
        return event
