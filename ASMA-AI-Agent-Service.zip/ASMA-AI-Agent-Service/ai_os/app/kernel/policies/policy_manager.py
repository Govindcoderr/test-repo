from ai_os.app.domain.models.engine import ProviderInfo
from ai_os.app.domain.models.execution import ExecutionContext
from ai_os.app.domain.models.kernel_request import KernelRequest
from ai_os.app.kernel.routing.requirement import Requirement


class PolicyManager:
    async def can_execute(self, context: ExecutionContext) -> bool:
        if context.agent and not context.agent.enabled:
            return False
        return True

    async def can_execute_request(self, request: KernelRequest, context: ExecutionContext) -> bool:
        return await self.can_execute(context)

    async def select_provider(self, providers: list[ProviderInfo], requirement: Requirement) -> ProviderInfo:
        return providers[0]

    async def can_fallback(self, requirement: Requirement) -> bool:
        return True

    async def is_parallel_allowed(self, context: ExecutionContext) -> bool:
        return True
