from abc import ABC, abstractmethod

from ai_os.app.domain.models.execution import ExecutionContext


class AuthorizationService(ABC):
    """Abstract authorization service.

    Implement this interface to provide real authorization logic.
    The kernel calls authorize() before dispatching to an engine.
    """

    @abstractmethod
    async def authorize(
        self,
        user_id: str,
        agent_id: str,
        capability: str | None = None,
        resource_type: str | None = None,
        context: ExecutionContext | None = None,
    ) -> bool:
        pass


class DefaultAuthorizationService(AuthorizationService):
    """Default authorization that allows all requests.

    Replace with a real implementation that checks permissions
    against your access control system.
    """

    async def authorize(
        self,
        user_id: str,
        agent_id: str,
        capability: str | None = None,
        resource_type: str | None = None,
        context: ExecutionContext | None = None,
    ) -> bool:
        # Default: allow all. Override with real authorization logic.
        return True
