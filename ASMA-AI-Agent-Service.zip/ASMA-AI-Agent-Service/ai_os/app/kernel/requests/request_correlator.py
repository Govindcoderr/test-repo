from ai_os.app.domain.interfaces.observability import ObservabilityService
from ai_os.app.domain.interfaces.repository import RequestRepository
from ai_os.app.kernel.observability.execution_tracer import ExecutionTracer
from ai_os.app.domain.models.events import KernelEventType
from ai_os.app.domain.models.execution import ExecutionContext, ModelLog
from ai_os.app.domain.models.kernel_request import KernelRequest
from ai_os.app.domain.models.kernel_response import KernelResponse, ResponseStatus


class ResponseCorrelator:
    """Correlates engine responses back to requests and updates execution context.

    This is engine-agnostic — it records execution logs and updates context
    based on what the response contains, without assuming specific engine names.
    """

    def __init__(
        self,
        request_repository: RequestRepository,
        observability: ObservabilityService,
        tracer: ExecutionTracer | None = None,
    ) -> None:
        self._request_repository = request_repository
        self._observability = observability
        self._tracer = tracer or ExecutionTracer()

    async def correlate(
        self,
        response: KernelResponse,
        context: ExecutionContext,
        original_request: KernelRequest,
    ) -> KernelResponse:
        """Correlate a response with its original request and update execution context."""
        # Move request from pending to completed
        if original_request in context.pending_requests:
            context.pending_requests.remove(original_request)
        context.completed_requests.append(original_request)
        context.steps_executed += 1

        # Update context from result
        if response.result:
            self._update_context_from_result(response, context, original_request)

        # Trace and log
        engine_id = original_request.target.engine_id if original_request.target else "unknown"
        self._tracer.trace_context_updated(context, original_request, engine_id)
        self._record_execution_log(context, original_request, response, engine_id)

        # Handle failures
        if response.status == ResponseStatus.FAILURE:
            context.failed_requests.append(original_request)
            context.errors.extend(response.errors)

        context.warnings.extend(response.warnings)

        await self._observability.emit(
            KernelEventType.CONTEXT_UPDATED,
            execution_id=context.execution_id,
            request_id=response.request_id,
            payload={"status": response.status.value},
        )

        return response

    def _update_context_from_result(
        self,
        response: KernelResponse,
        context: ExecutionContext,
        request: KernelRequest,
    ) -> None:
        """Update execution context based on engine response content.

        Uses capability and response metadata to determine what kind of result
        this is, rather than hardcoding engine IDs.
        """
        result = response.result or {}
        capability = request.capability or ""

        # Accumulate results based on capability category
        if capability.startswith("knowledge."):
            context.knowledge_context.update(result)
        elif capability.startswith("memory."):
            context.memory_context.update(result)
        elif capability.startswith("tool."):
            context.tool_results.append(result)

        # Supervisor/Planning results update strategy and workflow
        if capability.startswith("supervisor."):
            if "strategy" in result:
                context.strategy.update(result["strategy"])
        if capability.startswith("planning."):
            if "workflow" in result:
                context.workflow_plan.update(result["workflow"])
            elif "plan" in result:
                context.workflow_plan.update(result["plan"])

        # Any capability's stage may report LLM usage for its own call —
        # see SupervisorEngine/PlanningEngine._model_usage_entry(). This is
        # what actually populates ExecutionContext.model_logs (and, via
        # ResponseBuilder, ExecutionResponse.agent.modelLogs /
        # executionMetrics.totalTokens/totalCost/modelTime) — without this,
        # the usage/latency/cost normalized by the Model engine's provider
        # adapters would be computed and then silently discarded.
        if "modelUsage" in result:
            self._record_model_usage(response, context, request, result["modelUsage"])

        # Worker state updates from Agent Runtime
        if capability.startswith("agent."):
            if "workerStates" in result:
                context.worker_states.update(result["workerStates"])
            if "subAgentResults" in result:
                context.sub_agent_results.update(result["subAgentResults"])

        # Collect artifacts
        if response.artifacts:
            context.artifacts.extend(response.artifacts)

        # Extract final response if present
        if result.get("finalResponse"):
            context.final_response = result["finalResponse"]
        elif result.get("response") and not context.final_response:
            context.final_response = result["response"]

    def _record_model_usage(
        self,
        response: KernelResponse,
        context: ExecutionContext,
        request: KernelRequest,
        model_usage: dict,
    ) -> None:
        """Turn a stage's `modelUsage` block into an ExecutionContext.model_logs entry.

        `model_usage` is the dict shape SupervisorEngine/PlanningEngine's
        `_model_usage_entry()` builds from an LLMResponse — see
        domain/models/llm_response.py for the normalized fields this comes
        from. Recorded regardless of capability prefix, since any engine
        (Supervisor, Planning, and eventually Agent Runtime workers) may
        report LLM usage this way.
        """
        context.model_logs.append(
            ModelLog(
                requestId=request.request_id,
                modelProvider=model_usage.get("provider", "unknown"),
                modelName=model_usage.get("modelName", "unknown"),
                inputTokens=model_usage.get("promptTokens", 0),
                outputTokens=model_usage.get("completionTokens", 0),
                totalTokens=model_usage.get("totalTokens", 0),
                latency=model_usage.get("latency"),
                cost=model_usage.get("cost"),
                finishReason=model_usage.get("finishReason"),
                status="SUCCESS" if response.status == ResponseStatus.SUCCESS else "FAILURE",
            )
        )

    def _record_execution_log(
        self,
        context: ExecutionContext,
        request: KernelRequest,
        response: KernelResponse,
        engine_id: str,
    ) -> None:
        """Record a structured execution log entry for this dispatch step."""
        # Use `or` rather than dict.get(key, default) — metadata may contain
        # the key with an explicit None value (e.g. dynamic-loop steps that
        # don't set stepId/stepName), which .get()'s default would not catch.
        step_id = request.metadata.get("stepId") or request.request_id
        step_name = request.metadata.get("stepName") or request.capability or engine_id
        log = {
            "stepId": step_id,
            "stepName": step_name,
            "engineId": engine_id,
            "capability": request.capability,
            "resource": request.resource.model_dump(by_alias=True) if request.resource else None,
            "status": response.status.value,
            "duration": response.metadata.get("duration") if response.metadata else None,
            "resultKeys": list((response.result or {}).keys()),
        }
        context.execution_logs.append(log)
