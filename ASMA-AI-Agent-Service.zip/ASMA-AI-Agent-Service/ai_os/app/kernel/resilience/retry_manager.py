import asyncio
from collections.abc import Awaitable, Callable
from typing import TypeVar

from ai_os.app.domain.models.execution import ExecutionContext
from ai_os.app.domain.models.kernel_request import RetryPolicy
from ai_os.app.domain.models.kernel_response import KernelResponse
from ai_os.app.kernel.errors.kernel_errors import ErrorType, KernelError, KernelException

T = TypeVar("T")


class RetryManager:
    async def execute_with_retry(
        self,
        operation: Callable[[], Awaitable[KernelResponse]],
        retry_policy: RetryPolicy,
        context: ExecutionContext,
    ) -> KernelResponse:
        last_exception: KernelException | None = None
        delay = retry_policy.retry_delay_seconds

        for attempt in range(retry_policy.max_retries + 1):
            try:
                response = await operation()
                if response.status.value == "FAILURE":
                    error_codes = [e.get("code", "") for e in response.errors]
                    if any(c in retry_policy.non_retryable_errors for c in error_codes):
                        return response
                    if attempt < retry_policy.max_retries:
                        context.retry_count += 1
                        await asyncio.sleep(delay)
                        delay *= retry_policy.backoff_multiplier
                        continue
                return response
            except KernelException as exc:
                last_exception = exc
                if not exc.error.retryable or attempt >= retry_policy.max_retries:
                    raise
                context.retry_count += 1
                await asyncio.sleep(delay)
                delay *= retry_policy.backoff_multiplier

        if last_exception:
            raise last_exception

        raise KernelException(
            KernelError(
                code="RETRY_EXHAUSTED",
                message="All retry attempts exhausted",
                type=ErrorType.ENGINE_ERROR,
                retryable=False,
            )
        )
