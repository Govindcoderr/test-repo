import asyncio
from collections.abc import Awaitable, Callable
from typing import TypeVar

from ai_os.app.domain.models.kernel_request import KernelRequest
from ai_os.app.domain.models.kernel_response import KernelResponse, ResponseStatus
from ai_os.app.kernel.errors.kernel_errors import ErrorType, KernelError, KernelException

T = TypeVar("T")


class TimeoutManager:
    async def execute_with_timeout(
        self,
        operation: Callable[[], Awaitable[KernelResponse]],
        timeout_seconds: int,
        request: KernelRequest,
    ) -> KernelResponse:
        try:
            return await asyncio.wait_for(operation(), timeout=timeout_seconds)
        except asyncio.TimeoutError:
            raise KernelException(
                KernelError(
                    code="REQUEST_TIMED_OUT",
                    message=f"Request timed out after {timeout_seconds} seconds",
                    type=ErrorType.TIMEOUT_ERROR,
                    request_id=request.request_id,
                    execution_id=request.execution_id,
                    retryable=True,
                )
            )
