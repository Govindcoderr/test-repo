import uuid
from datetime import datetime, timezone

from ai_os.app.domain.interfaces.engine import Engine
from ai_os.app.domain.models.engine import EngineManifest, EngineStatus
from ai_os.app.kernel.errors.kernel_errors import ErrorType, KernelError, KernelException


class EngineRegistry:
    def __init__(self) -> None:
        self._engines: dict[str, Engine] = {}
        self._manifests: dict[str, EngineManifest] = {}

    def register(self, engine: Engine) -> None:
        manifest = engine.manifest
        if manifest.engine_id in self._engines:
            raise KernelException(
                KernelError(
                    code="ENGINE_ALREADY_REGISTERED",
                    message=f"Engine '{manifest.engine_id}' is already registered",
                    type=ErrorType.KERNEL_ERROR,
                )
            )
        self._engines[manifest.engine_id] = engine
        self._manifests[manifest.engine_id] = manifest

    def unregister(self, engine_id: str) -> None:
        self._engines.pop(engine_id, None)
        self._manifests.pop(engine_id, None)

    def get_engine(self, engine_id: str) -> Engine | None:
        return self._engines.get(engine_id)

    def get_manifest(self, engine_id: str) -> EngineManifest | None:
        return self._manifests.get(engine_id)

    def list_engines(self) -> list[EngineManifest]:
        return list(self._manifests.values())

    def list_active_engines(self) -> list[EngineManifest]:
        return [m for m in self._manifests.values() if m.status == EngineStatus.ACTIVE]

    async def initialize_all(self) -> None:
        for engine in self._engines.values():
            await engine.initialize()

    async def shutdown_all(self) -> None:
        for engine in self._engines.values():
            await engine.shutdown()

    async def health_check(self, engine_id: str) -> bool:
        engine = self._engines.get(engine_id)
        if not engine:
            return False
        return await engine.health_check()
