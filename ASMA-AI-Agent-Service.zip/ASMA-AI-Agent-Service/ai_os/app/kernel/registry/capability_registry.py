from ai_os.app.domain.models.engine import CapabilityRegistration, ProviderInfo, EngineStatus
from ai_os.app.kernel.registry.engine_registry import EngineRegistry


class CapabilityRegistry:
    def __init__(self, engine_registry: EngineRegistry) -> None:
        self._engine_registry = engine_registry
        self._capabilities: dict[str, list[CapabilityRegistration]] = {}

    def register(self, registration: CapabilityRegistration) -> None:
        self._capabilities.setdefault(registration.capability, []).append(registration)
        self._capabilities[registration.capability].sort(key=lambda r: r.priority)

    def unregister(self, capability: str, engine_id: str) -> None:
        if capability not in self._capabilities:
            return
        self._capabilities[capability] = [
            r for r in self._capabilities[capability] if r.engine_id != engine_id
        ]

    def unregister_engine(self, engine_id: str) -> None:
        for capability in list(self._capabilities.keys()):
            self.unregister(capability, engine_id)

    def find_providers(self, capability: str) -> list[ProviderInfo]:
        registrations = self._capabilities.get(capability, [])
        providers: list[ProviderInfo] = []
        for reg in registrations:
            manifest = self._engine_registry.get_manifest(reg.engine_id)
            if manifest is None:
                continue
            providers.append(
                ProviderInfo(
                    engineId=reg.engine_id,
                    priority=reg.priority,
                    status=manifest.status,
                    metadata=reg.metadata,
                )
            )
        return providers

    def is_available(self, capability: str) -> bool:
        return len(self.find_providers(capability)) > 0

    def get_metadata(self, capability: str) -> list[CapabilityRegistration]:
        return list(self._capabilities.get(capability, []))

    def list_capabilities(self) -> list[str]:
        return list(self._capabilities.keys())

    def register_from_engine_manifest(self, engine_id: str, capabilities: list[str], priority: int = 100) -> None:
        for capability in capabilities:
            self.register(
                CapabilityRegistration(
                    capability=capability,
                    engineId=engine_id,
                    priority=priority,
                )
            )
