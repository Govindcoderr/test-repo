from ai_os.app.domain.models.engine import ProviderInfo, ResourceRegistration
from ai_os.app.kernel.registry.engine_registry import EngineRegistry


class ResourceRegistry:
    def __init__(self, engine_registry: EngineRegistry) -> None:
        self._engine_registry = engine_registry
        self._resources: dict[str, list[ResourceRegistration]] = {}

    def register(self, registration: ResourceRegistration) -> None:
        self._resources.setdefault(registration.resource_type, []).append(registration)
        self._resources[registration.resource_type].sort(key=lambda r: r.priority)

    def unregister(self, resource_type: str, engine_id: str) -> None:
        if resource_type not in self._resources:
            return
        self._resources[resource_type] = [
            r for r in self._resources[resource_type] if r.engine_id != engine_id
        ]

    def unregister_engine(self, engine_id: str) -> None:
        for resource_type in list(self._resources.keys()):
            self.unregister(resource_type, engine_id)

    def find_providers(self, resource_type: str) -> list[ProviderInfo]:
        registrations = self._resources.get(resource_type, [])
        providers: list[ProviderInfo] = []
        for reg in registrations:
            manifest = self._engine_registry.get_manifest(reg.engine_id)
            if manifest is None:
                continue
            providers.append(
                ProviderInfo(
                    engineId=reg.engine_id,
                    priority=reg.priority,
                    status=manifest.status,
                    metadata=reg.metadata,
                )
            )
        return providers

    def is_available(self, resource_type: str) -> bool:
        return len(self.find_providers(resource_type)) > 0

    def list_resource_types(self) -> list[str]:
        return list(self._resources.keys())

    def register_from_engine_manifest(self, engine_id: str, resources: list[str], priority: int = 100) -> None:
        for resource_type in resources:
            self.register(
                ResourceRegistration(
                    resourceType=resource_type,
                    engineId=engine_id,
                    priority=priority,
                )
            )
