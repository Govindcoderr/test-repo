import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI

from ai_os.app.api.dependencies import get_container
from ai_os.app.api.routes.kernel_routes import router as kernel_router
from ai_os.app.config.settings import get_settings
from ai_os.app.infrastructure.engines.Model.model_engine import ModelEngine
from ai_os.app.infrastructure.engines.Planning.planning_engine import PlanningEngine
from ai_os.app.infrastructure.engines.Supervisor.supervisor_engine import SupervisorEngine

logging.basicConfig(level=logging.INFO)


@asynccontextmanager
async def lifespan(app: FastAPI):
    container = get_container()
    settings = get_settings()

    # The Model engine is the only place that constructs an LLM SDK
    # client. Supervisor and Planning each get a fixed ILLMClient built
    # once, here, from their own env-configured ModelConfiguration (see
    # Settings.supervisor_model_configuration/planning_model_configuration)
    # — they are NOT backend-configurable. Only Agent Runtime workers will
    # receive a backend-supplied ModelConfiguration, dispatched through the
    # kernel's "model.create_client" capability, once that engine exists.
    model_engine = ModelEngine()
    supervisor_llm = model_engine.create_client_from_config(settings.supervisor_model_configuration())
    planning_llm = model_engine.create_client_from_config(settings.planning_model_configuration())

    # Bootstrap the kernel with the engines that are ready. Additional
    # engines are registered here as they become ready, e.g.
    # container.register_engine(MyEngine()). Note: Planning's create_plan
    # hands off to "supervisor.validate_result" for now — Agent Runtime
    # doesn't exist yet, so no engine actually executes the built workflow.
    await container.bootstrap(
        [
            model_engine,
            SupervisorEngine(llm_client=supervisor_llm),
            PlanningEngine(llm_client=planning_llm),
        ]
    )
    yield
    await container.lifecycle_manager.shutdown()


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        lifespan=lifespan,
    )
    app.include_router(kernel_router)
    return app


app = create_app()
