from functools import lru_cache

from ai_os.app.config.settings import Settings, get_settings
from ai_os.app.domain.interfaces.engine import Engine
from ai_os.app.infrastructure.gateways.local_engine_gateway import LocalEngineGateway
from ai_os.app.infrastructure.memory.json_memory_store import JsonMemoryStore
from ai_os.app.infrastructure.notifications.notification_service import (
    LoggingNotificationService,
    NotificationService,
    WebhookNotificationService,
)
from ai_os.app.infrastructure.observability.console_observer import ConsoleObserver
from ai_os.app.infrastructure.repositories.in_memory.repositories import (
    InMemoryEventRepository,
    InMemoryExecutionRepository,
    InMemoryRequestRepository,
)
from ai_os.app.kernel.execution.execution_manager import ExecutionManager
from ai_os.app.kernel.execution.execution_scheduler import ExecutionScheduler
from ai_os.app.kernel.human_input.pending_input_registry import PendingInputRegistry
from ai_os.app.kernel.intents.intent_manager import IntentManager
from ai_os.app.kernel.kernel import AIKernel
from ai_os.app.kernel.lifecycle_manager import LifecycleManager
from ai_os.app.kernel.observability.execution_tracer import ExecutionTracer
from ai_os.app.kernel.orchestration.dispatch_plan_executor import DispatchPlanExecutor
from ai_os.app.kernel.plugin_loader import PluginLoader
from ai_os.app.kernel.policies.authorization import AuthorizationService, DefaultAuthorizationService
from ai_os.app.kernel.policies.policy_manager import PolicyManager
from ai_os.app.kernel.registry.capability_registry import CapabilityRegistry
from ai_os.app.kernel.registry.engine_registry import EngineRegistry
from ai_os.app.kernel.registry.resource_registry import ResourceRegistry
from ai_os.app.kernel.requests.request_correlator import ResponseCorrelator
from ai_os.app.kernel.resilience.retry_manager import RetryManager
from ai_os.app.kernel.resilience.timeout_manager import TimeoutManager
from ai_os.app.kernel.response.response_builder import ResponseBuilder
from ai_os.app.kernel.routing.capability_resolver import CapabilityResolver
from ai_os.app.kernel.routing.provider_resolver import ProviderResolver
from ai_os.app.kernel.routing.request_dispatcher import RequestDispatcher
from ai_os.app.kernel.routing.resource_resolver import ResourceResolver


class KernelContainer:
    """Composition root for the AI OS Kernel.

    Wires all kernel infrastructure. Engines are registered dynamically
    at runtime via `register_engine()` or during bootstrap.
    """

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()

        # Repositories (in-memory for now — swap for persistent implementations later)
        self.execution_repository = InMemoryExecutionRepository()
        self.request_repository = InMemoryRequestRepository()
        self.event_repository = InMemoryEventRepository()

        # Observability
        self.observability = ConsoleObserver()
        self.tracer = ExecutionTracer()

        # Fallback memory store (JSON file) — dev-phase stand-in for a real
        # Memory engine. Called directly by the kernel, not dispatched.
        self.memory_store = JsonMemoryStore(self.settings.memory_store_path)

        # Human-in-the-loop: in-process suspension registry + outbound
        # notifier. WebhookNotificationService is used when a webhook URL
        # is configured (the separate backend service, per the project's
        # architecture); otherwise falls back to logging only.
        self.pending_input_registry = PendingInputRegistry()
        self.notification_service: NotificationService = (
            WebhookNotificationService(
                self.settings.human_input_webhook_url,
                timeout_seconds=self.settings.human_input_webhook_timeout_seconds,
            )
            if self.settings.human_input_webhook_url
            else LoggingNotificationService()
        )

        # Engine infrastructure
        self.engine_registry = EngineRegistry()
        self.capability_registry = CapabilityRegistry(self.engine_registry)
        self.resource_registry = ResourceRegistry(self.engine_registry)
        self.engine_gateway = LocalEngineGateway()

        # Policies & Authorization
        self.authorization = DefaultAuthorizationService()
        self.policy_manager = PolicyManager()

        # Routing
        self.provider_resolver = ProviderResolver(
            self.engine_registry, self.policy_manager, self.authorization
        )
        self.capability_resolver = CapabilityResolver(
            self.capability_registry, self.provider_resolver, self.authorization
        )
        self.resource_resolver = ResourceResolver(
            self.resource_registry, self.provider_resolver, self.authorization
        )

        # Resilience
        self.retry_manager = RetryManager()
        self.timeout_manager = TimeoutManager()

        # Request Dispatcher
        self.request_dispatcher = RequestDispatcher(
            capability_resolver=self.capability_resolver,
            resource_resolver=self.resource_resolver,
            engine_gateway=self.engine_gateway,
            request_repository=self.request_repository,
            observability=self.observability,
            retry_manager=self.retry_manager,
            timeout_manager=self.timeout_manager,
            settings=self.settings,
            tracer=self.tracer,
        )

        # Execution
        self.execution_manager = ExecutionManager(
            self.execution_repository, self.event_repository, self.observability
        )
        self.intent_manager = IntentManager()
        self.response_correlator = ResponseCorrelator(
            self.request_repository, self.observability, tracer=self.tracer
        )
        self.response_builder = ResponseBuilder()
        self.scheduler = ExecutionScheduler()

        # Dispatch Plan Executor (for backend-defined execution plans)
        self.dispatch_plan_executor = DispatchPlanExecutor(
            self.intent_manager,
            self.request_dispatcher,
            self.response_correlator,
            self.scheduler,
        )

        # Kernel
        self.kernel = AIKernel(
            execution_manager=self.execution_manager,
            intent_manager=self.intent_manager,
            request_dispatcher=self.request_dispatcher,
            response_correlator=self.response_correlator,
            response_builder=self.response_builder,
            policy_manager=self.policy_manager,
            scheduler=self.scheduler,
            observability=self.observability,
            dispatch_plan_executor=self.dispatch_plan_executor,
            capability_registry=self.capability_registry,
            resource_registry=self.resource_registry,
            tracer=self.tracer,
            memory_store=self.memory_store,
            pending_input_registry=self.pending_input_registry,
            notification_service=self.notification_service,
            human_input_timeout_seconds=self.settings.human_input_timeout_seconds,
        )

        # Plugin infrastructure (for engine registration)
        self.plugin_loader = PluginLoader(
            self.engine_registry, self.capability_registry, self.resource_registry
        )
        self.lifecycle_manager = LifecycleManager(self.plugin_loader, self.engine_registry)

    def register_engine(self, engine: Engine) -> None:
        """Register a single engine at runtime.

        This is the primary way engines will be added as they become ready.
        The kernel automatically discovers capabilities and resources from the engine manifest.
        """
        self.plugin_loader.load_engine(engine)
        self.engine_gateway.register_engine(engine.manifest.engine_id, engine)

    async def register_and_initialize_engine(self, engine: Engine) -> None:
        """Register and initialize a single engine."""
        self.register_engine(engine)
        await engine.initialize()

    async def bootstrap(self, engines: list[Engine] | None = None) -> None:
        """Bootstrap the kernel with a list of engines.

        If no engines are provided, the kernel starts with an empty registry.
        Engines can be registered later via `register_engine()`.
        """
        if engines:
            await self.lifecycle_manager.startup(engines)
            for engine in engines:
                self.engine_gateway.register_engine(engine.manifest.engine_id, engine)


@lru_cache
def get_container() -> KernelContainer:
    return KernelContainer()


async def get_kernel() -> AIKernel:
    container = get_container()
    if not container.engine_registry.list_engines():
        await container.bootstrap()
    return container.kernel
