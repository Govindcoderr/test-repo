from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from typing import Any

from ai_os.app.api.dependencies import get_container, get_kernel
from ai_os.app.domain.models.dispatch_plan import DispatchPlan, EngineDispatchItem
from ai_os.app.domain.models.execution import ExecutionRequest
from ai_os.app.domain.models.kernel_output import ExecutionResponse
from ai_os.app.domain.models.kernel_response import KernelResponse
from ai_os.app.kernel.errors.kernel_errors import KernelException
from ai_os.app.kernel.kernel import AIKernel

router = APIRouter(prefix="/api/v1/kernel", tags=["kernel"])


class KernelDispatchRequest(BaseModel):
    """Single engine dispatch through the kernel."""

    dispatch: EngineDispatchItem
    execution_id: str | None = Field(default=None, alias="executionId")
    session_id: str = Field(default="SESSION-DISPATCH", alias="sessionId")
    user_id: str = Field(default="USER-DISPATCH", alias="userId")

    model_config = {"populate_by_name": True}


class KernelPlanRequest(BaseModel):
    """Multi-step dispatch plan execution through the kernel."""

    plan: DispatchPlan
    execution_id: str | None = Field(default=None, alias="executionId")
    session_id: str = Field(default="SESSION-PLAN", alias="sessionId")
    user_id: str = Field(default="USER-PLAN", alias="userId")

    model_config = {"populate_by_name": True}


@router.post("/execute", response_model=ExecutionResponse)
async def execute(
    request: ExecutionRequest,
    kernel: AIKernel = Depends(get_kernel),
) -> ExecutionResponse:
    """Run a full execution lifecycle through the kernel.

    Accepts an ExecutionRequest with an optional dispatchPlan in metadata.
    The kernel creates an execution context, validates policies, executes
    the dispatch plan, and returns the aggregated response.
    """
    try:
        return await kernel.execute(request)
    except KernelException as exc:
        raise HTTPException(status_code=400, detail=exc.error.model_dump(by_alias=True)) from exc


@router.post("/dispatch", response_model=KernelResponse)
async def dispatch_engine(
    request: KernelDispatchRequest,
    kernel: AIKernel = Depends(get_kernel),
) -> KernelResponse:
    """Dispatch a single engine call through the kernel.

    The kernel resolves which engine provides the requested capability
    or resource and dispatches the request to it.
    """
    try:
        return await kernel.dispatch(
            request.dispatch,
            execution_id=request.execution_id,
            session_id=request.session_id,
            user_id=request.user_id,
        )
    except KernelException as exc:
        raise HTTPException(status_code=400, detail=exc.error.model_dump(by_alias=True)) from exc


class HumanInputAnswerRequest(BaseModel):
    """The human's answer to a pending human-input/approval request.

    `answer` is intentionally free-form (Any) — a worker asked whatever
    question it needed to, and the answer's shape depends on that
    question (a yes/no, free text, a chosen option, etc.). It is merged
    into the blocked task's payload as `humanInputAnswer` verbatim.
    """

    answer: dict[str, Any] = Field(default_factory=dict)


@router.post("/human-input/{request_id}")
async def resolve_human_input(
    request_id: str,
    request: HumanInputAnswerRequest,
    kernel: AIKernel = Depends(get_kernel),
) -> dict:
    """Deliver a human's answer to a suspended, in-process execution.

    Called by the backend (a separate HTTP service, per the project's
    architecture) once the human has responded in chat. This resumes the
    SAME suspended coroutine that raised the request — no execution is
    reconstructed or replayed; see AIKernel._await_human_input and
    kernel/human_input/pending_input_registry.py for the mechanism.

    Returns 404 if `request_id` is unknown, already resolved, or already
    timed out — e.g. the human answered after the configured wait window
    (default 5 minutes) had already elapsed and the execution moved on
    without the answer.
    """
    resolved = kernel.resolve_human_input(request_id, request.answer)
    if not resolved:
        raise HTTPException(
            status_code=404,
            detail=f"No pending human-input request found for '{request_id}' "
            "(unknown, already answered, or already timed out).",
        )
    return {"status": "accepted", "requestId": request_id}


@router.post("/dispatch-plan", response_model=list[KernelResponse])
async def dispatch_plan(
    request: KernelPlanRequest,
    kernel: AIKernel = Depends(get_kernel),
) -> list[KernelResponse]:
    """Execute a multi-step dispatch plan through the kernel.

    A dispatch plan is a sequence of phases. Each phase is either a single
    engine call or a set of parallel engine calls. The kernel resolves and
    dispatches each step in order.
    """
    try:
        return await kernel.dispatch_plan(
            request.plan,
            execution_id=request.execution_id,
            session_id=request.session_id,
            user_id=request.user_id,
        )
    except KernelException as exc:
        raise HTTPException(status_code=400, detail=exc.error.model_dump(by_alias=True)) from exc


@router.get("/registry")
async def list_registry(container=Depends(get_container)) -> dict:
    """List registered capabilities and resources.

    Returns what the kernel can currently route to — capabilities
    provided by registered engines and resource types they serve.
    """
    return {
        "capabilities": container.capability_registry.list_capabilities(),
        "resources": container.resource_registry.list_resource_types(),
        "engines": [
            {
                "engineId": m.engine_id,
                "name": m.name,
                "version": m.version,
                "status": m.status.value,
                "capabilities": m.capabilities,
                "resources": m.resources,
            }
            for m in container.engine_registry.list_engines()
        ],
    }


@router.get("/health")
async def health() -> dict:
    """Kernel health check."""
    return {"status": "healthy", "service": "ai-kernel"}
