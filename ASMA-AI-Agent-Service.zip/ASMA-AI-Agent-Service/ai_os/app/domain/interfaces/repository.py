from abc import ABC, abstractmethod

from ai_os.app.domain.models.execution import ExecutionContext
from ai_os.app.domain.models.events import KernelEvent
from ai_os.app.domain.models.kernel_request import KernelRequest


class ExecutionRepository(ABC):
    @abstractmethod
    async def save_context(self, context: ExecutionContext) -> None:
        pass

    @abstractmethod
    async def get_context(self, execution_id: str) -> ExecutionContext | None:
        pass

    @abstractmethod
    async def delete_context(self, execution_id: str) -> None:
        pass


class RequestRepository(ABC):
    @abstractmethod
    async def save_request(self, request: KernelRequest) -> None:
        pass

    @abstractmethod
    async def get_request(self, request_id: str) -> KernelRequest | None:
        pass

    @abstractmethod
    async def list_by_execution(self, execution_id: str) -> list[KernelRequest]:
        pass


class EventRepository(ABC):
    @abstractmethod
    async def save_event(self, event: KernelEvent) -> None:
        pass

    @abstractmethod
    async def list_by_execution(self, execution_id: str) -> list[KernelEvent]:
        pass
