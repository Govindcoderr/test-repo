"""ILLMClient — the only interface callers (Supervisor, Planning, Agent
Runtime workers) are allowed to depend on for LLM reasoning.

The Model engine's ClientFactory (see
infrastructure/engines/Model/client_factory.py) is the ONLY place that
constructs a provider SDK client. Every provider adapter
(infrastructure/engines/Model/providers/*) implements this interface and
wraps its own SDK client internally — callers never see the raw SDK
object, only ILLMClient + LLMResponse.

This keeps the boundary the user's design calls for: the Model engine
creates and manages clients; it does not perform inference itself, and
whichever code holds the returned ILLMClient calls generate()/stream()
directly, exactly like using a database connection.
"""

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator

from ai_os.app.domain.models.llm_request import LLMRequest
from ai_os.app.domain.models.llm_response import LLMResponse


class ILLMClient(ABC):
    """Provider-agnostic LLM client contract.

    Fixed input/output shape: every method takes an LLMRequest and returns
    (or yields) LLMResponse — never a provider-native type. Adding a new
    provider means implementing this interface once; it never means
    changing a caller's code.
    """

    @abstractmethod
    async def generate(self, request: LLMRequest) -> LLMResponse:
        """Return a single, complete LLMResponse for the given request."""
        raise NotImplementedError

    @abstractmethod
    async def stream(self, request: LLMRequest) -> AsyncIterator[LLMResponse]:
        """Yield incremental LLMResponse chunks as they arrive.

        Implementations that don't yet support streaming should raise
        NotImplementedError rather than silently falling back to a single
        generate() call, so callers can detect the gap instead of getting
        an unexpected non-streaming response.
        """
        raise NotImplementedError

    @abstractmethod
    async def structured_output(self, request: LLMRequest, schema: dict) -> LLMResponse:
        """Return an LLMResponse whose `content` is JSON matching `schema`.

        `schema` is a JSON Schema dict. Providers that support native
        structured/JSON-mode output should use it; others may fall back to
        prompting + validation, but must still return LLMResponse.
        """
        raise NotImplementedError

    @abstractmethod
    async def health(self) -> bool:
        """Return True if this client can currently reach its provider."""
        raise NotImplementedError
