from abc import ABC, abstractmethod

from ai_os.app.domain.models.kernel_request import KernelRequest
from ai_os.app.domain.models.kernel_response import KernelResponse


class EngineGateway(ABC):
    @abstractmethod
    async def send(self, engine_id: str, request: KernelRequest) -> KernelResponse:
        pass

    @abstractmethod
    async def health_check(self, engine_id: str) -> bool:
        pass

    @abstractmethod
    def register_engine(self, engine_id: str, engine: object) -> None:
        pass
