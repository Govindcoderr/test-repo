from abc import ABC, abstractmethod
from typing import Any

from ai_os.app.domain.models.events import KernelEvent, KernelEventType
from ai_os.app.domain.models.execution import ExecutionContext
from ai_os.app.domain.models.kernel_request import KernelRequest


class ObservabilityService(ABC):
    @abstractmethod
    async def emit(self, event_type: KernelEventType, execution_id: str | None = None,
                   request_id: str | None = None, payload: dict[str, Any] | None = None) -> None:
        pass

    @abstractmethod
    async def log_structured(self, component: str, event: str, status: str,
                             execution_id: str | None = None, request_id: str | None = None,
                             correlation_id: str | None = None, extra: dict[str, Any] | None = None) -> None:
        pass
