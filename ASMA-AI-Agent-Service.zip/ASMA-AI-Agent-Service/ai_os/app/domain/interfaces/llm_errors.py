"""Provider-agnostic LLM error taxonomy.

Every provider adapter (infrastructure/engines/Model/providers/*) MUST
catch its own SDK's exceptions at the boundary and re-raise one of these
instead — this is the one place a provider-specific exception type
(openai.RateLimitError, anthropic.APIStatusError, etc.) is allowed to
appear. Everything above the adapter (ResilientLLMClient's retry/fallback
logic, callers, tests) only ever deals with LLMError and its two
subclasses, so retry/fallback behavior never has to know which provider
raised the error.

    LLMError                    (base — unexpected/unclassified failures)
    ├── LLMTransientError       (retryable: rate limits, timeouts, 5xx,
    │                            connection errors)
    └── LLMPermanentError       (not retryable: bad API key, invalid
                                 request, unknown model, malformed schema)
"""


class LLMError(RuntimeError):
    """Base class for all normalized LLM client errors."""


class LLMTransientError(LLMError):
    """A retryable failure — rate limit, timeout, connection error, 5xx."""


class LLMPermanentError(LLMError):
    """A non-retryable failure — auth failure, invalid request, bad model."""
