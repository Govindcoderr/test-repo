from abc import ABC, abstractmethod

from ai_os.app.domain.models.engine import EngineManifest
from ai_os.app.domain.models.kernel_request import KernelRequest
from ai_os.app.domain.models.kernel_response import KernelResponse


class Engine(ABC):
    """Abstract base for all AI OS engines.

    Every engine must:
    1. Declare a manifest (engine_id, capabilities, resources, priority)
    2. Handle initialization and shutdown lifecycle
    3. Execute kernel requests and return kernel responses

    The kernel discovers what an engine can do via its manifest.
    When a request arrives for a capability/resource that this engine
    provides, the kernel routes the request here via execute().

    To add a new engine:
    - Create a class implementing this interface
    - Define capabilities (what it can do) and resources (what data it serves)
    - Register it with the kernel via container.register_engine(engine)
    """

    @property
    @abstractmethod
    def manifest(self) -> EngineManifest:
        """Return the engine's manifest describing its capabilities and resources."""
        pass

    @abstractmethod
    async def initialize(self) -> None:
        """Initialize the engine (connect to services, load models, etc.)."""
        pass

    @abstractmethod
    async def health_check(self) -> bool:
        """Return True if the engine is healthy and ready to handle requests."""
        pass

    @abstractmethod
    async def execute(self, request: KernelRequest) -> KernelResponse:
        """Execute a kernel request and return a response.

        The request contains:
        - request_type: CAPABILITY_REQUEST or RESOURCE_REQUEST
        - capability: which capability is being invoked (e.g. "model.reason")
        - resource: which resource is being requested (e.g. type="document", id="DOC-123")
        - payload: arbitrary data for the engine to process
        - metadata: routing/tracking metadata

        The response must include:
        - status: SUCCESS, FAILURE, PARTIAL, TIMEOUT, or CANCELLED
        - result: the engine's output data
        - errors: any error details if status is FAILURE
        """
        pass

    @abstractmethod
    async def shutdown(self) -> None:
        """Gracefully shut down the engine (close connections, release resources)."""
        pass
