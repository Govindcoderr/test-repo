from typing import Any

from pydantic import BaseModel, Field


class Permissions(BaseModel):
    database_permission: list[Any] = Field(default_factory=list, alias="databasePermission")
    tool_permission: list[Any] = Field(default_factory=list, alias="toolPermission")
    knowledge_permission: list[Any] = Field(default_factory=list, alias="knowledgePermission")
    memory_permission: list[Any] = Field(default_factory=list, alias="memoryPermission")
    model_permission: list[Any] = Field(default_factory=list, alias="modelPermission")

    model_config = {"populate_by_name": True, "extra": "allow"}
