from typing import Any

from pydantic import BaseModel, Field


class ModelConfiguration(BaseModel):
    provider: str = "openai"
    model_name: str = Field(default="configured-model", alias="modelName")
    temperature: float = 0.2
    max_tokens: int = Field(default=10000, alias="maxTokens")
    streaming: bool = False
    reasoning_node: bool = Field(default=True, alias="reasoningNode")
    # Number of retry attempts ResilientLLMClient makes on a transient
    # failure (rate limit, timeout, connection error, 5xx) before giving up
    # or falling back — see infrastructure/engines/Model/resilient_client.py.
    retry: int = 2
    api_key: str | None = Field(default=None, alias="apiKey")
    is_internal: bool = Field(default=False, alias="isInternal")
    secret_reference: str | None = Field(default=None, alias="secretReference")
    # Only meaningful for providers that support an overridable endpoint
    # (Azure OpenAI, self-hosted/OpenAI-compatible, BYOM, etc.) — omit to
    # use the provider's own SDK default. See
    # infrastructure/engines/Model/providers/openai_provider.py.
    base_url: str | None = Field(default=None, alias="baseUrl")
    timeout: int | None = None
    response_format: str | None = Field(default=None, alias="responseFormat")
    # Optional secondary configuration ResilientLLMClient switches to once
    # the primary's retries are exhausted with a transient error. Nested
    # (rather than a separate provider/model pair of fields) so a fallback
    # can itself point at any provider — e.g. primary=openai/gpt-5,
    # fallback=openai/gpt-4o-mini, or a cross-provider fallback once a
    # second provider exists. A fallback's own `fallback` field is ignored
    # — only one hop is attempted, to avoid unbounded fallback chains.
    fallback: "ModelConfiguration | dict[str, Any] | None" = None

    model_config = {"populate_by_name": True}


ModelConfiguration.model_rebuild()
