from typing import Any

from pydantic import BaseModel, Field

from ai_os.app.domain.models.model_configuration import ModelConfiguration
from ai_os.app.domain.models.permissions import Permissions


class MemoryPolicy(BaseModel):
    enabled: bool = True

    model_config = {"populate_by_name": True, "extra": "allow"}


class SubAgentDefinition(BaseModel):
    sub_agent_id: str = Field(alias="subAgentId")
    name: str
    version: str = "1.0"
    description: str = ""
    responsibility: str = ""
    memory_policy: MemoryPolicy = Field(default_factory=MemoryPolicy, alias="memoryPolicy")
    model_configuration: ModelConfiguration | dict[str, Any] = Field(
        default_factory=dict, alias="modelConfiguration"
    )
    permissions: list[Permissions] = Field(default_factory=list)
    knowledge_sources: list[Any] = Field(default_factory=list, alias="knowledgeSources")
    allowed_tools: list[Any] = Field(default_factory=list, alias="allowedTools")
    metadata: dict[str, Any] = Field(default_factory=dict)
    enabled: bool = True
    execution_time: int | None = Field(default=None, alias="executionTime")

    model_config = {"populate_by_name": True}


class AgentDefinition(BaseModel):
    agent_id: str = Field(alias="agentId")
    name: str
    version: str = "1.0"
    description: str = ""
    responsibility: str = ""
    memory_policy: MemoryPolicy = Field(default_factory=MemoryPolicy, alias="memoryPolicy")
    model_configuration: ModelConfiguration | None = Field(default=None, alias="modelConfiguration")
    permissions: list[Permissions] = Field(default_factory=list)
    knowledge_sources: list[Any] = Field(default_factory=list, alias="knowledgeSources")
    allowed_tools: list[Any] = Field(default_factory=list, alias="allowedTools")
    sub_agents: list[SubAgentDefinition] = Field(default_factory=list, alias="subAgents")
    metadata: dict[str, Any] = Field(default_factory=dict)
    enabled: bool = True
    execution_time: int | None = Field(default=None, alias="executionTime")

    model_config = {"populate_by_name": True}
