"""Kernel output models returned to the backend."""

from typing import Any

from pydantic import BaseModel, Field


class ActivityLog(BaseModel):
    timestamp: str = Field(alias="timeStamp")
    engine: str | None = None
    action: str
    status: str
    duration: float | None = None
    message: str = ""

    model_config = {"populate_by_name": True}


class ModelLogEntry(BaseModel):
    provider: str = ""
    model: str = ""
    prompt_tokens: int = Field(default=0, alias="promptTokens")
    completion_tokens: int = Field(default=0, alias="completionTokens")
    latency: float | None = None
    cost: float | None = None
    retry_count: int = Field(default=0, alias="retryCount")
    finish_reason: str | None = Field(default=None, alias="finishReason")

    model_config = {"populate_by_name": True}


class ToolLogEntry(BaseModel):
    tool_name: str = Field(alias="toolName")
    action: str = "execute"
    input_summary: str = Field(default="", alias="inputSummary")
    output_summary: str = Field(default="", alias="outputSummary")
    status: str = "SUCCESS"
    duration: float | None = None
    retry_count: int = Field(default=0, alias="retryCount")

    model_config = {"populate_by_name": True}


class MemoryLogEntry(BaseModel):
    operation: str
    memory_type: str = Field(alias="memoryType")
    source: str | None = None
    status: str = "SUCCESS"
    records_retrieved: int = Field(default=0, alias="recordsRetrieved")
    records_stored: int = Field(default=0, alias="recordsStored")
    duration: float | None = None
    summary: str | None = None

    model_config = {"populate_by_name": True}


class KnowledgeLogEntry(BaseModel):
    knowledge_source: str | None = Field(default=None, alias="knowledgeSource")
    query: str | None = None
    document_retrieved: int = Field(default=0, alias="documentRetrieved")
    chunks_retrieved: int = Field(default=0, alias="chunksRetrieved")
    average_score: float | None = Field(default=None, alias="averageScore")
    status: str = "SUCCESS"
    duration: float | None = None

    model_config = {"populate_by_name": True}


class ExecutionMetrics(BaseModel):
    execution_time: float | None = Field(default=None, alias="executionTime")
    planning_time: float | None = Field(default=None, alias="planningTime")
    model_time: float | None = Field(default=None, alias="modelTime")
    knowledge_time: float | None = Field(default=None, alias="knowledgeTime")
    memory_time: float | None = Field(default=None, alias="memoryTime")
    tool_time: float | None = Field(default=None, alias="toolTime")
    total_tokens: int = Field(default=0, alias="totalTokens")
    total_cost: float | None = Field(default=None, alias="totalCost")
    total_tool_calls: int = Field(default=0, alias="totalToolCalls")
    total_model_calls: int = Field(default=0, alias="totalModelCalls")

    model_config = {"populate_by_name": True}


class Artifact(BaseModel):
    artifact_id: str = Field(alias="artifactId")
    artifact_type: str = Field(default="document", alias="artifactType")
    name: str = ""
    location: str | None = None
    created_by: str | None = Field(default=None, alias="createdBy")
    created_on: str | None = Field(default=None, alias="createdOn")
    version: str | None = None

    model_config = {"populate_by_name": True}


class ExecutionSummary(BaseModel):
    goal: str | None = None
    workflow_name: str | None = Field(default=None, alias="workflowName")
    execution_type: str | None = Field(default=None, alias="executionType")
    status: str | None = None
    tool_tasks: int = Field(default=0, alias="toolTasks")
    completed_tasks: int = Field(default=0, alias="completedTasks")
    failed_tasks: int = Field(default=0, alias="failedTasks")
    skipped_tasks: int = Field(default=0, alias="skippedTasks")
    total_agents: int = Field(default=0, alias="totalAgents")
    total_sub_agents: int = Field(default=0, alias="totalSubAgents")
    total_tools_used: int = Field(default=0, alias="totalToolsUsed")
    total_models_used: int = Field(default=0, alias="totalModelsUsed")
    execution_duration: float | None = Field(default=None, alias="executionDuration")
    started_on: str | None = Field(default=None, alias="startedOn")
    completed_on: str | None = Field(default=None, alias="completedOn")
    completed_reason: str | None = Field(default=None, alias="completedReason")
    final_message: str | None = Field(default=None, alias="finalMessage")

    model_config = {"populate_by_name": True}


class SubAgentResponse(BaseModel):
    sub_agent_id: str = Field(alias="subAgentId")
    sub_agent_name: str = Field(alias="subAgentName")
    status: str = "COMPLETED"
    execution_time: float | None = Field(default=None, alias="executionTime")
    response: Any | None = None
    execution_summary: list[ExecutionSummary] = Field(default_factory=list, alias="executionSummary")
    execution_metrics: ExecutionMetrics = Field(default_factory=ExecutionMetrics, alias="executionMetrics")
    model_logs: list[ModelLogEntry] = Field(default_factory=list, alias="modelLogs")
    tool_logs: list[ToolLogEntry] = Field(default_factory=list, alias="toolLogs")
    memory_logs: list[MemoryLogEntry] = Field(default_factory=list, alias="memoryLogs")
    knowledge_logs: list[KnowledgeLogEntry] = Field(default_factory=list, alias="knowledgeLogs")

    model_config = {"populate_by_name": True}


class AgentResponse(BaseModel):
    agent_id: str = Field(alias="agentId")
    agent_name: str = Field(alias="agentName")
    status: str = "COMPLETED"
    execution_time: float | None = Field(default=None, alias="executionTime")
    response: Any | None = None
    execution_summary: list[ExecutionSummary] = Field(default_factory=list, alias="executionSummary")
    execution_metrics: ExecutionMetrics = Field(default_factory=ExecutionMetrics, alias="executionMetrics")
    model_logs: list[ModelLogEntry] = Field(default_factory=list, alias="modelLogs")
    tool_logs: list[ToolLogEntry] = Field(default_factory=list, alias="toolLogs")
    memory_logs: list[MemoryLogEntry] = Field(default_factory=list, alias="memoryLogs")
    knowledge_logs: list[KnowledgeLogEntry] = Field(default_factory=list, alias="knowledgeLogs")
    sub_agents: list[SubAgentResponse] = Field(default_factory=list, alias="subAgents")

    model_config = {"populate_by_name": True}


class ExecutionResponse(BaseModel):
    execution_id: str = Field(alias="executionId")
    session_id: str = Field(alias="sessionId")
    # Memory space identifier for this conversation — pass this back in on
    # the next ExecutionRequest to continue with the same conversation
    # history. See infrastructure/memory/json_memory_store.py.
    memory_id: str | None = Field(default=None, alias="memoryId")
    status: str
    started_on: str | None = Field(default=None, alias="startedOn")
    completed_on: str | None = Field(default=None, alias="completedOn")
    final_response: Any | None = Field(default=None, alias="finalResponse")
    artifacts: list[Artifact] = Field(default_factory=list)
    agent: AgentResponse | None = None
    activity_logs: list[ActivityLog] = Field(default_factory=list, alias="activityLogs")
    # Full, untruncated result returned by each engine step in the dynamic
    # execution loop, in dispatch order — e.g. Supervisor's understand_goal
    # result, Planning's create_plan result, etc. Unlike activityLogs
    # (which only stores a short resultSummary string), this carries the
    # engine's complete result dict for inspection/debugging.
    step_results: list[dict[str, Any]] = Field(default_factory=list, alias="stepResults")
    warnings: list[str] = Field(default_factory=list)
    errors: list[dict[str, Any]] = Field(default_factory=list)
    execution_metrics: ExecutionMetrics = Field(default_factory=ExecutionMetrics, alias="executionMetrics")
    execution_state: str = Field(alias="executionState")

    model_config = {"populate_by_name": True}
