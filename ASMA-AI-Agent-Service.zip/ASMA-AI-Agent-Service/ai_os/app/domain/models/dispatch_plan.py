from typing import Any

from pydantic import BaseModel, Field


class EngineDispatchItem(BaseModel):
    """A single engine call requested by the backend or another engine via the kernel."""

    step_id: str | None = Field(default=None, alias="stepId")
    step_name: str | None = Field(default=None, alias="stepName")
    request_type: str = Field(default="CAPABILITY_REQUEST", alias="requestType")
    capability: str | None = None
    resource: dict[str, Any] | None = None
    payload: dict[str, Any] = Field(default_factory=dict)
    source_type: str = Field(default="backend", alias="sourceType")
    source_id: str = Field(default="api", alias="sourceId")
    timeout: int = 30

    model_config = {"populate_by_name": True}


class DispatchPlan(BaseModel):
    """Backend-defined engine dispatch sequence for the kernel OS layer.

    Each phase is either:
    - A single dispatch item dict (capability/resource request)
    - A dict with key "parallel" containing a list of dispatch items
    """

    phases: list[dict[str, Any]] = Field(default_factory=list)

    model_config = {"populate_by_name": True}
