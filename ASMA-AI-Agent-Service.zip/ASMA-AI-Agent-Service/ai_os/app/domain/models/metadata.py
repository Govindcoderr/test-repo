from typing import Any

from pydantic import BaseModel, Field


class RequestMetadata(BaseModel):
    department: str | None = None
    customer: str | None = None
    priority: str | None = None
    region: str | None = None
    business_unit: str | None = Field(default=None, alias="businessUnit")
    project: str | None = None
    custom_attribute: dict[str, Any] = Field(default_factory=dict, alias="customAttribute")

    model_config = {"populate_by_name": True, "extra": "allow"}
