from typing import Any

from pydantic import BaseModel, Field, model_validator

from ai_os.app.domain.models.agent import AgentDefinition
from ai_os.app.domain.models.attachment import Attachment
from ai_os.app.domain.models.execution_state import ExecutionState
from ai_os.app.domain.models.kernel_request import KernelRequest
from ai_os.app.domain.models.kernel_response import KernelResponse
from ai_os.app.domain.models.metadata import RequestMetadata
from ai_os.app.domain.models.permissions import Permissions
from ai_os.app.domain.models.runtime_configuration import RuntimeConfiguration


class ExecutionOptions(BaseModel):
    save_memory: bool = Field(default=True, alias="saveMemory")
    enable_knowledge: bool = Field(default=True, alias="enableKnowledge")
    enable_planning: bool = Field(default=True, alias="enablePlanning")
    enable_supervisor: bool = Field(default=True, alias="enableSupervisor")
    enable_agent: bool = Field(default=False, alias="enableAgent")
    debug_mode: bool = Field(default=False, alias="debugMode")

    model_config = {"populate_by_name": True, "extra": "allow"}


class ExecutionRequest(BaseModel):
    """Backend → Kernel input contract."""

    execution_id: str | None = Field(default=None, alias="executionId")
    session_id: str = Field(alias="sessionId")
    user_id: str = Field(alias="userId")
    tenant_id: str | None = Field(default=None, alias="tenantId")
    parent_execution_id: str | None = Field(default=None, alias="parentExecutionId")
    correlation_id: str | None = Field(default=None, alias="correlationId")
    request_timestamp: str | None = Field(default=None, alias="requestTimeStamp")
    user_query: str = Field(default="", alias="userQuery")
    attachments: list[Attachment] = Field(default_factory=list)
    execution_options: ExecutionOptions = Field(default_factory=ExecutionOptions, alias="executionOptions")
    metadata: RequestMetadata | dict[str, Any] = Field(default_factory=dict)
    agent_definition: AgentDefinition | None = Field(default=None, alias="agentDefinition")
    # Identifies the memory space for this conversation. Omit on the first
    # call of a conversation — the kernel's fallback memory store mints a
    # new one and returns it via ExecutionResponse.memoryId for reuse on
    # subsequent requests. See infrastructure/memory/json_memory_store.py.
    memory_id: str | None = Field(default=None, alias="memoryId")
    runtime_configuration: RuntimeConfiguration = Field(
        default_factory=RuntimeConfiguration, alias="runtimeConfiguration"
    )

    model_config = {"populate_by_name": True}

    @model_validator(mode="before")
    @classmethod
    def normalize_legacy_fields(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        if "agentDefinition" not in data and "agent" in data:
            data["agentDefinition"] = data.pop("agent")
        return data


class ModelLog(BaseModel):
    request_id: str = Field(alias="requestId")
    model_provider: str = Field(alias="modelProvider")
    model_name: str = Field(alias="modelName")
    started_at: str | None = Field(default=None, alias="startedAt")
    completed_at: str | None = Field(default=None, alias="completedAt")
    input_tokens: int = Field(default=0, alias="inputTokens")
    output_tokens: int = Field(default=0, alias="outputTokens")
    total_tokens: int = Field(default=0, alias="totalTokens")
    latency: float | None = None
    # USD cost estimate for this call — see
    # infrastructure/engines/Model/pricing.py::estimate_cost. None (never
    # 0.0) when the model isn't in the pricing table.
    cost: float | None = None
    finish_reason: str | None = Field(default=None, alias="finishReason")
    status: str = "SUCCESS"
    error: str | None = None

    model_config = {"populate_by_name": True}


class MemoryLog(BaseModel):
    request_id: str = Field(alias="requestId")
    operation: str
    memory_type: str = Field(alias="memoryType")
    records_read: int = Field(default=0, alias="recordsRead")
    records_written: int = Field(default=0, alias="recordsWritten")
    started_at: str | None = Field(default=None, alias="startedAt")
    completed_at: str | None = Field(default=None, alias="completedAt")
    status: str = "SUCCESS"

    model_config = {"populate_by_name": True}


class KnowledgeLog(BaseModel):
    request_id: str = Field(alias="requestId")
    operation: str
    query: str | None = None
    source: str | None = None
    documents_retrieved: int = Field(default=0, alias="documentsRetrieved")
    chunks_retrieved: int = Field(default=0, alias="chunksRetrieved")
    latency: float | None = None
    status: str = "SUCCESS"

    model_config = {"populate_by_name": True}


class ToolLog(BaseModel):
    request_id: str = Field(alias="requestId")
    tool_name: str = Field(alias="toolName")
    operation: str
    parameters_summary: str = Field(default="", alias="parametersSummary")
    started_at: str | None = Field(default=None, alias="startedAt")
    completed_at: str | None = Field(default=None, alias="completedAt")
    duration: float | None = None
    status: str = "SUCCESS"
    error: str | None = None

    model_config = {"populate_by_name": True}


class ExecutionContext(BaseModel):
    execution_id: str = Field(alias="executionId")
    session_id: str = Field(alias="sessionId")
    user_id: str = Field(alias="userId")
    tenant_id: str | None = Field(default=None, alias="tenantId")
    parent_execution_id: str | None = Field(default=None, alias="parentExecutionId")
    correlation_id: str | None = Field(default=None, alias="correlationId")
    request_timestamp: str | None = Field(default=None, alias="requestTimeStamp")
    agent: AgentDefinition
    sub_agents: list = Field(default_factory=list, alias="subAgents")
    user_query: str = Field(alias="userQuery")
    attachments: list[Attachment] = Field(default_factory=list)
    execution_options: ExecutionOptions = Field(default_factory=ExecutionOptions, alias="executionOptions")
    metadata: dict[str, Any] = Field(default_factory=dict)
    memory_id: str | None = Field(default=None, alias="memoryId")
    permissions: list[Permissions] = Field(default_factory=list)
    runtime_configuration: RuntimeConfiguration = Field(
        default_factory=RuntimeConfiguration, alias="runtimeConfiguration"
    )
    model_configuration: dict[str, Any] | None = Field(default=None, alias="modelConfiguration")
    current_state: ExecutionState = Field(default=ExecutionState.CREATED, alias="currentState")
    current_step: str | None = Field(default=None, alias="currentStep")
    conversation_context: dict[str, Any] = Field(default_factory=dict, alias="conversationContext")
    memory_context: dict[str, Any] = Field(default_factory=dict, alias="memoryContext")
    knowledge_context: dict[str, Any] = Field(default_factory=dict, alias="knowledgeContext")
    tool_results: list[dict[str, Any]] = Field(default_factory=list, alias="toolResults")
    artifacts: list[dict[str, Any]] = Field(default_factory=list)
    execution_events: list[dict[str, Any]] = Field(default_factory=list, alias="executionEvents")
    pending_requests: list[KernelRequest] = Field(default_factory=list, alias="pendingRequests")
    completed_requests: list[KernelRequest] = Field(default_factory=list, alias="completedRequests")
    failed_requests: list[KernelRequest] = Field(default_factory=list, alias="failedRequests")
    metrics: dict[str, Any] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)
    errors: list[dict[str, Any]] = Field(default_factory=list)
    final_response: str | None = Field(default=None, alias="finalResponse")
    engines_used: list[str] = Field(default_factory=list, alias="enginesUsed")
    capabilities_used: list[str] = Field(default_factory=list, alias="capabilitiesUsed")
    retry_count: int = Field(default=0, alias="retryCount")
    started_at: str | None = Field(default=None, alias="startedAt")
    completed_at: str | None = Field(default=None, alias="completedAt")
    model_logs: list[ModelLog] = Field(default_factory=list, alias="modelLogs")
    memory_logs: list[MemoryLog] = Field(default_factory=list, alias="memoryLogs")
    knowledge_logs: list[KnowledgeLog] = Field(default_factory=list, alias="knowledgeLogs")
    tool_logs: list[ToolLog] = Field(default_factory=list, alias="toolLogs")
    activity_logs: list[dict[str, Any]] = Field(default_factory=list, alias="activityLogs")
    execution_logs: list[dict[str, Any]] = Field(default_factory=list, alias="executionLogs")
    steps_executed: int = Field(default=0, alias="stepsExecuted")
    strategy: dict[str, Any] = Field(default_factory=dict)
    workflow_plan: dict[str, Any] = Field(default_factory=dict, alias="workflowPlan")
    sub_agent_results: dict[str, Any] = Field(default_factory=dict, alias="subAgentResults")
    active_scope: str = Field(default="main_agent", alias="activeScope")

    # Dynamic execution loop state
    step_results: list[dict[str, Any]] = Field(default_factory=list, alias="stepResults")
    last_step_result: dict[str, Any] | None = Field(default=None, alias="lastStepResult")
    worker_states: dict[str, Any] = Field(default_factory=dict, alias="workerStates")
    iteration_count: int = Field(default=0, alias="iterationCount")

    # Per-task results from a Planning-generated workflow, keyed by taskId
    # (not by capability — step_results is capability-keyed and ordered,
    # this is task-identity-keyed so a dependent task's dependencies can be
    # looked up directly regardless of how many steps ran in between).
    # Populated once a worker/Agent Runtime capability completes a specific
    # task — see AIKernel's task-dispatch dependency-resolution mechanism
    # (not yet wired up; Agent Runtime doesn't exist yet, but this field
    # and record_task_result() are ready for it).
    task_results: dict[str, Any] = Field(default_factory=dict, alias="taskResults")

    # Number of times supervisor.validate_result has sent the workflow back
    # to Planning for revision (outcome=needs_more_planning). Incremented by
    # ResponseCorrelator and used by SupervisorEngine to cap revision loops.
    revision_count: int = Field(default=0, alias="revisionCount")

    # Set by AIKernel when it force-routes to supervisor.validate_result
    # after an engine failure or dispatch error, so validate_result knows
    # this pass was triggered by a break in the workflow rather than a
    # normal engine-driven hand-off.
    forced_validation: bool = Field(default=False, alias="forcedValidation")

    # Record of the currently outstanding human-input request, if any —
    # informational only (visible in ExecutionResponse for observability).
    # The actual suspension mechanism (the asyncio.Future) lives in
    # PendingInputRegistry, not here, since a Future cannot be persisted
    # on this Pydantic model. Cleared once the pause is resolved (answered
    # or timed out). See AIKernel._await_human_input.
    pending_human_input: dict[str, Any] | None = Field(default=None, alias="pendingHumanInput")

    model_config = {"populate_by_name": True, "arbitrary_types_allowed": True}

    def record_engine_use(self, engine_id: str) -> None:
        if engine_id not in self.engines_used:
            self.engines_used.append(engine_id)

    def record_capability_use(self, capability: str) -> None:
        if capability not in self.capabilities_used:
            self.capabilities_used.append(capability)

    def record_step_result(self, capability: str, result: dict[str, Any]) -> None:
        """Record a step result from the execution loop."""
        entry = {"capability": capability, "result": result}
        self.step_results.append(entry)
        self.last_step_result = result

    def record_task_result(self, task_id: str, result: Any) -> None:
        """Record a specific task's result, keyed by taskId.

        Used to resolve a task's dependency inputs by ID once Agent
        Runtime dispatches Planning-generated workflow tasks — see
        AIKernel's task-dependency-resolution mechanism.
        """
        self.task_results[task_id] = result
