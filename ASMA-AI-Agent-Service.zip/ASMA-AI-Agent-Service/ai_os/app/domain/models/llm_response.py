"""Standardized LLM response contract.

Every provider adapter inside the Model engine (see
infrastructure/engines/Model/providers/) converts whatever shape its own
SDK returns into this model before handing it back through ILLMClient.
Callers (Supervisor, Planning, and eventually Agent Runtime workers) only
ever see this shape — never a raw OpenAI/Anthropic/Gemini response object.
"""

from typing import Any

from pydantic import BaseModel, Field


class TokenUsage(BaseModel):
    prompt_tokens: int = Field(default=0, alias="promptTokens")
    completion_tokens: int = Field(default=0, alias="completionTokens")
    total_tokens: int = Field(default=0, alias="totalTokens")

    model_config = {"populate_by_name": True}


class LLMResponse(BaseModel):
    """Provider-agnostic result of a single generate() call."""

    content: str = ""
    finish_reason: str | None = Field(default=None, alias="finishReason")
    tool_calls: list[dict[str, Any]] = Field(default_factory=list, alias="toolCalls")
    usage: TokenUsage = Field(default_factory=TokenUsage)
    # Wall-clock time the call took, measured by the provider adapter
    # around its own SDK call — set for every generate()/structured_output()
    # response; streaming's final chunk carries the accumulated total.
    latency_ms: float | None = Field(default=None, alias="latencyMs")
    # Computed from usage + a static per-model pricing table (see
    # infrastructure/engines/Model/pricing.py). None (never 0.0) when the
    # model isn't in the pricing table — a missing price should never be
    # silently reported as free.
    cost: float | None = None
    # Free-form, adapter-specific extras (e.g. model name actually served,
    # system fingerprint) that don't belong in the fixed fields above but
    # are still worth keeping around for observability.
    metadata: dict[str, Any] = Field(default_factory=dict)
    # The untouched, provider-native response object/dict — kept only for
    # debugging/observability. Callers should never rely on its shape;
    # doing so reintroduces the provider-branching this contract exists to
    # avoid. Excluded from serialization by default since it's not JSON-safe
    # for every provider.
    raw_response: Any = Field(default=None, alias="rawResponse", exclude=True)

    model_config = {"populate_by_name": True, "arbitrary_types_allowed": True}
