from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class RequestType(str, Enum):
    CAPABILITY_REQUEST = "CAPABILITY_REQUEST"
    RESOURCE_REQUEST = "RESOURCE_REQUEST"
    EXECUTION_REQUEST = "EXECUTION_REQUEST"
    SUB_AGENT_EXECUTION = "SUB_AGENT_EXECUTION"


class Priority(str, Enum):
    LOW = "LOW"
    NORMAL = "NORMAL"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class RequestSource(BaseModel):
    type: str
    id: str


class RequestTarget(BaseModel):
    engine_id: str = Field(alias="engineId")
    type: str = "engine"

    model_config = {"populate_by_name": True}


class ResourceRef(BaseModel):
    type: str
    id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class RetryPolicy(BaseModel):
    max_retries: int = Field(default=2, alias="maxRetries")
    retry_delay_seconds: float = Field(default=0.5, alias="retryDelaySeconds")
    backoff_multiplier: float = Field(default=2.0, alias="backoffMultiplier")
    retryable_errors: list[str] = Field(default_factory=list, alias="retryableErrors")
    non_retryable_errors: list[str] = Field(default_factory=list, alias="nonRetryableErrors")

    model_config = {"populate_by_name": True}


class KernelRequest(BaseModel):
    request_id: str = Field(alias="requestId")
    execution_id: str = Field(alias="executionId")
    parent_request_id: str | None = Field(default=None, alias="parentRequestId")
    correlation_id: str = Field(alias="correlationId")
    session_id: str = Field(alias="sessionId")
    source: RequestSource
    target: RequestTarget | None = None
    request_type: RequestType = Field(alias="requestType")
    capability: str | None = None
    resource: ResourceRef | None = None
    payload: dict[str, Any] = Field(default_factory=dict)
    context_reference: str | None = Field(default=None, alias="contextReference")
    metadata: dict[str, Any] = Field(default_factory=dict)
    priority: Priority = Priority.NORMAL
    timeout: int = 30
    retry_policy: RetryPolicy = Field(default_factory=RetryPolicy, alias="retryPolicy")

    model_config = {"populate_by_name": True}
