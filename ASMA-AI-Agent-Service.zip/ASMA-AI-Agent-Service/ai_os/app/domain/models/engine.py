from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class EngineStatus(str, Enum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"
    DEGRADED = "DEGRADED"
    UNAVAILABLE = "UNAVAILABLE"


class EngineManifest(BaseModel):
    engine_id: str = Field(alias="engineId")
    name: str
    version: str = "1.0.0"
    description: str = ""
    status: EngineStatus = EngineStatus.ACTIVE
    capabilities: list[str] = Field(default_factory=list)
    resources: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    priority: int = 100

    model_config = {"populate_by_name": True}


class CapabilityRegistration(BaseModel):
    capability: str
    engine_id: str = Field(alias="engineId")
    version: str = "1.0.0"
    priority: int = 100
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class ResourceRegistration(BaseModel):
    resource_type: str = Field(alias="resourceType")
    engine_id: str = Field(alias="engineId")
    version: str = "1.0.0"
    priority: int = 100
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class ProviderInfo(BaseModel):
    engine_id: str = Field(alias="engineId")
    priority: int = 100
    status: EngineStatus = EngineStatus.ACTIVE
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}
