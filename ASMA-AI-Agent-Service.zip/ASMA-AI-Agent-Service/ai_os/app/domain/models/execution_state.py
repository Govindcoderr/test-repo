from enum import Enum


class ExecutionState(str, Enum):
    CREATED = "CREATED"
    INITIALIZING = "INITIALIZING"
    VALIDATING = "VALIDATING"
    SUPERVISING = "SUPERVISING"
    PLANNING = "PLANNING"
    PREPARING_CONTEXT = "PREPARING_CONTEXT"
    EXECUTING = "EXECUTING"
    WAITING = "WAITING"
    RESUMING = "RESUMING"
    VALIDATING_RESULT = "VALIDATING_RESULT"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    PAUSED = "PAUSED"
    TIMED_OUT = "TIMED_OUT"


VALID_TRANSITIONS: dict[ExecutionState, set[ExecutionState]] = {
    ExecutionState.CREATED: {ExecutionState.INITIALIZING, ExecutionState.CANCELLED},
    ExecutionState.INITIALIZING: {ExecutionState.VALIDATING, ExecutionState.FAILED, ExecutionState.CANCELLED},
    ExecutionState.VALIDATING: {ExecutionState.SUPERVISING, ExecutionState.EXECUTING, ExecutionState.FAILED, ExecutionState.CANCELLED},
    ExecutionState.SUPERVISING: {ExecutionState.PLANNING, ExecutionState.PREPARING_CONTEXT, ExecutionState.EXECUTING, ExecutionState.FAILED},
    ExecutionState.PLANNING: {ExecutionState.PREPARING_CONTEXT, ExecutionState.EXECUTING, ExecutionState.FAILED},
    ExecutionState.PREPARING_CONTEXT: {ExecutionState.EXECUTING, ExecutionState.FAILED},
    ExecutionState.EXECUTING: {
        ExecutionState.WAITING,
        ExecutionState.VALIDATING_RESULT,
        ExecutionState.COMPLETED,
        ExecutionState.FAILED,
        ExecutionState.PAUSED,
        ExecutionState.TIMED_OUT,
    },
    ExecutionState.WAITING: {ExecutionState.RESUMING, ExecutionState.EXECUTING, ExecutionState.FAILED, ExecutionState.CANCELLED, ExecutionState.TIMED_OUT},
    ExecutionState.RESUMING: {ExecutionState.EXECUTING, ExecutionState.FAILED},
    ExecutionState.VALIDATING_RESULT: {ExecutionState.COMPLETED, ExecutionState.EXECUTING, ExecutionState.FAILED},
    ExecutionState.PAUSED: {ExecutionState.RESUMING, ExecutionState.CANCELLED},
    ExecutionState.TIMED_OUT: {ExecutionState.FAILED, ExecutionState.EXECUTING},
    ExecutionState.COMPLETED: set(),
    ExecutionState.FAILED: set(),
    ExecutionState.CANCELLED: set(),
}


def can_transition(from_state: ExecutionState, to_state: ExecutionState) -> bool:
    return to_state in VALID_TRANSITIONS.get(from_state, set())
