"""Standardized LLM request contract.

Fixed input shape for every ILLMClient call (see
domain/interfaces/llm_client.py) — callers build one of these instead of
passing loose args, so adding a field (e.g. tool schemas, response
format override) never requires touching every provider adapter's method
signature.
"""

from typing import Any

from pydantic import BaseModel, Field


class LLMMessage(BaseModel):
    role: str  # "system" | "user" | "assistant"
    content: str


class LLMRequest(BaseModel):
    """Input to ILLMClient.generate()/stream()/structured_output()."""

    messages: list[LLMMessage] = Field(default_factory=list)
    # Per-call overrides — None means "use the client's configured
    # default" (set at construction time from ModelConfiguration).
    temperature: float | None = None
    max_tokens: int | None = Field(default=None, alias="maxTokens")
    response_format: str | None = Field(default=None, alias="responseFormat")
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}

    @classmethod
    def from_system_user(cls, system: str, user: str) -> "LLMRequest":
        """Convenience constructor for the common system+user prompt pair."""
        return cls(
            messages=[
                LLMMessage(role="system", content=system),
                LLMMessage(role="user", content=user),
            ]
        )
