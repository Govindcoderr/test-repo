from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class KernelEventType(str, Enum):
    EXECUTION_CREATED = "EXECUTION_CREATED"
    REQUEST_RECEIVED = "REQUEST_RECEIVED"
    REQUEST_VALIDATED = "REQUEST_VALIDATED"
    CAPABILITY_RESOLVED = "CAPABILITY_RESOLVED"
    RESOURCE_RESOLVED = "RESOURCE_RESOLVED"
    PROVIDER_SELECTED = "PROVIDER_SELECTED"
    REQUEST_DISPATCHED = "REQUEST_DISPATCHED"
    ENGINE_RESPONSE_RECEIVED = "ENGINE_RESPONSE_RECEIVED"
    CONTEXT_UPDATED = "CONTEXT_UPDATED"
    RETRY_STARTED = "RETRY_STARTED"
    REQUEST_FAILED = "REQUEST_FAILED"
    EXECUTION_COMPLETED = "EXECUTION_COMPLETED"
    EXECUTION_FAILED = "EXECUTION_FAILED"
    STATE_CHANGED = "STATE_CHANGED"


class KernelEvent(BaseModel):
    event_id: str = Field(alias="eventId")
    event_type: KernelEventType = Field(alias="eventType")
    timestamp: str
    execution_id: str | None = Field(default=None, alias="executionId")
    request_id: str | None = Field(default=None, alias="requestId")
    source: str = "kernel"
    payload: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}
