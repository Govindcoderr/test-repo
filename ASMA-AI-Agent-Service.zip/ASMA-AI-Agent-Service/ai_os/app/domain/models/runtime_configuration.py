from pydantic import BaseModel, Field


class RuntimeConfiguration(BaseModel):
    max_execution_time: int | None = Field(default=None, alias="maxExecutionTime")
    max_parallel_agents: int = Field(default=3, alias="maxParallelAgents")
    checkpoints_enabled: bool = Field(default=False, alias="checkpointsEnabled")
    auto_retry: bool = Field(default=True, alias="autoRetry")
    streaming_enabled: bool = Field(default=False, alias="streamingEnabled")
    debug_mode: bool = Field(default=False, alias="debugMode")
    human_approval_required: bool = Field(default=False, alias="humanApprovalRequired")
    notification_enabled: bool = Field(default=False, alias="notificationEnabled")

    model_config = {"populate_by_name": True}
