from pydantic import BaseModel, Field


class Attachment(BaseModel):
    file_id: str = Field(alias="fileId")
    file_name: str = Field(alias="fileName")
    mime_type: str = Field(alias="mimeType")
    storage_path: str = Field(alias="storagePath")
    size: int
    attachment_type: str | None = Field(default=None, alias="attachmentType")
    document_id: str | None = Field(default=None, alias="documentId")

    model_config = {"populate_by_name": True}
