from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class ResponseStatus(str, Enum):
    SUCCESS = "SUCCESS"
    FAILURE = "FAILURE"
    PARTIAL = "PARTIAL"
    TIMEOUT = "TIMEOUT"
    CANCELLED = "CANCELLED"


class NextStep(BaseModel):
    """Directive from an engine telling the kernel what to dispatch next.

    This is the primary mechanism for dynamic flow control.
    Engines return a NextStep to chain execution to another engine
    without the kernel needing to know the business flow.
    """

    capability: str | None = None
    resource: dict[str, Any] | None = None
    payload: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class NextIntent(BaseModel):
    """Legacy intent model — kept for backward compatibility."""

    intent_type: str = Field(alias="intentType")
    capability: str | None = None
    resource: dict[str, Any] | None = None
    task: dict[str, Any] | None = None
    payload: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class KernelResponse(BaseModel):
    request_id: str = Field(alias="requestId")
    execution_id: str = Field(alias="executionId")
    parent_request_id: str | None = Field(default=None, alias="parentRequestId")
    correlation_id: str = Field(alias="correlationId")
    status: ResponseStatus
    result: dict[str, Any] | None = None
    artifacts: list[dict[str, Any]] = Field(default_factory=list)
    metrics: dict[str, Any] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)
    errors: list[dict[str, Any]] = Field(default_factory=list)

    # Dynamic flow control — engines use these to direct the kernel
    next_step: NextStep | None = Field(default=None, alias="nextStep")
    next_steps: list[NextStep] = Field(default_factory=list, alias="nextSteps")

    # Directive for what to call after parallel nextSteps complete
    after_parallel: NextStep | None = Field(default=None, alias="afterParallel")

    # Legacy field
    next_intents: list[NextIntent] = Field(default_factory=list, alias="nextIntents")

    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}
