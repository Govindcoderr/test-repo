"""Base engine implementation for AI OS engines.

All concrete engines should extend BaseEngine. It provides:
- Manifest management
- Lifecycle tracking (initialized state)
- Helper methods for building responses
- Standard health check behavior

Example usage:
    class MyModelEngine(BaseEngine):
        def __init__(self):
            super().__init__(
                EngineManifest(
                    engineId="my-model-engine",
                    name="My Model Engine",
                    version="1.0.0",
                    capabilities=["model.reason", "model.summarize"],
                    resources=[],
                    priority=100,
                )
            )

        async def execute(self, request: KernelRequest) -> KernelResponse:
            # Your engine logic here
            result = await self._do_reasoning(request.payload)
            return self._success(request, result)
"""

from ai_os.app.domain.interfaces.engine import Engine
from ai_os.app.domain.models.engine import EngineManifest, EngineStatus
from ai_os.app.domain.models.kernel_request import KernelRequest
from ai_os.app.domain.models.kernel_response import KernelResponse, ResponseStatus


class BaseEngine(Engine):
    """Base class for all AI OS engine implementations.

    Provides lifecycle management and response builder helpers.
    Subclasses must implement execute() with their domain logic.
    """

    def __init__(self, manifest: EngineManifest) -> None:
        self._manifest = manifest
        self._initialized = False

    @property
    def manifest(self) -> EngineManifest:
        return self._manifest

    async def initialize(self) -> None:
        """Override to add custom initialization logic."""
        self._initialized = True

    async def health_check(self) -> bool:
        return self._initialized and self._manifest.status == EngineStatus.ACTIVE

    async def execute(self, request: KernelRequest) -> KernelResponse:
        raise NotImplementedError(
            f"Engine '{self._manifest.engine_id}' must implement execute()"
        )

    async def shutdown(self) -> None:
        """Override to add custom shutdown logic."""
        self._initialized = False

    # ─── Response Helpers ───────────────────────────────────────────────

    def _success(
        self,
        request: KernelRequest,
        result: dict,
        metadata: dict | None = None,
    ) -> KernelResponse:
        """Build a SUCCESS response."""
        return KernelResponse(
            requestId=request.request_id,
            executionId=request.execution_id,
            parentRequestId=request.parent_request_id,
            correlationId=request.correlation_id,
            status=ResponseStatus.SUCCESS,
            result=result,
            metadata={"sourceEngineId": self._manifest.engine_id, **(metadata or {})},
        )

    def _failure(
        self,
        request: KernelRequest,
        code: str,
        message: str,
        retryable: bool = False,
    ) -> KernelResponse:
        """Build a FAILURE response."""
        return KernelResponse(
            requestId=request.request_id,
            executionId=request.execution_id,
            parentRequestId=request.parent_request_id,
            correlationId=request.correlation_id,
            status=ResponseStatus.FAILURE,
            errors=[{"code": code, "message": message, "retryable": retryable}],
            metadata={"sourceEngineId": self._manifest.engine_id},
        )

    def _partial(
        self,
        request: KernelRequest,
        result: dict,
        warnings: list[str] | None = None,
    ) -> KernelResponse:
        """Build a PARTIAL response (some data available but incomplete)."""
        return KernelResponse(
            requestId=request.request_id,
            executionId=request.execution_id,
            parentRequestId=request.parent_request_id,
            correlationId=request.correlation_id,
            status=ResponseStatus.PARTIAL,
            result=result,
            warnings=warnings or [],
            metadata={"sourceEngineId": self._manifest.engine_id},
        )
