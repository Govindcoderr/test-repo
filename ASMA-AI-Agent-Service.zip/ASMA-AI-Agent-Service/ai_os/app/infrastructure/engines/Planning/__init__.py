"""Planning engine package.

Exposes a single capability, planning.create_plan, which:
1. Breaks the query (+ Supervisor's goal analysis) into meaningful tasks.
2. Analyzes dependencies between those tasks.
3. Converts the task list into an ordered workflow, grouping independent
   tasks into parallel phases where dependencies allow.

See planning_engine.py for the concrete implementation.
"""

from ai_os.app.infrastructure.engines.Planning.planning_engine import PlanningEngine

__all__ = ["PlanningEngine"]
