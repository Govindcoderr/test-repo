"""Planning engine.

Exposes a single capability, planning.create_plan, invoked by Supervisor's
understand_goal stage (and re-invoked by validate_result's
needs_more_planning outcome for revisions). It is responsible for:

    planning.create_plan
        1. Break query in meaningful tasks — an LLM call decomposes the
           user's query (+ Supervisor's goal analysis) into concrete tasks.
        2. Dependency analysis — the same LLM call determines which tasks
           depend on which others.
        3. Convert tasks into a workflow — done DETERMINISTICALLY (not by
           the LLM) via topological sort: tasks with no unmet dependencies
           are grouped into sequential phases.
        4. Parallel task planning — phases in that topological ordering are
           expressed such that independent tasks within a phase can run in
           parallel (they have no dependency relationship to each other).

        For now (no Agent Runtime engine yet to execute the workflow),
        this capability sets next_step to "supervisor.validate_result" so
        the mandatory validation gate still runs and the workflow completes
        cleanly end-to-end. Once Agent Runtime exists, this next_step will
        be changed to hand the workflow off for actual execution instead.

        Human-in-the-loop (rare — used sparingly): if the LLM's analysis
        sets needsClarification=true (see schemas.PlanAnalysis), this
        raises the same result["humanInputRequired"] signal Supervisor's
        understand_goal stage uses (see AIKernel._await_human_input) —
        the kernel suspends the whole execution, notifies the backend, and
        re-dispatches THIS SAME capability with the human's answer (or a
        timeout marker) merged into the payload once resolved. Reserved
        for gaps Supervisor's own higher-level goal analysis could not
        have caught — Supervisor is the first line of clarification-
        seeking; Planning is a second, narrower safety net during actual
        task breakdown. See _build_clarification_context and
        Planning/prompts.py's PLANNING_CLARIFICATION_*_NOTE_TEMPLATE.

Task-level output only — this engine does NOT decide which specific tool
or engine executes each task. Per the project's tool-selection design,
Planning offers only advisory, non-binding capability hints; the worker
that eventually executes a task decides the concrete tool/engine itself
from its own permitted tool list at execution time.

Reasoning is delegated to an ILLMClient (see
domain/interfaces/llm_client.py) built once at startup by the Model
engine (see infrastructure/engines/Model/model_engine.py) from a fixed
ModelConfiguration sourced from Settings.planning_model_configuration()
— Planning never receives model configuration from the backend/kernel;
that's reserved for Agent Runtime workers.
"""

import json
import re
from typing import Any

from ai_os.app.domain.interfaces.llm_client import ILLMClient
from ai_os.app.domain.models.engine import EngineManifest
from ai_os.app.domain.models.kernel_request import KernelRequest
from ai_os.app.domain.models.kernel_response import KernelResponse, NextStep
from ai_os.app.domain.models.llm_request import LLMRequest
from ai_os.app.domain.models.llm_response import LLMResponse
from ai_os.app.infrastructure.engines.base_engine import BaseEngine
from ai_os.app.infrastructure.engines.Planning.prompts import (
    CREATE_PLAN_SYSTEM_PROMPT,
    CREATE_PLAN_USER_PROMPT_TEMPLATE,
    PLANNING_CLARIFICATION_ANSWERED_NOTE_TEMPLATE,
    PLANNING_CLARIFICATION_TIMED_OUT_NOTE_TEMPLATE,
)
from ai_os.app.infrastructure.engines.Planning.schemas import PlanAnalysis, PlannedTask

_JSON_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)\s*```", re.DOTALL)


class PlanningError(ValueError):
    """Raised when the LLM's task breakdown can't be turned into a valid workflow."""


class PlanningEngine(BaseEngine):
    """Breaks queries into tasks, analyzes dependencies, and builds a workflow."""

    def __init__(self, llm_client: ILLMClient) -> None:
        """`llm_client` is required — built once by the composition root

        (main.py) via ModelEngine.create_client_from_config(), using
        Settings.planning_model_configuration(). Planning holds this
        client for its entire lifetime; it never asks the kernel for one.
        """
        super().__init__(
            EngineManifest(
                engineId="planning-engine",
                name="Planning Engine",
                version="1.0.0",
                description=(
                    "Breaks a query into meaningful tasks, analyzes task "
                    "dependencies, and converts them into an ordered "
                    "workflow with parallel phases where possible."
                ),
                capabilities=["planning.create_plan"],
                resources=[],
                priority=100,
            )
        )
        self._llm = llm_client

    async def execute(self, request: KernelRequest) -> KernelResponse:
        capability = request.capability
        try:
            if capability == "planning.create_plan":
                return await self._create_plan(request)

            return self._failure(
                request,
                code="UNSUPPORTED_CAPABILITY",
                message=f"Planning engine does not support capability '{capability}'",
            )
        except PlanningError as exc:
            return self._failure(
                request,
                code="INVALID_PLAN",
                message=f"Planning could not build a valid workflow: {exc}",
                retryable=False,
            )
        except Exception as exc:  # noqa: BLE001 — surface any stage failure as a KernelResponse
            return self._failure(
                request,
                code="PLANNING_STAGE_FAILED",
                message=f"Planning stage '{capability}' failed: {exc}",
                retryable=False,
            )

    # ─── planning.create_plan ─────────────────────────────────────────────

    async def _create_plan(self, request: KernelRequest) -> KernelResponse:
        payload = request.payload
        user_query = payload.get("userQuery", "")
        strategy = payload.get("strategy", {})
        execution_context = payload.get("executionContext", {}) or {}
        # Injected by the kernel before dispatch — see
        # AIKernel.MEMORY_REQUIRED_PREFIXES/_dispatch_step.
        memory_context = payload.get("memoryContext", [])
        # Present when this dispatch is a revision pass, triggered by
        # supervisor.validate_result's needs_more_planning outcome.
        revision_brief = payload.get("revisionBrief", "")
        previous_step_results = payload.get(
            "previousStepResults", execution_context.get("stepResults", [])
        )
        platform_capabilities = payload.get(
            "platformCapabilities", execution_context.get("platformCapabilities", [])
        )

        # This capability can be re-dispatched by the kernel as the resumed
        # half of a Planning-raised needsClarification human-in-the-loop
        # round-trip (see AIKernel._await_human_input) — the payload then
        # carries either humanInputAnswer or humanInputTimedOut, plus
        # humanInputQuestion echoing what was originally asked. Fold that
        # into the prompt so the LLM finishes the task breakdown instead of
        # asking the same clarifying question again. Mirrors
        # SupervisorEngine._build_clarification_context exactly.
        clarification_context = self._build_clarification_context(payload)

        user_prompt = CREATE_PLAN_USER_PROMPT_TEMPLATE.format(
            conversation_history=self._format_conversation_history(memory_context),
            user_query=user_query,
            strategy=json.dumps(strategy, default=str) if strategy else "none",
            platform_capabilities=json.dumps(platform_capabilities) if platform_capabilities else "none",
            revision_brief=revision_brief or "none",
            previous_step_results=json.dumps(previous_step_results, default=str)
            if previous_step_results
            else "none",
            clarification_context=clarification_context,
        )
        llm_response = await self._complete_json(CREATE_PLAN_SYSTEM_PROMPT, user_prompt)
        analysis = PlanAnalysis.model_validate(self._parse_json(llm_response.content))

        # A resumed call after a clarification round-trip is NOT a fresh
        # human utterance — the kernel is re-dispatching this capability
        # with an answer/timeout, and the user's own query was already
        # recorded as a "human"/"system" turn on the original dispatch (by
        # whichever capability sent it here). Recording it under "system"
        # here avoids double-logging.
        is_resumed_call = clarification_context != "none"
        system_input = (
            f"[System] Resuming Planning after clarification: {clarification_context}"
            if is_resumed_call
            else f"[System] Planning request. userQuery: {user_query}. "
            f"Supervisor strategy: {json.dumps(strategy, default=str)}"
        )

        response = self._success(
            request,
            {
                "modelUsage": self._model_usage_entry(llm_response),
                "conversationTurn": {
                    "system": system_input,
                    "ai": json.dumps(analysis.model_dump(by_alias=True), default=str),
                },
            },
        )

        if analysis.needs_clarification:
            # Raise the standard human-in-the-loop signal instead of a
            # next_step — AIKernel._execute_dynamic_loop checks for this on
            # every response and suspends the whole workflow, then
            # re-dispatches THIS SAME capability (planning.create_plan)
            # with the answer/timeout merged into the payload, landing back
            # here via clarification_context above. See module docstring
            # and SupervisorEngine's own needs_clarification handling for
            # the identical mechanism.
            response.result["humanInputRequired"] = {
                "question": analysis.clarification_question,
                "taskId": None,
            }
            return response

        workflow = self._build_workflow(analysis)
        # Full workflow, not just the analysis, belongs in the result the
        # rest of the system (ResponseCorrelator, validate_result) reads
        # from — kept as its own key alongside conversationTurn's "ai" side.
        response.result["workflow"] = workflow

        # No Agent Runtime engine exists yet to actually execute the
        # workflow — route straight to the mandatory validation gate so the
        # execution still completes cleanly end-to-end. Once Agent Runtime
        # is ready, this should hand the workflow off for execution instead
        # (e.g. next_step = "agent.spawn_workers" with the workflow attached).
        response.next_step = NextStep(
            capability="supervisor.validate_result",
            payload={
                "userQuery": user_query,
                "strategy": strategy,
                "mergedResult": (
                    f"Planning produced a {len(workflow['phases'])}-phase workflow "
                    f"covering {len(analysis.tasks)} tasks, but no execution engine "
                    f"(Agent Runtime) exists yet to carry it out."
                ),
            },
        )
        return response

    @staticmethod
    def _build_clarification_context(payload: dict) -> str:
        """Render the resumed-call note for a Planning-raised needsClarification round-trip.

        Returns "none" (matching the prompt template's expectation) when
        this is a normal, non-resumed call — i.e. neither humanInputAnswer
        nor humanInputTimedOut is present in the payload. Mirrors
        SupervisorEngine._build_clarification_context exactly.
        """
        question = payload.get("humanInputQuestion")
        if payload.get("humanInputTimedOut"):
            return PLANNING_CLARIFICATION_TIMED_OUT_NOTE_TEMPLATE.format(
                clarification_question=question or ""
            )
        answer = payload.get("humanInputAnswer")
        if answer is not None:
            return PLANNING_CLARIFICATION_ANSWERED_NOTE_TEMPLATE.format(
                clarification_question=question or "",
                clarification_answer=json.dumps(answer, default=str),
            )
        return "none"

    # ─── Deterministic workflow construction (topological sort) ──────────

    def _build_workflow(self, analysis: PlanAnalysis) -> dict[str, Any]:
        """Convert the LLM's task list + dependencies into an ordered workflow.

        This is computed deterministically, NOT by the LLM — the LLM only
        decides what the tasks are and how they depend on each other; the
        actual execution order (and which tasks can run in parallel) is
        derived here via a standard Kahn's-algorithm topological sort, so
        correctness of ordering doesn't depend on the LLM getting it right.

        Raises PlanningError if the task list references an unknown task ID
        in dependsOn, or if the dependency graph contains a cycle (neither
        of which can be turned into a valid execution order).
        """
        tasks_by_id = {t.task_id: t for t in analysis.tasks}

        # Validate all dependsOn references point to real tasks.
        for task in analysis.tasks:
            for dep in task.depends_on:
                if dep not in tasks_by_id:
                    raise PlanningError(
                        f"Task '{task.task_id}' depends on unknown task '{dep}'"
                    )

        # Kahn's algorithm: repeatedly peel off all tasks whose dependencies
        # have all already been placed into a prior phase. Tasks peeled off
        # in the same round have no dependency relationship to each other
        # (directly or transitively unresolved), so they can run in
        # parallel within that phase.
        remaining = dict(tasks_by_id)
        placed: set[str] = set()
        phases: list[dict[str, Any]] = []

        while remaining:
            ready_ids = [
                tid for tid, t in remaining.items() if all(dep in placed for dep in t.depends_on)
            ]
            if not ready_ids:
                # No task is ready but tasks remain -> a cycle exists among
                # the remaining tasks.
                raise PlanningError(
                    f"Circular dependency detected among tasks: {sorted(remaining.keys())}"
                )

            ready_ids.sort()  # deterministic ordering for reproducibility
            phase_tasks = [self._task_to_dict(remaining[tid]) for tid in ready_ids]

            if len(phase_tasks) == 1:
                phases.append(phase_tasks[0])
            else:
                phases.append({"parallel": phase_tasks})

            for tid in ready_ids:
                placed.add(tid)
                del remaining[tid]

        return {
            "name": "planning-generated-workflow",
            "taskCount": len(analysis.tasks),
            "phases": phases,
            "planningRationale": analysis.planning_rationale,
        }

    @staticmethod
    def _task_to_dict(task: PlannedTask) -> dict[str, Any]:
        return {
            "taskId": task.task_id,
            "description": task.description,
            "dependsOn": task.depends_on,
            "suggestedCapability": task.suggested_capability,
            # Execution contract — see PlannedTask for the full rationale.
            # Carried through unchanged; the topological sort above only
            # reorders/groups tasks, it never touches their contract.
            "inputContract": task.input_contract,
            "executionSteps": task.execution_steps,
            "outputContract": task.output_contract,
        }

    # ─── Helpers ──────────────────────────────────────────────────────────

    async def _complete_json(self, system: str, user: str) -> LLMResponse:
        """Call the ILLMClient for a system/user prompt pair, JSON mode.

        Returns the full LLMResponse (not just `.content`) so the caller
        can both parse the JSON text AND attach usage/latency/cost via
        `_model_usage_entry` — see request_correlator.py for how
        `modelUsage` becomes an ExecutionContext.model_logs entry.
        """
        return await self._llm.generate(
            LLMRequest.from_system_user(system, user).model_copy(update={"response_format": "json"})
        )

    def _model_usage_entry(self, llm_response: LLMResponse) -> dict[str, Any]:
        """Build the `modelUsage` block ResponseCorrelator turns into a ModelLog entry."""
        return {
            "provider": llm_response.metadata.get("provider", "unknown"),
            "modelName": llm_response.metadata.get("model", "unknown"),
            "promptTokens": llm_response.usage.prompt_tokens,
            "completionTokens": llm_response.usage.completion_tokens,
            "totalTokens": llm_response.usage.total_tokens,
            "latency": llm_response.latency_ms,
            "cost": llm_response.cost,
            "finishReason": llm_response.finish_reason,
        }

    @staticmethod
    def _format_conversation_history(memory_context: list[dict[str, str]]) -> str:
        """Render stored memory turns as plain text for inclusion in a prompt.

        Returns "none" if there's no history, matching the prompt template's
        expectation of a plain "none" string for a fresh conversation.
        """
        if not memory_context:
            return "none"
        lines = [f"{turn.get('role', 'unknown')}: {turn.get('content', '')}" for turn in memory_context]
        return "\n".join(lines)

    @staticmethod
    def _parse_json(raw: str) -> dict[str, Any]:
        """Parse an LLM's raw text output as JSON.

        Tolerates responses wrapped in markdown code fences (```json ... ```),
        which many LLMs produce even when asked for strict JSON.
        """
        text = raw.strip()
        fence_match = _JSON_FENCE_RE.search(text)
        if fence_match:
            text = fence_match.group(1).strip()
        try:
            return json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(f"LLM response was not valid JSON: {raw!r}") from exc
