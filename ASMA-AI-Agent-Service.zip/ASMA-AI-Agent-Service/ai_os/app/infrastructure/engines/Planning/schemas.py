"""Internal data shapes used by the Planning engine.

These are Planning-local structures (not part of the shared kernel domain
models) used to validate/normalize the LLM's structured output for the
planning.create_plan capability.
"""

from pydantic import BaseModel, Field, field_validator, model_validator


class PlannedTask(BaseModel):
    """A single task the LLM decomposed the query into.

    Task-level, not tool-level: describes WHAT needs to happen, not which
    specific tool/engine will do it. Per the project's tool-selection
    design, exact tool choice is deferred to the worker at execution time
    (see AgentDefinition.allowed_tools) — Planning only offers an advisory
    capability hint, matching the same non-binding pattern Supervisor uses
    for suggestedCapabilities.
    """

    task_id: str = Field(alias="taskId")
    description: str
    # IDs of other tasks in this plan that must complete before this one
    # can start. Empty list if this task has no dependencies.
    depends_on: list[str] = Field(default_factory=list, alias="dependsOn")
    # Advisory, non-binding hint at the capability category this task will
    # likely use (e.g. "knowledge.retrieve", "tool.email"). Not a binding
    # instruction — the worker/Agent Runtime decides the actual tool/engine
    # at execution time from its own permitted tool list.
    suggested_capability: str = Field(default="", alias="suggestedCapability")

    # ─── Execution contract (what a worker needs to carry out this task) ──
    # These three fields together form the data-flow contract between a
    # task and its dependents. They describe WHAT the worker should do and
    # WHERE its input/output come from/go — never WHICH tool to call. Tool
    # selection stays the worker's own decision at execution time, from its
    # permitted tool list, matching suggestedCapability's non-binding rule.

    # Plain-language description of what this task needs as input and
    # where that input comes from — either "the user's query/attachments"
    # for a task with no dependencies, or "the output of task-X" for a
    # dependent task. Lets a worker know what to expect without the kernel
    # needing to infer it from the dependency graph alone.
    input_contract: str = Field(default="", alias="inputContract")

    # Ordered, ABSTRACT steps a worker should follow to carry out this
    # task — e.g. "receive the input", "call a tool to extract/transform
    # it", "produce the output". Steps must describe the pattern of action
    # (what kind of operation), never name a specific tool, engine, or
    # literal parameters — those are the worker's own decision at runtime.
    execution_steps: list[str] = Field(default_factory=list, alias="executionSteps")

    # Plain-language description of what this task must produce, in a form
    # its dependent tasks (or the kernel, if this task is terminal) can
    # consume. Mirrors input_contract's granularity so the two form a
    # matching producer/consumer contract across dependent tasks.
    output_contract: str = Field(default="", alias="outputContract")

    model_config = {"populate_by_name": True}

    @field_validator("task_id")
    @classmethod
    def _non_empty_task_id(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("taskId must be a non-empty string")
        return v


class PlanAnalysis(BaseModel):
    """Full output of the planning.create_plan LLM call.

    Task breakdown + dependency analysis only — converting this into an
    ordered/parallelized workflow is done deterministically afterward by
    PlanningEngine (topological sort), not left to the LLM, so the actual
    execution order is guaranteed correct rather than merely LLM-asserted.

    Normally the LLM always produces a task list. The one exception is
    needsClarification=true: something essential is missing/ambiguous
    enough that a valid task breakdown can't be produced yet (e.g. Planning
    discovers a genuine gap Supervisor's own understand_goal stage didn't
    catch — a missing recipient, an unresolvable reference, conflicting
    constraints). In that case `tasks` is legitimately empty and
    `clarificationQuestion` carries the exact question to ask the user —
    see PlanningEngine._create_plan's human-in-the-loop handling.
    """

    tasks: list[PlannedTask] = Field(default_factory=list)
    # Brief explanation of the overall approach, surfaced in the workflow
    # for traceability (e.g. shown in activity logs / step results).
    planning_rationale: str = Field(default="", alias="planningRationale")
    # Human-in-the-loop escape hatch — see class docstring. False in the
    # overwhelming majority of calls; Supervisor's own understand_goal
    # stage is the FIRST line of clarification-seeking (see
    # Supervisor/prompts.py's needs_clarification path) — Planning only
    # asks when it discovers something Supervisor's higher-level analysis
    # couldn't have caught (e.g. a genuine gap surfaced only once tasks are
    # actually being broken down).
    needs_clarification: bool = Field(default=False, alias="needsClarification")
    clarification_question: str = Field(default="", alias="clarificationQuestion")

    model_config = {"populate_by_name": True}

    @model_validator(mode="after")
    def _tasks_required_unless_clarifying(self) -> "PlanAnalysis":
        if self.needs_clarification:
            if not self.clarification_question.strip():
                raise ValueError("needsClarification=true requires a non-empty clarificationQuestion")
            return self
        if not self.tasks:
            raise ValueError("plan must contain at least one task unless needsClarification is true")
        return self
