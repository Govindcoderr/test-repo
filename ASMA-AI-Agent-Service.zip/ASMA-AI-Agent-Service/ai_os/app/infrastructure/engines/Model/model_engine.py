"""Model engine.

Owns exactly one responsibility: turning a ModelConfiguration into a
validated, ready-to-use ILLMClient. It does NOT perform inference itself
— there is no "model.generate" or "model.reason" capability here, and it
never calls `.generate()`/`.chat()` on anything. Whoever receives the
ILLMClient calls those methods themselves, exactly like checking out a
database connection.

    ModelConfiguration
        |
        v
    validate_configuration()
        |
        v
    resolve provider (ProviderRegistry)
        |
        v
    create SDK-backed client, wrapped as ILLMClient
        |
        v
    return ILLMClient

Fixed input/output contract:
    input  -> ModelConfiguration (domain/models/model_configuration.py)
    output -> ILLMClient (domain/interfaces/llm_client.py), whose own
              generate()/stream()/structured_output() always return
              LLMResponse (domain/models/llm_response.py)

Two call paths exist for this contract, matching the two ways a client is
needed in this codebase today:

1. Direct, in-process call — `create_client_from_config()`. Used by the
   composition root (main.py) at startup to build the clients Supervisor
   and Planning hold for their entire lifetime. Their ModelConfiguration
   comes from Settings (SUPERVISOR_MODEL_*/PLANNING_MODEL_* env vars) —
   see settings.py. This is a plain method call, not a kernel dispatch,
   because Supervisor/Planning need their client at construction time,
   before any KernelRequest exists yet.

2. Kernel-dispatched capability — `model.create_client`, handled by
   execute() below. This is the path Agent Runtime workers will use once
   that engine exists: the kernel dispatches this capability with a
   ModelConfiguration payload sourced from the backend's agentDefinition/
   subAgent definitions (per the project's decision that only workers use
   backend-supplied model configuration, not Supervisor/Planning). NOT
   YET WIRED into AIKernel's dynamic loop — Agent Runtime doesn't exist
   yet — but the capability is implemented and ready, same as
   AIKernel._resolve_task_dependencies is prepared-but-unwired for the
   same reason. When wiring it, note that KernelResponse.result flows
   into ExecutionContext.step_results, which is serialized back to the
   caller as part of ExecutionResponse — the kernel must pull the client
   out of the response and hold it on the context/NextStep payload
   itself, not leave it in the JSON-serialized step_results.

── Adding a new provider ──────────────────────────────────────────────
Only these files change:
1. infrastructure/engines/Model/providers/<name>_provider.py — new file,
   implements IProviderFactory + an ILLMClient wrapper for that SDK.
2. infrastructure/engines/Model/provider_registry.py — one new entry in
   PROVIDER_FACTORIES.
3. requirements.txt — pinned SDK dependency, if the provider needs one.
Nothing else — not this file, not client_factory.py, not any caller —
needs to change.
"""

from ai_os.app.domain.interfaces.llm_client import ILLMClient
from ai_os.app.domain.models.engine import EngineManifest
from ai_os.app.domain.models.kernel_request import KernelRequest
from ai_os.app.domain.models.kernel_response import KernelResponse
from ai_os.app.domain.models.model_configuration import ModelConfiguration
from ai_os.app.infrastructure.engines.base_engine import BaseEngine
from ai_os.app.infrastructure.engines.Model.client_factory import ClientFactory
from ai_os.app.infrastructure.engines.Model.exceptions import ModelEngineError
from ai_os.app.infrastructure.engines.Model.provider_registry import ProviderRegistry
from ai_os.app.infrastructure.engines.Model.validators import validate_configuration


class ModelEngine(BaseEngine):
    """Creates, validates, and manages LLM clients. Never performs inference."""

    def __init__(self, client_factory: ClientFactory | None = None) -> None:
        super().__init__(
            EngineManifest(
                engineId="model-engine",
                name="Model Engine",
                version="1.0.0",
                description=(
                    "Validates model configuration and creates standardized "
                    "ILLMClient instances for callers. Does not perform "
                    "inference itself."
                ),
                capabilities=["model.create_client", "model.validate_configuration"],
                resources=[],
                priority=100,
            )
        )
        self._client_factory = client_factory or ClientFactory()

    @property
    def provider_registry(self) -> ProviderRegistry:
        return self._client_factory._registry  # noqa: SLF001 — same-module trusted access

    # ─── Direct, in-process call path (see module docstring, path 1) ─────

    def create_client_from_config(self, config: ModelConfiguration) -> ILLMClient:
        """Build an ILLMClient directly, without going through kernel dispatch.

        Used by the composition root to build Supervisor's and Planning's
        clients at startup. Raises ModelEngineError (or a subclass) if
        `config` is invalid or the provider isn't supported.
        """
        return self._client_factory.create_client(config)

    # ─── Kernel-dispatched capability path (see module docstring, path 2) ─

    async def execute(self, request: KernelRequest) -> KernelResponse:
        capability = request.capability
        try:
            if capability == "model.create_client":
                return self._create_client(request)
            if capability == "model.validate_configuration":
                return self._validate_configuration(request)

            return self._failure(
                request,
                code="UNSUPPORTED_CAPABILITY",
                message=f"Model engine does not support capability '{capability}'",
            )
        except ModelEngineError as exc:
            return self._failure(
                request,
                code="INVALID_MODEL_CONFIGURATION",
                message=str(exc),
                retryable=False,
            )
        except Exception as exc:  # noqa: BLE001 — surface any stage failure as a KernelResponse
            return self._failure(
                request,
                code="MODEL_ENGINE_STAGE_FAILED",
                message=f"Model engine stage '{capability}' failed: {exc}",
                retryable=False,
            )

    def _parse_config(self, request: KernelRequest) -> ModelConfiguration:
        raw_config = request.payload.get("modelConfiguration")
        if not raw_config:
            raise ModelEngineError("payload.modelConfiguration is required")
        return (
            ModelConfiguration.model_validate(raw_config)
            if isinstance(raw_config, dict)
            else raw_config
        )

    def _create_client(self, request: KernelRequest) -> KernelResponse:
        config = self._parse_config(request)
        client = self._client_factory.create_client(config)
        # NOTE: `client` is a live Python object, not JSON-serializable —
        # see the "NOT YET WIRED" note in the module docstring. Safe today
        # only because nothing dispatches this capability yet.
        return self._success(
            request,
            {
                "client": client,
                "provider": config.provider,
                "modelName": config.model_name,
            },
        )

    def _validate_configuration(self, request: KernelRequest) -> KernelResponse:
        config = self._parse_config(request)
        validate_configuration(config, self.provider_registry)
        return self._success(
            request,
            {"valid": True, "provider": config.provider, "modelName": config.model_name},
        )
