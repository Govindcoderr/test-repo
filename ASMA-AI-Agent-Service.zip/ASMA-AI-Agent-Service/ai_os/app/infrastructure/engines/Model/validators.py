"""Configuration validation shared across all providers.

Provider-specific validation (e.g. "OpenAI requires apiKey") lives in each
provider's own factory.validate(). This module only checks what's true
for every provider regardless of which one is selected.
"""

from ai_os.app.domain.models.model_configuration import ModelConfiguration
from ai_os.app.infrastructure.engines.Model.exceptions import InvalidConfigurationError
from ai_os.app.infrastructure.engines.Model.provider_registry import ProviderRegistry


def validate_configuration(config: ModelConfiguration, registry: ProviderRegistry) -> None:
    """Raise InvalidConfigurationError / UnsupportedProviderError if `config` is unusable.

    Checks generic shape first, then delegates to the RESOLVED factory's
    own validate() — resolution honors isInternal (see
    ProviderRegistry.resolve()), so `config.provider` is only required to
    be non-empty when isInternal is false (an internal config's `provider`
    field is otherwise unused/informational).
    """
    if not config.is_internal and not config.provider:
        raise InvalidConfigurationError("ModelConfiguration requires a non-empty 'provider'")
    if config.temperature < 0 or config.temperature > 2:
        raise InvalidConfigurationError(
            f"ModelConfiguration.temperature must be between 0 and 2, got {config.temperature}"
        )
    if config.max_tokens <= 0:
        raise InvalidConfigurationError(
            f"ModelConfiguration.maxTokens must be positive, got {config.max_tokens}"
        )

    factory = registry.resolve(config)  # honors isInternal; raises UnsupportedProviderError if unknown
    factory.validate(config)
