"""ClientFactory — the single orchestration path from ModelConfiguration to ILLMClient.

    ModelConfiguration
        |
        v
    validate_configuration()   (validators.py — generic + provider-specific)
        |
        v
    ProviderRegistry.resolve(config)   (provider_registry.py — isInternal=true
        |                                always wins over `provider`, see resolve())
        v
    factory.create_client(config)   (providers/<provider>_provider.py) -> raw ILLMClient
        |
        v
    ResilientLLMClient(raw, config, fallback_factory)   (resilient_client.py)
        |
        v
    ILLMClient  (timeout + retry + single-hop fallback applied)

This is the only code path that turns a ModelConfiguration into a live
client, for any caller (ModelEngine.execute() included) — nothing else
constructs a provider SDK client directly, and every client handed out is
already wrapped with the standard resilience policy.
"""

from ai_os.app.domain.interfaces.llm_client import ILLMClient
from ai_os.app.domain.models.model_configuration import ModelConfiguration
from ai_os.app.infrastructure.engines.Model.provider_registry import ProviderRegistry
from ai_os.app.infrastructure.engines.Model.resilient_client import ResilientLLMClient
from ai_os.app.infrastructure.engines.Model.validators import validate_configuration


class ClientFactory:
    def __init__(self, registry: ProviderRegistry | None = None) -> None:
        self._registry = registry or ProviderRegistry()

    def create_client(self, config: ModelConfiguration) -> ILLMClient:
        """Validate `config` and return a ready-to-use, resilience-wrapped ILLMClient.

        Raises InvalidConfigurationError, UnsupportedProviderError, or
        ClientCreationError (see exceptions.py) — callers should expect
        ModelEngineError as the common base if they want a single except
        clause.
        """
        raw_client = self._create_raw_client(config)
        return ResilientLLMClient(
            primary=raw_client,
            config=config,
            fallback_factory=self._create_fallback_client if config.fallback else None,
        )

    def _create_raw_client(self, config: ModelConfiguration) -> ILLMClient:
        """Build the unwrapped, provider-native ILLMClient (no resilience layer).

        Resolution honors isInternal=true (see ProviderRegistry.resolve())
        — an internal ModelConfiguration always gets InternalClient
        regardless of its `provider` field.
        """
        validate_configuration(config, self._registry)
        factory = self._registry.resolve(config)
        return factory.create_client(config)

    def _create_fallback_client(self, fallback_config: ModelConfiguration) -> ILLMClient:
        """Build the fallback client, itself resilience-wrapped (with its own retry policy).

        `fallback_config.fallback` is ignored even if set — only one
        fallback hop is ever attempted, per ModelConfiguration.fallback's
        docstring, so this deliberately strips it before wrapping to avoid
        an accidental multi-hop chain.
        """
        single_hop_config = fallback_config.model_copy(update={"fallback": None})
        raw_client = self._create_raw_client(single_hop_config)
        return ResilientLLMClient(primary=raw_client, config=single_hop_config, fallback_factory=None)
