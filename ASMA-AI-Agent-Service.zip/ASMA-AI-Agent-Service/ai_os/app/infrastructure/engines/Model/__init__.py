"""Model engine — creates, validates, and manages LLM clients.

The Model engine's ONLY responsibility is producing an ILLMClient for a
caller (Supervisor, Planning, or — once it exists — Agent Runtime workers)
to call generate()/stream()/structured_output() on directly. It does NOT
perform inference itself; there is no "model.generate" or "model.reason"
capability here on purpose. See model_engine.py for the full contract.
"""
