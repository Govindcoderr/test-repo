"""Exceptions raised while validating configuration or building a client.

Caught by ModelEngine.execute() and turned into a KernelResponse FAILURE
(see base_engine.py::BaseEngine._failure), the same pattern
PlanningEngine uses for PlanningError.
"""


class ModelEngineError(ValueError):
    """Base class for all Model engine errors."""


class UnsupportedProviderError(ModelEngineError):
    """Raised when a ModelConfiguration names a provider with no registered factory."""


class InvalidConfigurationError(ModelEngineError):
    """Raised when a ModelConfiguration fails validation (missing key, etc.)."""


class ClientCreationError(ModelEngineError):
    """Raised when a provider factory fails to construct its SDK client."""
