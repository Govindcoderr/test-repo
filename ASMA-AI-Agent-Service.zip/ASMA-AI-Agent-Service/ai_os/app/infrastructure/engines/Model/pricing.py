"""Per-model pricing table used to compute LLMResponse.cost.

This is a plain data lookup, not logic. Rates are USD per 1,000,000
tokens ("per million" / "per MTok" — the convention every provider's own
pricing page uses), split prompt/completion since providers price them
differently.

Deliberately conservative: an unknown (provider, model) pair returns
`None`, never `0.0` — a missing price must never be silently reported as
"free". Callers (provider adapters, via `estimate_cost`) should leave
LLMResponse.cost unset (None) rather than guess.

── Why this isn't fetched "live" from the provider ────────────────────
None of OpenAI, Anthropic, or Google publish a pricing API — their rates
only exist on human-facing marketing pages (openai.com/api/pricing,
anthropic's pricing page, ai.google.dev pricing), not a queryable
endpoint. Scraping those pages is fragile (HTML changes silently break
it) and not something any of these vendors support or guarantee. So
"dynamic" here means "editable without a code change," not "fetched from
the provider at request time" — see the override file below.

── Two ways to update prices ───────────────────────────────────────────
1. Edit DEFAULT_PRICING_TABLE below and redeploy — fine for occasional
   updates when you're already shipping code changes.
2. Point MODEL_PRICING_OVERRIDES_PATH (see settings.py) at a JSON file on
   disk shaped like DEFAULT_PRICING_TABLE (see pricing_overrides.example.json
   for the exact shape). Entries in that file are merged OVER the
   defaults below (same provider+model wins from the override; anything
   not in the override falls back to DEFAULT_PRICING_TABLE) and are
   re-read from disk on every call — no server restart needed to pick up
   an updated price. This is the practical middle ground between fully
   hardcoded and a nonexistent live pricing API: ops can update rates by
   editing a file, without touching this module.
"""

import json
from pathlib import Path

from ai_os.app.domain.models.llm_response import TokenUsage

# {provider: {model_name: (prompt_per_million_usd, completion_per_million_usd)}}
DEFAULT_PRICING_TABLE: dict[str, dict[str, tuple[float, float]]] = {
    "openai": {
        "gpt-4.1": (2.00, 8.00),
        "gpt-4.1-mini": (0.40, 1.60),
        "gpt-5": (5.00, 15.00),
        "gpt-4o": (2.50, 10.00),
        "gpt-4o-mini": (0.15, 0.60),
        "gpt-5.6-luna": (0.20, 1.20),
    },
    "anthropic": {
        "claude-opus-4-1-20250805": (15.00, 75.00),
        "claude-sonnet-4-5-20250929": (3.00, 15.00),
        "claude-3-5-sonnet-20241022": (3.00, 15.00),
        "claude-3-5-haiku-20241022": (0.80, 4.00),
    },
    "gemini": {
        "gemini-2.5-pro": (1.25, 10.00),
        "gemini-2.5-flash": (0.30, 2.50),
        "gemini-2.0-flash": (0.10, 0.40),
        "gemini-1.5-pro": (1.25, 5.00),
        "gemini-1.5-flash": (0.075, 0.30),
    },
}

_TOKENS_PER_MILLION = 1_000_000.0


def _load_override_table() -> dict[str, dict[str, tuple[float, float]]]:
    """Read the override file configured via Settings.model_pricing_overrides_path.

    Returns an empty dict if no path is configured, the file doesn't
    exist, or it fails to parse — a bad/missing override file should
    never crash cost estimation, it should just fall back to defaults.
    Deliberately NOT cached across calls (unlike the merge below) so an
    ops team editing the file on disk is picked up on the next call
    without a restart.
    """
    from ai_os.app.config.settings import get_settings

    path_str = get_settings().model_pricing_overrides_path
    if not path_str:
        return {}
    path = Path(path_str)
    if not path.is_file():
        return {}
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    # Skip non-dict entries (e.g. a "_comment" string key) and any
    # malformed rate pair rather than raising — a typo in the override
    # file should degrade to "ignore that one entry," not crash cost
    # estimation for every model.
    result: dict[str, dict[str, tuple[float, float]]] = {}
    for provider, models in raw.items():
        if not isinstance(models, dict):
            continue
        parsed_models: dict[str, tuple[float, float]] = {}
        for model, rates in models.items():
            if isinstance(rates, (list, tuple)) and len(rates) == 2:
                parsed_models[model] = (float(rates[0]), float(rates[1]))
        if parsed_models:
            result[provider] = parsed_models
    return result


def _resolve_rates(provider: str, model_name: str) -> tuple[float, float] | None:
    """Look up rates, preferring the override file over DEFAULT_PRICING_TABLE."""
    override = _load_override_table()
    if provider in override and model_name in override[provider]:
        return override[provider][model_name]
    return DEFAULT_PRICING_TABLE.get(provider, {}).get(model_name)


def estimate_cost(provider: str, model_name: str, usage: TokenUsage) -> float | None:
    """Return the USD cost for `usage`, or None if `(provider, model_name)` has no known price."""
    rates = _resolve_rates(provider, model_name)
    if rates is None:
        return None
    prompt_rate, completion_rate = rates
    return (
        (usage.prompt_tokens / _TOKENS_PER_MILLION) * prompt_rate
        + (usage.completion_tokens / _TOKENS_PER_MILLION) * completion_rate
    )
