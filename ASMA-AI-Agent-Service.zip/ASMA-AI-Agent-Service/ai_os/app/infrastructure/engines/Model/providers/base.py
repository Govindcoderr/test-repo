"""Provider factory contract.

Each provider module (openai_provider.py, and future
anthropic_provider.py, gemini_provider.py, ollama_provider.py,
openai_compatible_provider.py, ...) implements exactly one
IProviderFactory. The Model engine's ClientFactory looks these up via
provider_registry.py and never branches on provider name itself.
"""

from abc import ABC, abstractmethod

from ai_os.app.domain.interfaces.llm_client import ILLMClient
from ai_os.app.domain.models.model_configuration import ModelConfiguration


class IProviderFactory(ABC):
    """Builds a validated ILLMClient for one provider from a ModelConfiguration."""

    @abstractmethod
    def validate(self, config: ModelConfiguration) -> None:
        """Raise InvalidConfigurationError if `config` is unusable for this provider.

        Should NOT attempt a network call — this is local, synchronous
        validation only (required fields present, sane values).
        """
        raise NotImplementedError

    @abstractmethod
    def create_client(self, config: ModelConfiguration) -> ILLMClient:
        """Construct and return this provider's ILLMClient implementation.

        Raises ClientCreationError if the underlying SDK client can't be
        constructed (e.g. malformed base_url).
        """
        raise NotImplementedError
