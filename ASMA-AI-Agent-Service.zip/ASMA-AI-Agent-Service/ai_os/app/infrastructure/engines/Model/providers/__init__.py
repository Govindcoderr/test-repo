"""Provider adapters — one module per LLM provider.

To add a new provider:
1. Create `providers/<provider>_provider.py` implementing IProviderFactory
   (see providers/base.py) and an ILLMClient wrapper for that provider's
   SDK (see providers/openai_provider.py for the reference shape).
2. Register it in provider_registry.py's PROVIDER_FACTORIES mapping.
3. If the provider needs its own SDK, add the pinned dependency to
   requirements.txt.

Nothing outside this package (provider_registry.py aside) ever needs to
change — see infrastructure/engines/Model/README in model_engine.py's
module docstring for the full checklist.
"""
