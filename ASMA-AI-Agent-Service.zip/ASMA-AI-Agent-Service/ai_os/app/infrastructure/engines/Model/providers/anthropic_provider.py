"""Anthropic (Claude) provider adapter.

Owns the only place in the codebase that constructs an `anthropic` SDK
client. `AnthropicClient` wraps `AsyncAnthropic` and implements
`ILLMClient`, converting every response into the fixed `LLMResponse`
shape (content, usage, latency, cost) so callers never touch
`response.content[0].text` — or any other Anthropic-specific shape —
themselves.

Every SDK exception is mapped, at this boundary, into the provider-
agnostic taxonomy in domain/interfaces/llm_errors.py
(LLMTransientError / LLMPermanentError) — see openai_provider.py's
module docstring for why this boundary matters.

Anthropic's Messages API takes `system` as a separate top-level
parameter rather than a message with role="system" — that translation
happens once, here, in `_split_system_message`.
"""

import time
from collections.abc import AsyncIterator

from anthropic import (
    APIConnectionError,
    APIStatusError,
    APITimeoutError,
    AsyncAnthropic,
    AnthropicError,
    AuthenticationError,
    BadRequestError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    UnprocessableEntityError,
)

from ai_os.app.domain.interfaces.llm_client import ILLMClient
from ai_os.app.domain.interfaces.llm_errors import LLMPermanentError, LLMTransientError
from ai_os.app.domain.models.llm_request import LLMMessage, LLMRequest
from ai_os.app.domain.models.llm_response import LLMResponse, TokenUsage
from ai_os.app.domain.models.model_configuration import ModelConfiguration
from ai_os.app.infrastructure.engines.Model.exceptions import (
    ClientCreationError,
    InvalidConfigurationError,
)
from ai_os.app.infrastructure.engines.Model.pricing import estimate_cost
from ai_os.app.infrastructure.engines.Model.providers.base import IProviderFactory

_PERMANENT_ERROR_TYPES = (
    AuthenticationError,
    PermissionDeniedError,
    BadRequestError,
    NotFoundError,
    UnprocessableEntityError,
)
_TRANSIENT_ERROR_TYPES = (
    RateLimitError,
    APITimeoutError,
    APIConnectionError,
    InternalServerError,
)

_JSON_INSTRUCTION_SUFFIX = (
    "\n\nRespond with ONLY a single valid JSON object matching the requested "
    "schema. Do not include any explanation or markdown code fences."
)


class AnthropicClient(ILLMClient):
    """ILLMClient implementation backed by AsyncAnthropic."""

    def __init__(
        self,
        api_key: str,
        model: str,
        base_url: str | None = None,
        temperature: float = 0.2,
        max_tokens: int = 4096,
        timeout: float = 30.0,
        provider_name: str = "anthropic",
    ) -> None:
        self._model = model
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._provider_name = provider_name
        self._sdk_client = AsyncAnthropic(
            api_key=api_key,
            base_url=base_url or None,
            timeout=timeout,
        )

    async def generate(self, request: LLMRequest) -> LLMResponse:
        system, messages = self._split_system_message(request)
        started = time.perf_counter()
        try:
            response = await self._sdk_client.messages.create(
                model=self._model,
                system=system,
                messages=messages,
                temperature=request.temperature if request.temperature is not None else self._temperature,
                max_tokens=request.max_tokens or self._max_tokens,
            )
        except AnthropicError as exc:
            raise self._map_error(exc) from exc

        latency_ms = (time.perf_counter() - started) * 1000
        return self._to_llm_response(response, latency_ms)

    async def stream(self, request: LLMRequest) -> AsyncIterator[LLMResponse]:
        """Yield incremental LLMResponse chunks as text deltas arrive.

        Each yielded chunk carries only the incremental `content` delta,
        matching OpenAIClient.stream()'s contract. The final chunk (after
        the stream completes) carries the accumulated usage/latency/cost,
        pulled from `AsyncMessageStream.get_final_message()`.
        """
        system, messages = self._split_system_message(request)
        started = time.perf_counter()
        try:
            async with self._sdk_client.messages.stream(
                model=self._model,
                system=system,
                messages=messages,
                temperature=request.temperature if request.temperature is not None else self._temperature,
                max_tokens=request.max_tokens or self._max_tokens,
            ) as stream:
                async for event in stream:
                    if event.type == "content_block_delta" and event.delta.type == "text_delta":
                        yield LLMResponse(
                            content=event.delta.text,
                            metadata={"model": self._model, "provider": self._provider_name, "final": False},
                        )

                final_message = await stream.get_final_message()
                latency_ms = (time.perf_counter() - started) * 1000
                token_usage = TokenUsage(
                    promptTokens=final_message.usage.input_tokens,
                    completionTokens=final_message.usage.output_tokens,
                    totalTokens=final_message.usage.input_tokens + final_message.usage.output_tokens,
                )
                yield LLMResponse(
                    content="",
                    finishReason=final_message.stop_reason,
                    usage=token_usage,
                    latencyMs=latency_ms,
                    cost=estimate_cost(self._provider_name, self._model, token_usage),
                    metadata={"model": self._model, "provider": self._provider_name, "final": True},
                    rawResponse=final_message,
                )
        except AnthropicError as exc:
            raise self._map_error(exc) from exc

    async def structured_output(self, request: LLMRequest, schema: dict) -> LLMResponse:
        # Claude has no dedicated JSON-mode flag on the Messages API (as
        # OpenAI's response_format is) — the reliable approach is a strong
        # prompt instruction, same as any other provider without native
        # structured output. Callers already validate the returned text
        # against their own schema (see SupervisorEngine._parse_json), so
        # this only needs to bias the model toward raw JSON.
        if request.messages and request.messages[-1].role == "user":
            messages = list(request.messages)
            messages[-1] = LLMMessage(
                role="user", content=messages[-1].content + _JSON_INSTRUCTION_SUFFIX
            )
            request = request.model_copy(update={"messages": messages})
        return await self.generate(request)

    async def health(self) -> bool:
        try:
            await self._sdk_client.models.list(limit=1)
            return True
        except AnthropicError:
            return False

    def _map_error(self, exc: AnthropicError) -> LLMTransientError | LLMPermanentError:
        """Translate an anthropic.* exception into the provider-agnostic taxonomy.

        This is the ONLY place an anthropic.* exception type is inspected.
        """
        message = f"Anthropic API request failed: {exc}"
        if isinstance(exc, APIStatusError):
            message = f"Anthropic API returned {exc.status_code}: {exc.response.text}"
        if isinstance(exc, _PERMANENT_ERROR_TYPES):
            return LLMPermanentError(message)
        if isinstance(exc, _TRANSIENT_ERROR_TYPES):
            return LLMTransientError(message)
        # Unclassified AnthropicError subclass — default to transient, same
        # rationale as OpenAIClient._map_error.
        return LLMTransientError(message)

    @staticmethod
    def _split_system_message(request: LLMRequest) -> tuple[str, list[dict]]:
        """Anthropic's Messages API takes `system` separately from `messages`.

        LLMRequest.from_system_user() (and any other caller) puts the
        system prompt as a message with role="system" — this pulls that
        out and returns Anthropic's expected (system_str, messages_list)
        shape. If multiple system messages are present, they're joined;
        if none are present, system is an empty string (Anthropic accepts
        that as "no system prompt").
        """
        system_parts = [m.content for m in request.messages if m.role == "system"]
        other_messages = [
            {"role": m.role, "content": m.content} for m in request.messages if m.role != "system"
        ]
        return "\n\n".join(system_parts), other_messages

    def _to_llm_response(self, response, latency_ms: float) -> LLMResponse:
        try:
            text_blocks = [block.text for block in response.content if block.type == "text"]
            content = "".join(text_blocks)
        except AttributeError as exc:
            raise LLMPermanentError(f"Unexpected Anthropic API response shape: {response!r}") from exc

        usage = response.usage
        token_usage = TokenUsage(
            promptTokens=usage.input_tokens,
            completionTokens=usage.output_tokens,
            totalTokens=usage.input_tokens + usage.output_tokens,
        )
        return LLMResponse(
            content=content,
            finishReason=response.stop_reason,
            usage=token_usage,
            latencyMs=latency_ms,
            cost=estimate_cost(self._provider_name, self._model, token_usage),
            metadata={"model": response.model, "provider": self._provider_name},
            rawResponse=response,
        )


class AnthropicProviderFactory(IProviderFactory):
    """Validates ModelConfiguration and builds AnthropicClient instances.

    Only ever reached for configs with isInternal=false — see
    OpenAIProviderFactory's docstring for why "unless isInternal" no
    longer applies on this path.
    """

    def validate(self, config: ModelConfiguration) -> None:
        if not config.api_key and not config.secret_reference:
            raise InvalidConfigurationError("Anthropic provider requires 'apiKey' or 'secretReference'")
        if not config.model_name:
            raise InvalidConfigurationError("Anthropic provider requires 'modelName'")

    def create_client(self, config: ModelConfiguration) -> ILLMClient:
        if not config.api_key:
            raise ClientCreationError(
                "Anthropic provider has no resolved apiKey — secretReference resolution "
                "is not implemented yet"
            )
        try:
            return AnthropicClient(
                api_key=config.api_key,
                model=config.model_name,
                base_url=config.base_url,
                temperature=config.temperature,
                max_tokens=config.max_tokens,
                timeout=float(config.timeout) if config.timeout else 30.0,
            )
        except Exception as exc:  # noqa: BLE001 — wrap any SDK construction failure
            raise ClientCreationError(f"Failed to construct Anthropic client: {exc}") from exc
