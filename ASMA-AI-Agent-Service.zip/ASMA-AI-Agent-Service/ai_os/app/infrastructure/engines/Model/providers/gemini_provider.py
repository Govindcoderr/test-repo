"""Google Gemini provider adapter.

Owns the only place in the codebase that constructs a `google-genai` SDK
client. `GeminiClient` wraps `google.genai.Client` and implements
`ILLMClient`, converting every response into the fixed `LLMResponse`
shape (content, usage, latency, cost) so callers never touch
`response.candidates[0].content.parts[0].text` — or any other
Gemini-specific shape — themselves.

Every SDK exception is mapped, at this boundary, into the provider-
agnostic taxonomy in domain/interfaces/llm_errors.py
(LLMTransientError / LLMPermanentError) — see openai_provider.py's
module docstring for why this boundary matters.

Gemini's API also takes `system_instruction` as a separate config field
rather than a message with role="system", same shape difference as
Anthropic — handled here via `_split_system_message`.
"""

import time
from collections.abc import AsyncIterator

from google import genai
from google.genai import errors as genai_errors
from google.genai import types as genai_types

from ai_os.app.domain.interfaces.llm_client import ILLMClient
from ai_os.app.domain.interfaces.llm_errors import LLMPermanentError, LLMTransientError
from ai_os.app.domain.models.llm_request import LLMRequest
from ai_os.app.domain.models.llm_response import LLMResponse, TokenUsage
from ai_os.app.domain.models.model_configuration import ModelConfiguration
from ai_os.app.infrastructure.engines.Model.exceptions import (
    ClientCreationError,
    InvalidConfigurationError,
)
from ai_os.app.infrastructure.engines.Model.pricing import estimate_cost
from ai_os.app.infrastructure.engines.Model.providers.base import IProviderFactory

# Gemini's REST errors surface as ClientError (4xx) / ServerError (5xx),
# but a 4xx rate-limit (429) is still transient despite being a "client"
# error by HTTP convention — checked by status code, not exception type,
# below. Anything else 4xx (401/403/404/400/422) is treated as permanent.
_TRANSIENT_STATUS_CODES = {429, 500, 502, 503, 504}


class GeminiClient(ILLMClient):
    """ILLMClient implementation backed by google.genai.Client."""

    def __init__(
        self,
        api_key: str,
        model: str,
        base_url: str | None = None,
        temperature: float = 0.2,
        max_tokens: int = 4096,
        timeout: float = 30.0,
        provider_name: str = "gemini",
    ) -> None:
        self._model = model
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._provider_name = provider_name
        http_options = genai_types.HttpOptions(
            base_url=base_url or None,
            timeout=int(timeout * 1000),  # HttpOptions.timeout is milliseconds
        )
        self._sdk_client = genai.Client(api_key=api_key, http_options=http_options)

    async def generate(self, request: LLMRequest) -> LLMResponse:
        system, contents = self._split_system_message(request)
        config = genai_types.GenerateContentConfig(
            system_instruction=system or None,
            temperature=request.temperature if request.temperature is not None else self._temperature,
            max_output_tokens=request.max_tokens or self._max_tokens,
            response_mime_type="application/json" if request.response_format == "json" else None,
        )
        started = time.perf_counter()
        try:
            response = await self._sdk_client.aio.models.generate_content(
                model=self._model, contents=contents, config=config
            )
        except genai_errors.APIError as exc:
            raise self._map_error(exc) from exc

        latency_ms = (time.perf_counter() - started) * 1000
        return self._to_llm_response(response, latency_ms)

    async def stream(self, request: LLMRequest) -> AsyncIterator[LLMResponse]:
        """Yield incremental LLMResponse chunks as text deltas arrive.

        Gemini's streaming API yields successive GenerateContentResponse
        objects, each carrying the incremental text for that step (not the
        accumulated text) plus a running `usage_metadata` snapshot. The
        final chunk's usage_metadata reflects the complete call, so that is
        what gets used for the final chunk's usage/latency/cost, matching
        OpenAIClient/AnthropicClient's contract of "only the final chunk
        carries usage".
        """
        system, contents = self._split_system_message(request)
        config = genai_types.GenerateContentConfig(
            system_instruction=system or None,
            temperature=request.temperature if request.temperature is not None else self._temperature,
            max_output_tokens=request.max_tokens or self._max_tokens,
            response_mime_type="application/json" if request.response_format == "json" else None,
        )
        started = time.perf_counter()
        last_usage = None
        last_finish_reason = None
        try:
            async for chunk in await self._sdk_client.aio.models.generate_content_stream(
                model=self._model, contents=contents, config=config
            ):
                last_usage = chunk.usage_metadata or last_usage
                if chunk.candidates:
                    finish_reason = chunk.candidates[0].finish_reason
                    if finish_reason:
                        last_finish_reason = finish_reason.value
                text = chunk.text or ""
                if text:
                    yield LLMResponse(
                        content=text,
                        metadata={"model": self._model, "provider": self._provider_name, "final": False},
                    )
        except genai_errors.APIError as exc:
            raise self._map_error(exc) from exc

        latency_ms = (time.perf_counter() - started) * 1000
        token_usage = (
            TokenUsage(
                promptTokens=last_usage.prompt_token_count or 0,
                completionTokens=last_usage.candidates_token_count or 0,
                totalTokens=last_usage.total_token_count or 0,
            )
            if last_usage
            else TokenUsage()
        )
        yield LLMResponse(
            content="",
            finishReason=last_finish_reason,
            usage=token_usage,
            latencyMs=latency_ms,
            cost=estimate_cost(self._provider_name, self._model, token_usage),
            metadata={"model": self._model, "provider": self._provider_name, "final": True},
        )

    async def structured_output(self, request: LLMRequest, schema: dict) -> LLMResponse:
        structured_request = request.model_copy(update={"response_format": "json"})
        return await self.generate(structured_request)

    async def health(self) -> bool:
        try:
            await self._sdk_client.aio.models.list(config={"page_size": 1})
            return True
        except genai_errors.APIError:
            return False

    def _map_error(self, exc: genai_errors.APIError) -> LLMTransientError | LLMPermanentError:
        """Translate a google.genai.errors.APIError into the provider-agnostic taxonomy.

        This is the ONLY place a genai.errors.* exception type is
        inspected. Classified by HTTP status code (exc.code) rather than
        exception subclass, since Gemini's 429 rate-limit is a ClientError
        (4xx) by the SDK's own convention but is still transient/retryable.
        """
        message = f"Gemini API returned {exc.code}: {exc.message}"
        if exc.code in _TRANSIENT_STATUS_CODES:
            return LLMTransientError(message)
        return LLMPermanentError(message)

    @staticmethod
    def _split_system_message(request: LLMRequest) -> tuple[str, list[genai_types.Content]]:
        """Gemini takes `system_instruction` separately from `contents`.

        Also maps LLMMessage.role="assistant" -> Gemini's "model" role,
        since Gemini's Content.role only accepts "user"/"model".
        """
        system_parts = [m.content for m in request.messages if m.role == "system"]
        contents = [
            genai_types.Content(
                role="model" if m.role == "assistant" else m.role,
                parts=[genai_types.Part(text=m.content)],
            )
            for m in request.messages
            if m.role != "system"
        ]
        return "\n\n".join(system_parts), contents

    def _to_llm_response(self, response: genai_types.GenerateContentResponse, latency_ms: float) -> LLMResponse:
        try:
            content = response.text or ""
        except (AttributeError, ValueError) as exc:
            raise LLMPermanentError(f"Unexpected Gemini API response shape: {response!r}") from exc

        finish_reason = None
        if response.candidates and response.candidates[0].finish_reason:
            finish_reason = response.candidates[0].finish_reason.value

        usage = response.usage_metadata
        token_usage = (
            TokenUsage(
                promptTokens=usage.prompt_token_count or 0,
                completionTokens=usage.candidates_token_count or 0,
                totalTokens=usage.total_token_count or 0,
            )
            if usage
            else TokenUsage()
        )
        return LLMResponse(
            content=content,
            finishReason=finish_reason,
            usage=token_usage,
            latencyMs=latency_ms,
            cost=estimate_cost(self._provider_name, self._model, token_usage),
            metadata={"model": self._model, "provider": self._provider_name},
            rawResponse=response,
        )


class GeminiProviderFactory(IProviderFactory):
    """Validates ModelConfiguration and builds GeminiClient instances.

    Only ever reached for configs with isInternal=false — see
    OpenAIProviderFactory's docstring for why "unless isInternal" no
    longer applies on this path.
    """

    def validate(self, config: ModelConfiguration) -> None:
        if not config.api_key and not config.secret_reference:
            raise InvalidConfigurationError("Gemini provider requires 'apiKey' or 'secretReference'")
        if not config.model_name:
            raise InvalidConfigurationError("Gemini provider requires 'modelName'")

    def create_client(self, config: ModelConfiguration) -> ILLMClient:
        if not config.api_key:
            raise ClientCreationError(
                "Gemini provider has no resolved apiKey — secretReference resolution "
                "is not implemented yet"
            )
        try:
            return GeminiClient(
                api_key=config.api_key,
                model=config.model_name,
                base_url=config.base_url,
                temperature=config.temperature,
                max_tokens=config.max_tokens,
                timeout=float(config.timeout) if config.timeout else 30.0,
            )
        except Exception as exc:  # noqa: BLE001 — wrap any SDK construction failure
            raise ClientCreationError(f"Failed to construct Gemini client: {exc}") from exc
