"""Internal (self-hosted / in-house) model provider adapter.

Routes to your own model-serving gateway instead of any third-party
vendor SDK. This is the adapter every `ModelConfiguration` with
`isInternal=true` uses, REGARDLESS of what `config.provider` says —
`provider` selects among third-party vendors (openai/anthropic/gemini);
`isInternal` is a separate axis entirely ("does this call leave our own
infrastructure at all"), and it always wins. See
ProviderRegistry.resolve() for where that precedence is enforced — this
file only implements the adapter itself.

There is no vendor SDK here — `InternalClient` is a thin `httpx.AsyncClient`
wrapper that POSTs a plain JSON body to your gateway and expects a plain
JSON body back, matching this project's own normalized shapes as closely
as possible so your gateway's contract is simple to implement:

    Request body (POST {base_url}):
        {
          "model": "<modelName>",
          "messages": [{"role": "system"|"user"|"assistant", "content": "..."}, ...],
          "temperature": <float>,
          "maxTokens": <int>,
          "stream": false,
          "responseFormat": "json" | null
        }

    Expected response body:
        {
          "content": "<generated text>",
          "finishReason": "<string or null>",
          "usage": {
            "promptTokens": <int>, "completionTokens": <int>, "totalTokens": <int>
          },
          "metadata": {...}            # optional, passed through as-is
        }

`base_url` is treated as the FULL completion endpoint URL (not an SDK
base path with an implicit sub-path appended) — point it directly at
whatever route your gateway exposes for chat completions. If a
`ModelConfiguration` omits `base_url`, `INTERNAL_MODEL_BASE_URL` (see
settings.py) is used as the default, so most internal-model requests
don't need to repeat the endpoint every time.

Every httpx exception is mapped, at this boundary, into the
provider-agnostic taxonomy in domain/interfaces/llm_errors.py — this is
the ONLY place an httpx.* exception type is inspected.
"""

import time
from collections.abc import AsyncIterator

import httpx

from ai_os.app.config.settings import get_settings
from ai_os.app.domain.interfaces.llm_client import ILLMClient
from ai_os.app.domain.interfaces.llm_errors import LLMPermanentError, LLMTransientError
from ai_os.app.domain.models.llm_request import LLMRequest
from ai_os.app.domain.models.llm_response import LLMResponse, TokenUsage
from ai_os.app.domain.models.model_configuration import ModelConfiguration
from ai_os.app.infrastructure.engines.Model.exceptions import (
    ClientCreationError,
    InvalidConfigurationError,
)
from ai_os.app.infrastructure.engines.Model.providers.base import IProviderFactory

# 429 and 5xx are transient even though 429 is nominally a "client" error —
# same convention as GeminiClient._map_error. Everything else 4xx (401,
# 403, 404, 400, 422, ...) is treated as permanent: the request itself is
# wrong and retrying it unchanged will fail the same way again.
_TRANSIENT_STATUS_CODES = {429, 500, 502, 503, 504}


class InternalClient(ILLMClient):
    """ILLMClient implementation backed by a plain HTTP call to an in-house gateway."""

    def __init__(
        self,
        base_url: str,
        model: str,
        api_key: str | None = None,
        temperature: float = 0.2,
        max_tokens: int = 4096,
        timeout: float = 30.0,
        provider_name: str = "internal",
    ) -> None:
        self._base_url = base_url
        self._model = model
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._provider_name = provider_name
        headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
        self._http_client = httpx.AsyncClient(headers=headers, timeout=timeout)

    async def generate(self, request: LLMRequest) -> LLMResponse:
        body = self._build_request_body(request, stream=False)
        started = time.perf_counter()
        try:
            response = await self._http_client.post(self._base_url, json=body)
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise self._map_status_error(exc) from exc
        except httpx.TimeoutException as exc:
            raise LLMTransientError(f"Internal model request timed out: {exc}") from exc
        except httpx.RequestError as exc:
            raise LLMTransientError(f"Internal model request failed: {exc}") from exc

        latency_ms = (time.perf_counter() - started) * 1000
        return self._to_llm_response(response, latency_ms)

    async def stream(self, request: LLMRequest) -> AsyncIterator[LLMResponse]:
        # Scaffolded, not yet implemented — your gateway's streaming
        # contract (SSE? chunked JSON lines?) isn't defined yet. Implement
        # against httpx's `client.stream(...)` once that contract exists,
        # mirroring OpenAIClient.stream()'s "only the final chunk carries
        # usage" convention for consistency with every other adapter.
        raise NotImplementedError("InternalClient.stream() is not yet implemented")
        yield  # pragma: no cover - makes this an async generator

    async def structured_output(self, request: LLMRequest, schema: dict) -> LLMResponse:
        structured_request = request.model_copy(update={"response_format": "json"})
        return await self.generate(structured_request)

    async def health(self) -> bool:
        """Best-effort reachability check.

        There's no standardized health-check convention across in-house
        gateways yet, so this derives `{scheme}://{host}/health` from
        `base_url` and treats a 2xx response as healthy. If your gateway
        uses a different convention, override this method's URL
        derivation or replace it with a fixed health endpoint once one is
        agreed on.
        """
        try:
            origin = httpx.URL(self._base_url)
            health_url = origin.copy_with(path="/health", query=None)
            response = await self._http_client.get(str(health_url), timeout=5.0)
            return response.status_code < 300
        except httpx.HTTPError:
            return False

    def _map_status_error(self, exc: httpx.HTTPStatusError) -> LLMTransientError | LLMPermanentError:
        """Translate an httpx.HTTPStatusError into the provider-agnostic taxonomy.

        This (plus the TimeoutException/RequestError branches in
        generate()) is the ONLY place an httpx.* exception type is
        inspected — ResilientLLMClient and every caller only ever see
        LLMTransientError/LLMPermanentError.
        """
        status_code = exc.response.status_code
        message = f"Internal model gateway returned {status_code}: {exc.response.text}"
        if status_code in _TRANSIENT_STATUS_CODES:
            return LLMTransientError(message)
        return LLMPermanentError(message)

    def _build_request_body(self, request: LLMRequest, stream: bool) -> dict:
        return {
            "model": self._model,
            "messages": [{"role": m.role, "content": m.content} for m in request.messages],
            "temperature": request.temperature if request.temperature is not None else self._temperature,
            "maxTokens": request.max_tokens or self._max_tokens,
            "stream": stream,
            "responseFormat": request.response_format,
        }

    def _to_llm_response(self, response: httpx.Response, latency_ms: float) -> LLMResponse:
        try:
            data = response.json()
            content = data["content"]
        except (ValueError, KeyError, TypeError) as exc:
            raise LLMPermanentError(
                f"Unexpected internal model gateway response shape: {response.text!r}"
            ) from exc

        usage_data = data.get("usage") or {}
        token_usage = TokenUsage(
            promptTokens=usage_data.get("promptTokens", 0) or 0,
            completionTokens=usage_data.get("completionTokens", 0) or 0,
            totalTokens=usage_data.get("totalTokens", 0) or 0,
        )
        return LLMResponse(
            content=content,
            finishReason=data.get("finishReason"),
            usage=token_usage,
            latencyMs=latency_ms,
            # Self-hosted inference is generally not billed per token the
            # way vendor APIs are — left unpriced (None) rather than
            # guessing $0.00, same "never silently report free" policy as
            # pricing.py::estimate_cost for any other unpriced model.
            cost=None,
            metadata={"model": self._model, "provider": self._provider_name, **data.get("metadata", {})},
            rawResponse=data,
        )


class InternalProviderFactory(IProviderFactory):
    """Validates ModelConfiguration and builds InternalClient instances.

    Used for EVERY ModelConfiguration with isInternal=true — see
    ProviderRegistry.resolve(), which routes here before `config.provider`
    is even consulted.
    """

    def validate(self, config: ModelConfiguration) -> None:
        if not config.model_name:
            raise InvalidConfigurationError("Internal model configuration requires 'modelName'")
        base_url = config.base_url or get_settings().internal_model_base_url
        if not base_url:
            raise InvalidConfigurationError(
                "Internal model configuration requires either 'baseUrl' or a configured "
                "INTERNAL_MODEL_BASE_URL default"
            )
        # Deliberately no apiKey requirement — internal gateways on a
        # trusted network often don't need one. If apiKey IS set, it's
        # forwarded as a bearer token (see InternalClient.__init__).

    def create_client(self, config: ModelConfiguration) -> ILLMClient:
        settings = get_settings()
        base_url = config.base_url or settings.internal_model_base_url
        if not base_url:
            raise ClientCreationError(
                "Cannot construct internal model client: no baseUrl on the configuration "
                "and no INTERNAL_MODEL_BASE_URL default configured"
            )
        try:
            return InternalClient(
                base_url=base_url,
                model=config.model_name,
                api_key=config.api_key,
                temperature=config.temperature,
                max_tokens=config.max_tokens,
                timeout=float(config.timeout) if config.timeout else settings.internal_model_timeout_seconds,
            )
        except Exception as exc:  # noqa: BLE001 — wrap any construction failure
            raise ClientCreationError(f"Failed to construct internal model client: {exc}") from exc
