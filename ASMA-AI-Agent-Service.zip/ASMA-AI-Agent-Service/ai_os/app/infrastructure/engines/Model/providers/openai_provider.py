"""OpenAI provider adapter.

Owns the only place in the codebase that constructs an `openai` SDK
client. `OpenAIClient` wraps `AsyncOpenAI` and implements `ILLMClient`,
converting every response into the fixed `LLMResponse` shape (content,
usage, latency, cost) so callers never touch
`response.choices[0].message.content` — or any other OpenAI-specific
shape — themselves.

Every SDK exception is mapped, at this boundary, into the provider-
agnostic taxonomy in domain/interfaces/llm_errors.py (LLMTransientError /
LLMPermanentError). This is the one place an `openai.*` exception type is
allowed to appear — ResilientLLMClient's retry/fallback logic (see
../resilient_client.py) only ever sees LLMError subclasses, so it never
needs to know which provider raised the error.

Uses the official `openai` Python SDK (pinned in requirements.txt) rather
than a raw HTTP call, for the SDK's built-in connection handling — see
the original rationale in the now-retired infrastructure/llm/llm_client.py.
"""

import time
from collections.abc import AsyncIterator

from openai import (
    APIConnectionError,
    APIStatusError,
    APITimeoutError,
    AsyncOpenAI,
    AuthenticationError,
    BadRequestError,
    InternalServerError,
    NotFoundError,
    OpenAIError,
    PermissionDeniedError,
    RateLimitError,
    UnprocessableEntityError,
)

from ai_os.app.domain.interfaces.llm_client import ILLMClient
from ai_os.app.domain.interfaces.llm_errors import LLMPermanentError, LLMTransientError
from ai_os.app.domain.models.llm_request import LLMRequest
from ai_os.app.domain.models.llm_response import LLMResponse, TokenUsage
from ai_os.app.domain.models.model_configuration import ModelConfiguration
from ai_os.app.infrastructure.engines.Model.exceptions import (
    ClientCreationError,
    InvalidConfigurationError,
)
from ai_os.app.infrastructure.engines.Model.pricing import estimate_cost
from ai_os.app.infrastructure.engines.Model.providers.base import IProviderFactory

# Non-retryable — the request itself is wrong or the credentials are bad;
# retrying with the same input will fail again the same way.
_PERMANENT_ERROR_TYPES = (
    AuthenticationError,
    PermissionDeniedError,
    BadRequestError,
    NotFoundError,
    UnprocessableEntityError,
)
# Retryable — transient by nature (rate limiting, timeouts, connection
# drops, the provider's own infrastructure failing momentarily).
_TRANSIENT_ERROR_TYPES = (
    RateLimitError,
    APITimeoutError,
    APIConnectionError,
    InternalServerError,
)


class OpenAIClient(ILLMClient):
    """ILLMClient implementation backed by AsyncOpenAI."""

    def __init__(
        self,
        api_key: str,
        model: str,
        base_url: str | None = None,
        temperature: float = 0.2,
        max_tokens: int = 4096,
        timeout: float = 30.0,
        provider_name: str = "openai",
    ) -> None:
        self._model = model
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._provider_name = provider_name
        self._sdk_client = AsyncOpenAI(
            api_key=api_key,
            base_url=base_url or None,
            timeout=timeout,
        )

    async def generate(self, request: LLMRequest) -> LLMResponse:
        started = time.perf_counter()
        try:
            response = await self._sdk_client.chat.completions.create(
                model=self._model,
                messages=[{"role": m.role, "content": m.content} for m in request.messages],
                temperature=request.temperature if request.temperature is not None else self._temperature,
                max_completion_tokens=request.max_tokens or self._max_tokens,
                response_format={"type": "json_object"} if request.response_format == "json" else None,
            )
        except OpenAIError as exc:
            raise self._map_error(exc) from exc

        latency_ms = (time.perf_counter() - started) * 1000
        return self._to_llm_response(response, latency_ms)

    async def stream(self, request: LLMRequest) -> AsyncIterator[LLMResponse]:
        """Yield incremental LLMResponse chunks as they arrive from the API.

        Each yielded chunk carries only the incremental `content` delta
        (not the accumulated text) — callers that want the full text
        should concatenate `.content` across chunks themselves, mirroring
        how AsyncOpenAI's own delta stream works. Usage/latency/cost are
        not available mid-stream from the OpenAI API by default, so
        intermediate chunks carry empty TokenUsage()/latency_ms=None/
        cost=None; the FINAL chunk carries the accumulated totals for all
        three, computed the same way generate() does.
        """
        started = time.perf_counter()
        accumulated_content = ""
        finish_reason: str | None = None
        try:
            stream = await self._sdk_client.chat.completions.create(
                model=self._model,
                messages=[{"role": m.role, "content": m.content} for m in request.messages],
                temperature=request.temperature if request.temperature is not None else self._temperature,
                max_completion_tokens=request.max_tokens or self._max_tokens,
                response_format={"type": "json_object"} if request.response_format == "json" else None,
                stream=True,
                stream_options={"include_usage": True},
            )
            async for chunk in stream:
                usage = getattr(chunk, "usage", None)
                if usage is not None:
                    # The final chunk in an OpenAI stream carries usage and
                    # an empty choices list — emit the accumulated totals
                    # here instead of a content delta.
                    latency_ms = (time.perf_counter() - started) * 1000
                    token_usage = TokenUsage(
                        promptTokens=getattr(usage, "prompt_tokens", 0) or 0,
                        completionTokens=getattr(usage, "completion_tokens", 0) or 0,
                        totalTokens=getattr(usage, "total_tokens", 0) or 0,
                    )
                    yield LLMResponse(
                        content="",
                        finishReason=finish_reason,
                        usage=token_usage,
                        latencyMs=latency_ms,
                        cost=estimate_cost(self._provider_name, self._model, token_usage),
                        metadata={"model": self._model, "provider": self._provider_name, "final": True},
                        rawResponse=chunk,
                    )
                    continue

                choice = chunk.choices[0] if chunk.choices else None
                if choice is None:
                    continue
                delta = getattr(choice.delta, "content", None) or ""
                if choice.finish_reason:
                    finish_reason = choice.finish_reason
                accumulated_content += delta
                if delta:
                    yield LLMResponse(
                        content=delta,
                        finishReason=choice.finish_reason,
                        metadata={"model": self._model, "final": False},
                        rawResponse=chunk,
                    )
        except OpenAIError as exc:
            raise self._map_error(exc) from exc

    async def structured_output(self, request: LLMRequest, schema: dict) -> LLMResponse:
        structured_request = request.model_copy(update={"response_format": "json"})
        return await self.generate(structured_request)

    async def health(self) -> bool:
        try:
            await self._sdk_client.models.list()
            return True
        except OpenAIError:
            return False

    def _map_error(self, exc: OpenAIError) -> LLMTransientError | LLMPermanentError:
        """Translate an openai.* exception into the provider-agnostic taxonomy.

        This is the ONLY place an openai.* exception type is inspected —
        everything above this adapter (ResilientLLMClient, callers) only
        ever sees LLMTransientError/LLMPermanentError.
        """
        message = f"OpenAI API request failed: {exc}"
        if isinstance(exc, APIStatusError):
            message = f"OpenAI API returned {exc.status_code}: {exc.response.text}"
        if isinstance(exc, _PERMANENT_ERROR_TYPES):
            return LLMPermanentError(message)
        if isinstance(exc, _TRANSIENT_ERROR_TYPES):
            return LLMTransientError(message)
        # Unclassified OpenAIError subclass — default to transient so a
        # genuinely temporary issue we didn't anticipate isn't treated as
        # permanent and given up on immediately; ResilientLLMClient still
        # bounds the number of retries.
        return LLMTransientError(message)

    def _to_llm_response(self, response, latency_ms: float) -> LLMResponse:
        try:
            choice = response.choices[0]
            content = choice.message.content or ""
            finish_reason = choice.finish_reason
        except (AttributeError, IndexError) as exc:
            raise LLMPermanentError(f"Unexpected OpenAI API response shape: {response!r}") from exc

        usage = response.usage
        token_usage = (
            TokenUsage(
                promptTokens=getattr(usage, "prompt_tokens", 0) or 0,
                completionTokens=getattr(usage, "completion_tokens", 0) or 0,
                totalTokens=getattr(usage, "total_tokens", 0) or 0,
            )
            if usage
            else TokenUsage()
        )
        return LLMResponse(
            content=content,
            finishReason=finish_reason,
            usage=token_usage,
            latencyMs=latency_ms,
            cost=estimate_cost(self._provider_name, self._model, token_usage),
            metadata={"model": getattr(response, "model", None), "provider": self._provider_name},
            rawResponse=response,
        )


class OpenAIProviderFactory(IProviderFactory):
    """Validates ModelConfiguration and builds OpenAIClient instances.

    Only ever reached for configs with isInternal=false — ProviderRegistry
    .resolve() routes isInternal=true straight to InternalProviderFactory
    before this is consulted (see provider_registry.py). So an apiKey is
    always required here; there is no "unless isInternal" exception on
    this path.
    """

    def validate(self, config: ModelConfiguration) -> None:
        if not config.api_key and not config.secret_reference:
            raise InvalidConfigurationError("OpenAI provider requires 'apiKey' or 'secretReference'")
        if not config.model_name:
            raise InvalidConfigurationError("OpenAI provider requires 'modelName'")

    def create_client(self, config: ModelConfiguration) -> ILLMClient:
        if not config.api_key:
            raise ClientCreationError(
                "OpenAI provider has no resolved apiKey — secretReference resolution "
                "is not implemented yet"
            )
        try:
            return OpenAIClient(
                api_key=config.api_key,
                model=config.model_name,
                base_url=config.base_url,
                temperature=config.temperature,
                max_tokens=config.max_tokens,
                timeout=float(config.timeout) if config.timeout else 30.0,
            )
        except Exception as exc:  # noqa: BLE001 — wrap any SDK construction failure
            raise ClientCreationError(f"Failed to construct OpenAI client: {exc}") from exc
