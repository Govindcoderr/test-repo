"""ResilientLLMClient — timeout, retry, and fallback wrapped around any ILLMClient.

Rather than every provider adapter (openai_provider.py, and future
anthropic_provider.py, etc.) re-implementing timeout/retry/fallback
itself, ClientFactory wraps whatever raw ILLMClient a provider factory
builds in this decorator before returning it. This keeps that concern
fully isolated from provider-specific code — adding a new provider never
means re-implementing resilience, and changing the resilience policy
never means touching a provider adapter.

    ClientFactory.create_client(config)
        │
        ├── provider_factory.create_client(config)   -> raw ILLMClient
        │
        └── ResilientLLMClient(raw_client, config, fallback_factory)
                │
                ├── wraps every call with asyncio.wait_for(..., config.timeout)
                ├── retries config.retry times on LLMTransientError, with
                │   exponential backoff (mirrors kernel/resilience/retry_manager.py's
                │   idiom so the codebase has one retry pattern, not two)
                └── on retry exhaustion, if config.fallback is set, builds
                    a second ILLMClient from it (via `fallback_factory`,
                    which is ClientFactory.create_client bound by
                    ClientFactory itself) and attempts the call once
                    against that client instead

LLMPermanentError is never retried or grounds for fallback — the same
failure would just happen again immediately.
"""

import asyncio
from collections.abc import AsyncIterator, Awaitable, Callable
from typing import TypeVar

from ai_os.app.domain.interfaces.llm_client import ILLMClient
from ai_os.app.domain.interfaces.llm_errors import LLMError, LLMPermanentError, LLMTransientError
from ai_os.app.domain.models.llm_request import LLMRequest
from ai_os.app.domain.models.llm_response import LLMResponse
from ai_os.app.domain.models.model_configuration import ModelConfiguration

T = TypeVar("T")

DEFAULT_TIMEOUT_SECONDS = 30.0
DEFAULT_RETRY_DELAY_SECONDS = 0.5
RETRY_BACKOFF_MULTIPLIER = 2.0


class LLMRetryExhaustedError(LLMError):
    """Raised when all retries (and an attempted fallback, if any) failed."""


class ResilientLLMClient(ILLMClient):
    """Wraps an ILLMClient with timeout, retry, and single-hop fallback."""

    def __init__(
        self,
        primary: ILLMClient,
        config: ModelConfiguration,
        fallback_factory: Callable[[ModelConfiguration], ILLMClient] | None = None,
    ) -> None:
        """`fallback_factory` builds the fallback ILLMClient lazily (only if

        and when needed) from `config.fallback`. ClientFactory passes its
        own `create_client` bound method here so building a fallback goes
        through the same validate -> resolve -> construct path as any
        other client, rather than duplicating that logic in this class.
        """
        self._primary = primary
        self._config = config
        self._fallback_factory = fallback_factory
        self._fallback_client: ILLMClient | None = None
        self._timeout_seconds = float(config.timeout) if config.timeout else DEFAULT_TIMEOUT_SECONDS
        self._max_retries = max(config.retry, 0)

    async def generate(self, request: LLMRequest) -> LLMResponse:
        return await self._call_with_resilience(lambda client: client.generate(request))

    async def structured_output(self, request: LLMRequest, schema: dict) -> LLMResponse:
        return await self._call_with_resilience(
            lambda client: client.structured_output(request, schema)
        )

    async def stream(self, request: LLMRequest) -> AsyncIterator[LLMResponse]:
        """Timeout/retry apply only to establishing the stream, not each chunk.

        Once a stream starts yielding chunks, a mid-stream transient
        failure is surfaced to the caller as-is rather than silently
        retried — retrying a partially-consumed stream would mean either
        re-yielding duplicate content or losing track of what the caller
        already received, neither of which is safe to do implicitly.
        Establishing the stream itself (the first `__anext__`, which is
        where OpenAI's SDK actually issues the HTTP request) DOES go
        through the same timeout/retry/fallback policy as generate().
        """
        client = self._primary
        attempt = 0
        delay = DEFAULT_RETRY_DELAY_SECONDS
        last_error: LLMError | None = None

        while attempt <= self._max_retries:
            try:
                stream = client.stream(request)
                first_chunk = await asyncio.wait_for(
                    stream.__anext__(), timeout=self._timeout_seconds
                )
                # Stream established and first chunk received — hand off
                # to the caller for the remainder without further
                # retry/timeout wrapping (see docstring).
                yield first_chunk
                async for chunk in stream:
                    yield chunk
                return
            except StopAsyncIteration:
                return
            except LLMPermanentError:
                raise
            except (LLMTransientError, TimeoutError, asyncio.TimeoutError) as exc:
                last_error = exc if isinstance(exc, LLMError) else LLMTransientError(str(exc))
                attempt += 1
                if attempt > self._max_retries:
                    break
                await asyncio.sleep(delay)
                delay *= RETRY_BACKOFF_MULTIPLIER

        fallback_client = self._get_fallback_client()
        if fallback_client is not None:
            async for chunk in fallback_client.stream(request):
                yield chunk
            return

        raise LLMRetryExhaustedError(
            f"LLM stream failed after {self._max_retries + 1} attempt(s): {last_error}"
        ) from last_error

    async def health(self) -> bool:
        try:
            return await asyncio.wait_for(self._primary.health(), timeout=self._timeout_seconds)
        except (LLMError, TimeoutError, asyncio.TimeoutError):
            return False

    # ─── Shared retry/fallback logic for non-streaming calls ─────────────

    async def _call_with_resilience(
        self, operation: Callable[[ILLMClient], Awaitable[LLMResponse]]
    ) -> LLMResponse:
        last_error: LLMError | None = None
        delay = DEFAULT_RETRY_DELAY_SECONDS

        for attempt in range(self._max_retries + 1):
            try:
                return await asyncio.wait_for(
                    operation(self._primary), timeout=self._timeout_seconds
                )
            except LLMPermanentError:
                raise
            except (LLMTransientError, TimeoutError, asyncio.TimeoutError) as exc:
                last_error = exc if isinstance(exc, LLMError) else LLMTransientError(str(exc))
                if attempt < self._max_retries:
                    await asyncio.sleep(delay)
                    delay *= RETRY_BACKOFF_MULTIPLIER

        fallback_client = self._get_fallback_client()
        if fallback_client is not None:
            try:
                return await asyncio.wait_for(
                    operation(fallback_client), timeout=self._timeout_seconds
                )
            except LLMError as exc:
                last_error = exc

        raise LLMRetryExhaustedError(
            f"LLM call failed after {self._max_retries + 1} attempt(s)"
            f"{' plus fallback' if fallback_client is not None else ''}: {last_error}"
        ) from last_error

    def _get_fallback_client(self) -> ILLMClient | None:
        if self._config.fallback is None or self._fallback_factory is None:
            return None
        if self._fallback_client is None:
            fallback_config = (
                self._config.fallback
                if isinstance(self._config.fallback, ModelConfiguration)
                else ModelConfiguration.model_validate(self._config.fallback)
            )
            self._fallback_client = self._fallback_factory(fallback_config)
        return self._fallback_client
