"""Provider name -> IProviderFactory lookup.

This is the ONLY place that maps a `ModelConfiguration.provider` string to
a concrete implementation. Nothing else in the Model engine (or anywhere
else in the codebase) is allowed to branch on provider name — see
client_factory.py, which only ever calls `registry.resolve(config)`.

To add a THIRD-PARTY vendor provider, add one entry to PROVIDER_FACTORIES
(and implement the factory in providers/<name>_provider.py) — see
providers/__init__.py's docstring for the full checklist.

`isInternal` is a SEPARATE axis from `provider` — see resolve() below.
"""

from ai_os.app.domain.models.model_configuration import ModelConfiguration
from ai_os.app.infrastructure.engines.Model.exceptions import UnsupportedProviderError
from ai_os.app.infrastructure.engines.Model.providers.anthropic_provider import AnthropicProviderFactory
from ai_os.app.infrastructure.engines.Model.providers.base import IProviderFactory
from ai_os.app.infrastructure.engines.Model.providers.gemini_provider import GeminiProviderFactory
from ai_os.app.infrastructure.engines.Model.providers.internal_provider import InternalProviderFactory
from ai_os.app.infrastructure.engines.Model.providers.openai_provider import OpenAIProviderFactory

# Registered THIRD-PARTY vendor providers, selected via
# ModelConfiguration.provider. Add new vendors here as they're
# implemented — e.g. "openai_compatible": OpenAICompatibleProviderFactory()
# for BYOM/self-hosted endpoints that speak the OpenAI API shape (vLLM, LM
# Studio, Ollama's OpenAI-compatible mode, LiteLLM, etc.) — note that's a
# DIFFERENT case from isInternal=true below: that's for a vendor-shaped
# API you don't operate yourself; isInternal is for your own in-house
# gateway regardless of what shape it speaks.
PROVIDER_FACTORIES: dict[str, IProviderFactory] = {
    "openai": OpenAIProviderFactory(),
    "anthropic": AnthropicProviderFactory(),
    "gemini": GeminiProviderFactory(),
}

# The always-internal factory — used for every ModelConfiguration with
# isInternal=true, regardless of what `provider` says. Not part of
# PROVIDER_FACTORIES because it isn't selected by provider name; see
# resolve().
_INTERNAL_FACTORY: IProviderFactory = InternalProviderFactory()


class ProviderRegistry:
    """Thin lookup wrapper around PROVIDER_FACTORIES (kept as a class for testability)."""

    def __init__(self, factories: dict[str, IProviderFactory] | None = None) -> None:
        self._factories = factories if factories is not None else PROVIDER_FACTORIES

    def resolve(self, config: ModelConfiguration) -> IProviderFactory:
        """Resolve the IProviderFactory for `config`, honoring the isInternal override.

        `isInternal=true` ALWAYS routes to the internal-gateway factory,
        no matter what `config.provider` says — this is the single place
        that precedence is enforced. `config.provider` is only consulted
        when `isInternal` is false/unset. See client_factory.py and
        validators.py, both of which call this instead of `get()`
        directly, so the override can never be bypassed by a caller that
        forgot to check `isInternal` itself.
        """
        if config.is_internal:
            return _INTERNAL_FACTORY
        return self.get(config.provider)

    def get(self, provider: str) -> IProviderFactory:
        """Look up a THIRD-PARTY vendor factory by provider name directly.

        Prefer `resolve(config)` over calling this directly, unless you
        specifically need to bypass the isInternal override (e.g.
        inspecting what a given provider name would do on its own).
        """
        factory = self._factories.get(provider)
        if factory is None:
            raise UnsupportedProviderError(
                f"No provider factory registered for '{provider}'. "
                f"Supported providers: {sorted(self._factories.keys())}"
            )
        return factory

    def is_supported(self, provider: str) -> bool:
        return provider in self._factories

    def list_supported(self) -> list[str]:
        return sorted(self._factories.keys())
