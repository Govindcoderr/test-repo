"""Supervisor engine.

The Supervisor is the kernel's dynamic-loop entry point (see
AIKernel._resolve_initial_step, which looks for the exact capability
"supervisor.understand_goal"). It exposes three capabilities that chain
together via KernelResponse.next_step:

    supervisor.understand_goal
        -> produces a comprehensive goal-understanding brief: goal, intent,
           complexity, key entities, constraints, success criteria,
           ambiguities, suggested capability hints, a risk assessment, and
           an execution-path decision (see schemas.GoalAnalysis).
        -> the execution path decides what happens next — see
           _decide_execution_path for the deterministic precedence this
           applies on top of the LLM's own pick:
             - "needs_clarification" (allowed at ANY risk level — asking
               the user a question has no side effects, so risk never
               suppresses it; checked first, before the risk override
               below): raises a human-in-the-loop request via the standard
               `humanInputRequired` signal (see AIKernel._await_human_input)
               instead of guessing or planning against real ambiguity. The
               kernel suspends, then re-dispatches THIS SAME capability
               with the human's answer (or a timeout marker) merged into
               the payload — see the resumed-call handling below.
             - "requires_planning" (the default / risk medium|high forces
               this over "direct_response"): hands off to
               "planning.create_plan", passing BOTH the raw, unmodified
               userQuery and the full analysis (as `strategy`) — Planning
               always has the ground truth of what the user said, plus the
               structured brief so it doesn't have to re-derive it.
             - "direct_response" (only possible when risk is low): skips
               Planning entirely and hands off straight to
               "supervisor.validate_result" with the LLM's own answer as
               `mergedResult` — the same final safety gate every other
               workflow passes through, just without a task breakdown in
               between.

    supervisor.monitor_execution
        -> a lightweight, kernel-initiated mid-workflow checkpoint (NOT
           part of the normal next_step chain — the kernel dispatches this
           directly via AIKernel._run_monitoring_checkpoint at specific
           checkpoints, e.g. right after Planning produces a plan). Reviews
           what just happened and the pending next step, and returns a
           "continue" or "escalate" verdict for the kernel to act on. Only
           invoked when the workflow's complexity warrants it, or when the
           kernel's own cheap deterministic checks already flagged a
           concern — see AIKernel.MONITOR_CHECKPOINT_CAPABILITIES and
           MONITOR_COMPLEXITY_LEVELS.

    supervisor.validate_result
        -> the mandatory final gate for every workflow. Validates the
           collected results (or error context) against the original
           goal/intent and produces exactly one of four outcomes:
             - completed          -> terminal; finalResponse set for the user.
             - needs_more_planning -> next_step back to "planning.create_plan"
               with a revision brief (NOT a failure or user prompt).
             - error              -> terminal; user-facing error explanation.
             - needs_approval     -> terminal; approval/clarification request
               shown to the user.
           This capability is also the kernel's forced fallback destination
           whenever an engine fails or a dispatch error occurs mid-workflow
           (see AIKernel._execute_dynamic_loop) — nothing should reach the
           user without passing through this stage.

Every stage delegates its reasoning to an ILLMClient (see
domain/interfaces/llm_client.py) built once at startup by the Model
engine (see infrastructure/engines/Model/model_engine.py) from a fixed
ModelConfiguration sourced from Settings.supervisor_model_configuration()
— Supervisor never receives model configuration from the backend/kernel;
that's reserved for Agent Runtime workers.
"""

import json
import re
from typing import Any

from ai_os.app.domain.interfaces.llm_client import ILLMClient
from ai_os.app.domain.models.engine import EngineManifest
from ai_os.app.domain.models.kernel_request import KernelRequest
from ai_os.app.domain.models.kernel_response import KernelResponse, NextStep
from ai_os.app.domain.models.llm_request import LLMRequest
from ai_os.app.domain.models.llm_response import LLMResponse
from ai_os.app.infrastructure.engines.base_engine import BaseEngine
from ai_os.app.infrastructure.engines.Supervisor.prompts import (
    CLARIFICATION_ANSWERED_NOTE_TEMPLATE,
    CLARIFICATION_TIMED_OUT_NOTE_TEMPLATE,
    MONITOR_EXECUTION_SYSTEM_PROMPT,
    MONITOR_EXECUTION_USER_PROMPT_TEMPLATE,
    UNDERSTAND_GOAL_SYSTEM_PROMPT,
    UNDERSTAND_GOAL_USER_PROMPT_TEMPLATE,
    VALIDATE_RESULT_SYSTEM_PROMPT,
    VALIDATE_RESULT_USER_PROMPT_TEMPLATE,
)
from ai_os.app.infrastructure.engines.Supervisor.schemas import (
    GoalAnalysis,
    MonitorVerdict,
    ValidationOutcome,
    ValidationVerdict,
)

_JSON_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)\s*```", re.DOTALL)


class SupervisorEngine(BaseEngine):
    """Understands goals, monitors/merges execution, and validates results."""

    # Referenced by name rather than repeating the literal string across
    # _understand_goal's direct_response branch — mirrors AIKernel's own
    # VALIDATION_CAPABILITY constant for the same capability.
    VALIDATE_RESULT_CAPABILITY = "supervisor.validate_result"

    def __init__(self, llm_client: ILLMClient) -> None:
        """`llm_client` is required — built once by the composition root

        (main.py) via ModelEngine.create_client_from_config(), using
        Settings.supervisor_model_configuration(). Supervisor holds this
        client for its entire lifetime; it never asks the kernel for one.
        """
        super().__init__(
            EngineManifest(
                engineId="supervisor-engine",
                name="Supervisor Engine",
                version="1.0.0",
                description=(
                    "Understands the user's goal, analyzes intent and complexity, "
                    "monitors and merges downstream execution results, and "
                    "validates the final result before it is returned."
                ),
                capabilities=[
                    "supervisor.understand_goal",
                    "supervisor.monitor_execution",
                    "supervisor.validate_result",
                ],
                resources=[],
                priority=100,
            )
        )
        self._llm = llm_client

    async def execute(self, request: KernelRequest) -> KernelResponse:
        capability = request.capability
        try:
            if capability == "supervisor.understand_goal":
                return await self._understand_goal(request)
            if capability == "supervisor.monitor_execution":
                return await self._monitor_execution(request)
            if capability == "supervisor.validate_result":
                return await self._validate_result(request)

            return self._failure(
                request,
                code="UNSUPPORTED_CAPABILITY",
                message=f"Supervisor engine does not support capability '{capability}'",
            )
        except Exception as exc:  # noqa: BLE001 — surface any stage failure as a KernelResponse
            return self._failure(
                request,
                code="SUPERVISOR_STAGE_FAILED",
                message=f"Supervisor stage '{capability}' failed: {exc}",
                retryable=False,
            )

    # ─── Stage 1: understand_goal ───────────────────────────────────────

    # Deterministic override applied on top of whatever executionPath the
    # LLM itself picked — see _decide_execution_path. Risk assessment is
    # the one part of this stage's output the kernel/Supervisor trusts more
    # than the LLM's own path choice: a model can misjudge a query as
    # trivially safe when it actually carries risk, but it should never be
    # allowed to skip Planning on a self-assessed medium/high risk goal by
    # picking "direct_response" instead.
    #
    # This override does NOT apply to "needs_clarification" — asking the
    # user a question is never risky (it takes no action and has no side
    # effects), so a medium/high risk assessment must never suppress a
    # genuine clarification request. Risk only gates the "skip planning
    # entirely" path (direct_response), never the "ask before proceeding"
    # path. See _decide_execution_path for where this distinction is
    # actually enforced.
    _RISK_LEVELS_FORCING_PLANNING = {"medium", "high"}

    async def _understand_goal(self, request: KernelRequest) -> KernelResponse:
        payload = request.payload
        user_query = payload.get("userQuery", "")
        agent_definition = payload.get("agentDefinition")
        attachments = payload.get("attachments", [])
        # Injected by the kernel before dispatch for memory-required
        # capabilities — see AIKernel.MEMORY_REQUIRED_PREFIXES/_dispatch_step.
        memory_context = payload.get("memoryContext", [])

        # This capability can be re-dispatched by the kernel as the resumed
        # half of a needs_clarification human-in-the-loop round-trip (see
        # AIKernel._await_human_input) — the payload then carries either
        # humanInputAnswer or humanInputTimedOut, plus humanInputQuestion
        # echoing what was originally asked. Fold that into the prompt as
        # an extra note so the LLM finishes the analysis instead of asking
        # the same clarifying question again.
        clarification_context = self._build_clarification_context(payload)

        user_prompt = UNDERSTAND_GOAL_USER_PROMPT_TEMPLATE.format(
            conversation_history=self._format_conversation_history(memory_context),
            user_query=user_query,
            agent_context=json.dumps(agent_definition) if agent_definition else "none",
            attachments=json.dumps(attachments) if attachments else "none",
            clarification_context=clarification_context,
        )
        llm_response = await self._complete_json(UNDERSTAND_GOAL_SYSTEM_PROMPT, user_prompt)
        analysis = GoalAnalysis.model_validate(self._parse_json(llm_response.content))

        execution_path = self._decide_execution_path(analysis)

        # Full analysis, not just goal/intent/complexity — Planning receives
        # this entire brief alongside the raw userQuery so it doesn't have
        # to re-derive entities, constraints, success criteria, etc. from
        # the query itself.
        strategy = analysis.model_dump(by_alias=True)
        strategy["executionPath"] = execution_path

        # conversationTurn tells the kernel exactly what to store for this
        # step in the fallback memory store (see AIKernel._save_memory_turn).
        # The "ai" side stores the FULL GoalAnalysis result (serialized),
        # not just the goal string, so later turns/stages have complete
        # context of what was actually analyzed rather than a truncated
        # restatement.
        #
        # A resumed needs_clarification call (clarification_context set
        # above) is NOT a fresh human utterance — the kernel is
        # re-dispatching this same capability with an answer/timeout, and
        # the user's query was already recorded as a "human" turn on the
        # first dispatch. Recording it under "system" here avoids double-
        # logging the same raw query as two separate human turns.
        is_resumed_call = clarification_context != "none"
        conversation_turn = (
            {"system": f"[System] Resuming after clarification: {clarification_context}"}
            if is_resumed_call
            else {"human": user_query}
        )
        response = self._success(
            request,
            {
                "strategy": strategy,
                "modelUsage": self._model_usage_entry(llm_response),
                "conversationTurn": {
                    **conversation_turn,
                    "ai": json.dumps(strategy, default=str),
                },
            },
        )

        if execution_path == "needs_clarification":
            # Raise the standard human-in-the-loop signal instead of a
            # next_step — AIKernel._execute_dynamic_loop checks for this on
            # every response and suspends the whole workflow (see
            # kernel.py), then re-dispatches THIS SAME capability
            # (supervisor.understand_goal) with the answer/timeout merged
            # into the payload, landing back here via clarification_context
            # above.
            response.result["humanInputRequired"] = {
                "question": analysis.clarification_question,
                "taskId": None,
            }
            return response

        if execution_path == "direct_response":
            # Skip Planning entirely, but still pass through the mandatory
            # final gate — supervisor.validate_result — with the direct
            # answer as mergedResult, exactly like a normal workflow's
            # collected output. See VALIDATE_RESULT_SYSTEM_PROMPT: "Nothing
            # reaches the user except through your judgment here."
            response.next_step = NextStep(
                capability=self.VALIDATE_RESULT_CAPABILITY,
                payload={
                    "userQuery": user_query,
                    "strategy": strategy,
                    "mergedResult": analysis.direct_response,
                },
            )
            return response

        # "requires_planning" — the default path. Planning receives BOTH
        # the raw, unmodified userQuery AND the full goal-understanding
        # output (strategy) — the raw query so Planning always has the
        # ground truth of what the user actually said, and strategy so it
        # doesn't have to re-analyze the query from scratch.
        response.next_step = NextStep(
            capability="planning.create_plan",
            payload={
                "userQuery": user_query,
                "strategy": strategy,
                "agentDefinition": agent_definition,
                "attachments": attachments,
            },
        )
        return response

    def _decide_execution_path(self, analysis: GoalAnalysis) -> str:
        """Apply the deterministic risk override on top of the LLM's pick.

        The LLM is instructed to already respect this in its own prompt,
        but risk is exactly the kind of judgment call worth double-checking
        in code rather than trusting a single model call unconditionally.

        Precedence, checked in this order:
        1. A well-formed "needs_clarification" pick is ALWAYS honored,
           regardless of risk level — asking the user a question is never
           risky (no action taken, no side effects), so risk must never
           suppress a genuine clarification request. This is checked
           FIRST, before the risk override below, so it can never be
           overridden by it.
        2. Otherwise, a medium/high risk goal must never skip Planning via
           "direct_response" — forced to "requires_planning" instead.
        3. A malformed "direct_response" (no actual answer provided) also
           falls back to "requires_planning" rather than handing an empty
           answer to validate_result.
        4. Otherwise, trust the LLM's own pick (including
           "requires_planning" itself, or a malformed "needs_clarification"
           with no question, which also falls back to "requires_planning").
        """
        if analysis.execution_path == "needs_clarification" and analysis.clarification_question:
            return "needs_clarification"
        if analysis.risk_level in self._RISK_LEVELS_FORCING_PLANNING:
            return "requires_planning"
        if analysis.execution_path == "direct_response" and not analysis.direct_response:
            # Guard against a malformed LLM response (path chosen but no
            # answer actually provided) — fall back to planning rather
            # than handing an empty answer to validate_result.
            return "requires_planning"
        if analysis.execution_path == "needs_clarification" and not analysis.clarification_question:
            # Malformed: path chosen but no question provided. Already
            # excluded from the first branch above, so this only reaches
            # here when clarification_question is empty.
            return "requires_planning"
        return analysis.execution_path

    @staticmethod
    def _build_clarification_context(payload: dict) -> str:
        """Render the resumed-call note for a needs_clarification round-trip.

        Returns "none" (matching the prompt template's expectation) when
        this is a normal, non-resumed call — i.e. neither humanInputAnswer
        nor humanInputTimedOut is present in the payload.
        """
        question = payload.get("humanInputQuestion")
        if payload.get("humanInputTimedOut"):
            return CLARIFICATION_TIMED_OUT_NOTE_TEMPLATE.format(clarification_question=question or "")
        answer = payload.get("humanInputAnswer")
        if answer is not None:
            return CLARIFICATION_ANSWERED_NOTE_TEMPLATE.format(
                clarification_question=question or "",
                clarification_answer=json.dumps(answer, default=str),
            )
        return "none"

    # ─── Stage 2: monitor_execution (mid-workflow checkpoint) ────────────

    async def _monitor_execution(self, request: KernelRequest) -> KernelResponse:
        """Lightweight mid-workflow checkpoint — NOT final validation.

        This is a kernel-initiated side dispatch (see
        AIKernel._run_monitoring_checkpoint), not part of the normal
        engine-driven next_step chain. The kernel inserts this call at
        specific checkpoints (currently: right after Planning produces a
        plan) when the workflow's complexity warrants it, or when the
        kernel's own cheap deterministic checks already flagged a concern.

        The kernel inspects `result["monitorVerdict"]["decision"]` directly
        to decide whether to continue with the pending step or force a full
        `supervisor.validate_result` pass — this response's `next_step` is
        intentionally left unset.
        """
        payload = request.payload
        strategy = payload.get("strategy", {})
        goal = strategy.get("goal", "")
        intent = strategy.get("intent", "")
        complexity = strategy.get("complexity", "medium")

        checkpoint_capability = payload.get("checkpointCapability", "unknown")
        checkpoint_result = payload.get("checkpointResult", {})
        step_results = payload.get("stepResults", [])
        pending_next_step = payload.get("pendingNextStep", {})
        kernel_concerns = payload.get("kernelConcerns", [])

        user_prompt = MONITOR_EXECUTION_USER_PROMPT_TEMPLATE.format(
            goal=goal,
            intent=intent,
            complexity=complexity,
            checkpoint_capability=checkpoint_capability,
            checkpoint_result=json.dumps(checkpoint_result, default=str),
            step_results=json.dumps(step_results, default=str),
            pending_next_step=json.dumps(pending_next_step, default=str),
            kernel_concerns=json.dumps(kernel_concerns) if kernel_concerns else "none",
        )
        llm_response = await self._complete_json(MONITOR_EXECUTION_SYSTEM_PROMPT, user_prompt)
        verdict = MonitorVerdict.model_validate(self._parse_json(llm_response.content))

        monitor_result = verdict.model_dump(by_alias=True)
        system_input = (
            f"[System] Monitoring checkpoint after '{checkpoint_capability}': "
            f"reviewing pending next step '{pending_next_step.get('capability', 'unknown')}'. "
            f"Input reviewed: {json.dumps(checkpoint_result, default=str)}"
        )

        # Store the FULL verdict (decision + feedback + concerns), not just
        # the feedback string, so memory retains everything this checkpoint
        # actually concluded.
        return self._success(
            request,
            {
                "monitorVerdict": monitor_result,
                "modelUsage": self._model_usage_entry(llm_response),
                "conversationTurn": {
                    "system": system_input,
                    "ai": json.dumps(monitor_result, default=str),
                },
            },
        )

    # ─── Stage 3: validate_result ────────────────────────────────────────

    # Safety cap on how many times validate_result may send the workflow
    # back to Planning for revision before giving up and forcing an error
    # outcome. Separate from AIKernel.MAX_ITERATIONS, which bounds the
    # overall dynamic loop regardless of cause.
    MAX_REVISION_ATTEMPTS = 3

    async def _validate_result(self, request: KernelRequest) -> KernelResponse:
        payload = request.payload
        execution_context = payload.get("executionContext", {}) or {}
        strategy = execution_context.get("strategy") or payload.get("strategy", {})

        goal = payload.get("goal") or strategy.get("goal", "")
        intent = payload.get("intent") or strategy.get("intent", "")
        merged_result = payload.get("mergedResult", "")
        if not merged_result:
            previous_result = payload.get("previousResult") or {}
            merged_result = previous_result.get("mergedResult", "")

        step_results = execution_context.get("stepResults") or payload.get("stepResults", [])
        error_details = payload.get("errorDetails")
        revision_count = execution_context.get("revisionCount", 0)
        memory_context = payload.get("memoryContext", [])

        user_prompt = VALIDATE_RESULT_USER_PROMPT_TEMPLATE.format(
            conversation_history=self._format_conversation_history(memory_context),
            goal=goal,
            intent=intent,
            step_results=json.dumps(step_results, default=str),
            merged_result=merged_result,
            error_details=json.dumps(error_details, default=str) if error_details else "none",
        )
        llm_response = await self._complete_json(VALIDATE_RESULT_SYSTEM_PROMPT, user_prompt)
        verdict = ValidationVerdict.model_validate(self._parse_json(llm_response.content))
        model_usage = self._model_usage_entry(llm_response)

        # What the kernel/previous engine actually handed to this stage —
        # never the raw user query — recorded in memory as a "system" turn,
        # not a "human" one. See _build_validation_input_summary.
        system_input = self._build_validation_input_summary(step_results, merged_result, error_details)

        # Guard: if we've already looped back to Planning too many times,
        # force an error outcome instead of allowing an infinite
        # validate_result <-> planning cycle.
        if verdict.outcome == ValidationOutcome.NEEDS_MORE_PLANNING and revision_count >= self.MAX_REVISION_ATTEMPTS:
            validation_result = verdict.model_dump(by_alias=True)
            capped_response = (
                "I wasn't able to fully complete this request after "
                f"{revision_count} revision attempts. Last assessment: "
                f"{verdict.revision_brief or verdict.feedback}"
            )
            return self._success(
                request,
                {
                    "validation": validation_result,
                    "finalResponse": capped_response,
                    "modelUsage": model_usage,
                    # Store the FULL validation verdict, not just the
                    # derived capped_response text, so memory retains the
                    # complete outcome/score/feedback/branch fields.
                    "conversationTurn": {
                        "system": system_input,
                        "ai": json.dumps(validation_result, default=str),
                    },
                },
            )

        if verdict.outcome == ValidationOutcome.NEEDS_MORE_PLANNING:
            response = self._success(
                request, {"validation": verdict.model_dump(by_alias=True), "modelUsage": model_usage}
            )
            # Not a failure, not a user prompt — route back to Planning with
            # a revision brief describing what's still missing.
            response.next_step = NextStep(
                capability="planning.create_plan",
                payload={
                    "userQuery": payload.get("userQuery", ""),
                    "strategy": strategy,
                    "revisionBrief": verdict.revision_brief,
                    "previousStepResults": step_results,
                },
                # Signals the kernel to increment context.revision_count —
                # see ResponseCorrelator / AIKernel._resolve_next_step.
                metadata={"isRevisionLoop": True},
            )
            return response

        # completed / error / needs_approval are all terminal — exactly one
        # of these produced the user-facing text; finalResponse is picked
        # up automatically by the kernel's ResponseCorrelator.
        if verdict.outcome == ValidationOutcome.COMPLETED:
            final_text = verdict.final_response or merged_result
        elif verdict.outcome == ValidationOutcome.ERROR:
            final_text = verdict.error_message
        else:  # NEEDS_APPROVAL
            final_text = verdict.approval_request

        validation_result = verdict.model_dump(by_alias=True)
        return self._success(
            request,
            {
                "validation": validation_result,
                "finalResponse": final_text,
                "modelUsage": model_usage,
                # Store the FULL validation verdict, not just the derived
                # final_text, so memory retains the complete outcome/score/
                # feedback/branch fields rather than a partial view.
                "conversationTurn": {
                    "system": system_input,
                    "ai": json.dumps(validation_result, default=str),
                },
            },
        )

    # ─── Helpers ──────────────────────────────────────────────────────────

    async def _complete_json(self, system: str, user: str) -> LLMResponse:
        """Call the ILLMClient for a system/user prompt pair, JSON mode.

        Returns the full LLMResponse (not just `.content`) so callers can
        both parse the JSON text AND attach usage/latency/cost to their
        result payload via `_model_usage_entry` — see call sites below.
        """
        return await self._llm.generate(
            LLMRequest.from_system_user(system, user).model_copy(update={"response_format": "json"})
        )

    def _model_usage_entry(self, llm_response: LLMResponse) -> dict[str, Any]:
        """Build the `modelUsage` block ResponseCorrelator turns into a ModelLog entry.

        See kernel/requests/request_correlator.py's
        _update_context_from_result, which looks for this exact key in a
        capability's result to populate ExecutionContext.model_logs.
        """
        return {
            "provider": llm_response.metadata.get("provider", "unknown"),
            "modelName": llm_response.metadata.get("model", "unknown"),
            "promptTokens": llm_response.usage.prompt_tokens,
            "completionTokens": llm_response.usage.completion_tokens,
            "totalTokens": llm_response.usage.total_tokens,
            "latency": llm_response.latency_ms,
            "cost": llm_response.cost,
            "finishReason": llm_response.finish_reason,
        }

    @staticmethod
    def _build_validation_input_summary(
        step_results: list,
        merged_result: str,
        error_details: dict | None,
    ) -> str:
        """Describe what validate_result was actually asked to check.

        This is NOT the user's query — validate_result never receives raw
        human input, only kernel/engine-constructed context (step results,
        a merged result, or error details). Used as the "system" side of
        the conversationTurn recorded to memory, so history correctly shows
        this stage was triggered by the system, not the user.
        """
        if error_details:
            return f"[System] Workflow failure to review: {json.dumps(error_details, default=str)}"
        if merged_result:
            return f"[System] Merged result to validate: {merged_result}"
        if step_results:
            return f"[System] Step results to validate: {json.dumps(step_results, default=str)}"
        return "[System] Validation requested with no prior results."

    @staticmethod
    def _format_conversation_history(memory_context: list[dict[str, str]]) -> str:
        """Render stored memory turns as plain text for inclusion in a prompt.

        Returns "none" if there's no history, matching the prompt templates'
        expectation of a plain "none" string for a fresh conversation.
        """
        if not memory_context:
            return "none"
        lines = [f"{turn.get('role', 'unknown')}: {turn.get('content', '')}" for turn in memory_context]
        return "\n".join(lines)

    @staticmethod
    def _parse_json(raw: str) -> dict[str, Any]:
        """Parse an LLM's raw text output as JSON.

        Tolerates responses wrapped in markdown code fences (```json ... ```),
        which many LLMs produce even when asked for strict JSON.
        """
        text = raw.strip()
        fence_match = _JSON_FENCE_RE.search(text)
        if fence_match:
            text = fence_match.group(1).strip()
        try:
            return json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(f"LLM response was not valid JSON: {raw!r}") from exc
