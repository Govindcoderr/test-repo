"""Supervisor engine package.

The Supervisor is the entry point of the dynamic execution loop
(see AIKernel._resolve_initial_step). It is responsible for:

1. supervisor.understand_goal   — understand the goal, estimate complexity,
                                   analyze intent, then hand off to Planning.
2. supervisor.monitor_execution — monitor engine execution and merge results.
3. supervisor.validate_result   — validate the merged result against the
                                   original goal before finishing.

See supervisor_engine.py for the concrete implementation.
"""

from ai_os.app.infrastructure.engines.Supervisor.supervisor_engine import SupervisorEngine

__all__ = ["SupervisorEngine"]
