"""Internal data shapes used by the Supervisor engine.

These are Supervisor-local structures (not part of the shared kernel
domain models) used to validate/normalize the LLM's structured output
at each stage of the supervisor.* capability chain.
"""

from enum import Enum

from pydantic import BaseModel, Field


class GoalAnalysis(BaseModel):
    """Output of the understand_goal stage.

    Deliberately scoped to analysis only — task breakdown and workflow
    construction are the Planning engine's responsibility downstream. This
    is intentionally comprehensive (not just goal/intent/complexity) so
    Planning receives a rich, structured brief instead of having to
    re-derive context from the raw query itself.
    """

    goal: str
    intent: str
    complexity: str = "medium"  # "low" | "medium" | "high"
    complexity_reasoning: str = Field(default="", alias="complexityReasoning")

    # Concrete entities/parameters mentioned in the query that Planning will
    # likely need (dates, names, document references, systems, etc.).
    key_entities: list[str] = Field(default_factory=list, alias="keyEntities")

    # Explicit constraints or requirements the user stated (deadlines,
    # format requirements, exclusions, tone, scope limits, etc.).
    constraints: list[str] = Field(default_factory=list, alias="constraints")

    # What a successful outcome looks like — used by Planning to know when
    # a plan actually satisfies the goal, and later by validate_result.
    success_criteria: str = Field(default="", alias="successCriteria")

    # Things that are ambiguous or underspecified in the query. Non-blocking
    # — Planning may still proceed, but should account for these, and
    # validate_result may later decide these warrant needs_approval.
    ambiguities: list[str] = Field(default_factory=list, alias="ambiguities")

    # Advisory, non-binding hints at capability categories this goal will
    # likely require (e.g. "tool.email", "knowledge.retrieve"). Planning
    # owns the actual task breakdown — these are suggestions, not a plan.
    suggested_capabilities: list[str] = Field(default_factory=list, alias="suggestedCapabilities")

    # Risk level of carrying out this goal (e.g. irreversible actions,
    # sensitive data, external side effects like sending an email).
    risk_level: str = Field(default="low", alias="riskLevel")  # "low" | "medium" | "high"
    risk_reasoning: str = Field(default="", alias="riskReasoning")

    # Which of the three ways Supervisor should handle this goal — see
    # SupervisorEngine._understand_goal for the deterministic risk override
    # that applies on top of whatever the LLM picks here:
    #   - "requires_planning": the normal case — hand off to Planning for
    #     task breakdown. Always forced regardless of the LLM's pick when
    #     risk_level is "medium"/"high".
    #   - "direct_response": trivial, safe, unambiguous — Supervisor
    #     answers directly (see direct_response) without involving Planning
    #     at all, though the answer still passes through
    #     supervisor.validate_result like any other workflow output.
    #   - "needs_clarification": safe but underspecified in a way that
    #     would change the answer — raises a human-in-the-loop question
    #     (see clarification_question) via the existing humanInputRequired
    #     mechanism rather than guessing or planning against ambiguity.
    execution_path: str = Field(default="requires_planning", alias="executionPath")

    # Populated only when execution_path == "direct_response" — the actual,
    # complete answer to give the user, handed to supervisor.validate_result
    # as mergedResult rather than being returned to the user directly.
    direct_response: str = Field(default="", alias="directResponse")

    # Populated only when execution_path == "needs_clarification" — the
    # exact question to ask the user before Supervisor can proceed.
    clarification_question: str = Field(default="", alias="clarificationQuestion")

    model_config = {"populate_by_name": True}


class ValidationOutcome(str, Enum):
    """The four possible outcomes of the validate_result stage.

    - COMPLETED: the result satisfies the goal — finalize and return to user.
    - NEEDS_MORE_PLANNING: something is missing/incomplete — route back to
      Planning with a revision brief instead of failing or asking the user.
    - ERROR: an unrecoverable error occurred somewhere in the chain —
      explain it and return to the user (terminal).
    - NEEDS_APPROVAL: execution requires explicit user approval/input before
      it can proceed or complete — ask the user (terminal from the kernel's
      perspective; the user's next message would start a new execution).
    """

    COMPLETED = "completed"
    NEEDS_MORE_PLANNING = "needs_more_planning"
    ERROR = "error"
    NEEDS_APPROVAL = "needs_approval"


class ValidationVerdict(BaseModel):
    """Output of the validate_result stage.

    Exactly one branch's fields are expected to be meaningfully populated,
    depending on `outcome` — see prompts.py for the full branch contract.
    """

    outcome: ValidationOutcome
    score: float = Field(default=0.0, ge=0.0, le=1.0)
    feedback: str = ""

    # COMPLETED: the text to return to the user.
    final_response: str = Field(default="", alias="finalResponse")

    # NEEDS_MORE_PLANNING: what Planning should address in a revised plan.
    revision_brief: str = Field(default="", alias="revisionBrief")

    # ERROR: user-facing explanation of what went wrong.
    error_message: str = Field(default="", alias="errorMessage")

    # NEEDS_APPROVAL: the question/approval request to show the user.
    approval_request: str = Field(default="", alias="approvalRequest")

    model_config = {"populate_by_name": True}


class MonitorDecision(str, Enum):
    """The two possible outcomes of a mid-workflow monitoring checkpoint.

    - CONTINUE: nothing concerning — resume the pending action as planned.
    - ESCALATE: something is concerning enough to stop and route through
      the full supervisor.validate_result gate instead of continuing.
    """

    CONTINUE = "continue"
    ESCALATE = "escalate"


class MonitorVerdict(BaseModel):
    """Output of the monitor_execution stage.

    This is a lightweight, cheap check — the kernel only invokes it at
    specific checkpoints (see AIKernel.MONITOR_CHECKPOINT_CAPABILITIES) and
    only when the workflow's own complexity rating warrants it (see
    AIKernel._should_checkpoint). It is not a full re-validation; most
    checkpoints are expected to resolve to "continue".
    """

    decision: MonitorDecision
    feedback: str = ""
    concerns: list[str] = Field(default_factory=list)

    model_config = {"populate_by_name": True}
