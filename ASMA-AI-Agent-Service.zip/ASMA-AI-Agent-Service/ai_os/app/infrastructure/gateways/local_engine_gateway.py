from ai_os.app.domain.interfaces.engine import Engine
from ai_os.app.domain.interfaces.gateway import EngineGateway
from ai_os.app.domain.models.kernel_request import KernelRequest
from ai_os.app.domain.models.kernel_response import KernelResponse
from ai_os.app.kernel.errors.kernel_errors import ErrorType, KernelError, KernelException


class LocalEngineGateway(EngineGateway):
    def __init__(self) -> None:
        self._engines: dict[str, Engine] = {}

    def register_engine(self, engine_id: str, engine: object) -> None:
        if not isinstance(engine, Engine):
            raise TypeError("Engine must implement Engine interface")
        self._engines[engine_id] = engine

    async def send(self, engine_id: str, request: KernelRequest) -> KernelResponse:
        engine = self._engines.get(engine_id)
        if not engine:
            raise KernelException(
                KernelError(
                    code="ENGINE_NOT_FOUND",
                    message=f"Engine '{engine_id}' not found in gateway",
                    type=ErrorType.ENGINE_ERROR,
                    request_id=request.request_id,
                    execution_id=request.execution_id,
                )
            )
        return await engine.execute(request)

    async def health_check(self, engine_id: str) -> bool:
        engine = self._engines.get(engine_id)
        if not engine:
            return False
        return await engine.health_check()
