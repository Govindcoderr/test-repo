from ai_os.app.domain.interfaces.repository import EventRepository, ExecutionRepository, RequestRepository
from ai_os.app.domain.models.events import KernelEvent
from ai_os.app.domain.models.execution import ExecutionContext
from ai_os.app.domain.models.kernel_request import KernelRequest


class InMemoryExecutionRepository(ExecutionRepository):
    def __init__(self) -> None:
        self._store: dict[str, ExecutionContext] = {}

    async def save_context(self, context: ExecutionContext) -> None:
        self._store[context.execution_id] = context

    async def get_context(self, execution_id: str) -> ExecutionContext | None:
        return self._store.get(execution_id)

    async def delete_context(self, execution_id: str) -> None:
        self._store.pop(execution_id, None)


class InMemoryRequestRepository(RequestRepository):
    def __init__(self) -> None:
        self._store: dict[str, KernelRequest] = {}
        self._by_execution: dict[str, list[str]] = {}

    async def save_request(self, request: KernelRequest) -> None:
        self._store[request.request_id] = request
        self._by_execution.setdefault(request.execution_id, []).append(request.request_id)

    async def get_request(self, request_id: str) -> KernelRequest | None:
        return self._store.get(request_id)

    async def list_by_execution(self, execution_id: str) -> list[KernelRequest]:
        ids = self._by_execution.get(execution_id, [])
        return [self._store[rid] for rid in ids if rid in self._store]


class InMemoryEventRepository(EventRepository):
    def __init__(self) -> None:
        self._events: list[KernelEvent] = []

    async def save_event(self, event: KernelEvent) -> None:
        self._events.append(event)

    async def list_by_execution(self, execution_id: str) -> list[KernelEvent]:
        return [e for e in self._events if e.execution_id == execution_id]
