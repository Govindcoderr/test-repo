import logging
from typing import Any

from ai_os.app.domain.interfaces.observability import ObservabilityService
from ai_os.app.domain.models.events import KernelEventType

logger = logging.getLogger("ai_os.kernel")


class ConsoleObserver(ObservabilityService):
    async def emit(
        self,
        event_type: KernelEventType,
        execution_id: str | None = None,
        request_id: str | None = None,
        payload: dict[str, Any] | None = None,
    ) -> None:
        await self.log_structured(
            component="AIKernel",
            event=event_type.value,
            status="INFO",
            execution_id=execution_id,
            request_id=request_id,
            extra=payload,
        )

    async def log_structured(
        self,
        component: str,
        event: str,
        status: str,
        execution_id: str | None = None,
        request_id: str | None = None,
        correlation_id: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        log_data = {
            "component": component,
            "event": event,
            "status": status,
            "executionId": execution_id,
            "requestId": request_id,
            "correlationId": correlation_id,
        }
        if extra:
            log_data.update(extra)
        logger.info(log_data)
