"""Fallback memory storage.

This package holds the development-phase, JSON-file-backed memory store
(json_memory_store.py) used until a real Memory engine exists. The kernel
calls this store directly (not through the capability/engine dispatch
system) whenever a memory-required capability is about to run — see
AIKernel.MEMORY_REQUIRED_PREFIXES in kernel.py.

Once a real Memory engine is built (infrastructure/engines/Memory/), this
module should be removed and replaced with a "memory.retrieve" /
"memory.update" capability dispatch instead — the call sites in kernel.py
are intentionally isolated to make that swap contained.
"""

from ai_os.app.infrastructure.memory.json_memory_store import JsonMemoryStore

__all__ = ["JsonMemoryStore"]
