"""JSON-file-backed fallback memory store.

Temporary stand-in for a real Memory engine (infrastructure/engines/Memory/
is still empty). Stores conversation turns per memory space, partitioned by
agent key (e.g. "supervisor", "planning", "workers"), in a single JSON file:

{
  "<memoryId>": {
    "supervisor": [ {"role": "human", "content": "..."}, {"role": "ai", "content": "..."} ],
    "planning": [...],
    "workers": { "<workerName>": [...] }
  }
}

Each stored turn has a `role` of "human", "system", or "ai":
- "human": the literal user query, only recorded for capabilities that
  receive it as-is (supervisor.understand_goal, planning.create_plan).
- "system": the kernel- or engine-constructed input that triggered a call
  that was NOT a direct human utterance (e.g. supervisor.validate_result
  being invoked with an error summary or merged result to check).
- "ai": the engine's output for that turn.

This is called directly by the kernel (see AIKernel.MEMORY_REQUIRED_PREFIXES
and _maybe_load_memory / _maybe_save_memory in kernel.py) rather than being
dispatched as a capability through an engine — there is no MemoryEngine yet.
When one exists, this class's responsibilities move there and this module
should be deleted.

Concurrency: this is a single JSON file shared across requests within one
process. An asyncio.Lock serializes read-modify-write cycles so concurrent
requests don't clobber each other. This does NOT protect against multiple
OS processes writing the same file — fine for the current single-process
development setup, not a production-grade guarantee.
"""

import asyncio
import json
import uuid
from pathlib import Path
from typing import Any

Turn = dict[str, str]  # {"role": "human" | "ai", "content": "..."}


class JsonMemoryStore:
    """Reads and writes conversation turns to a local JSON file."""

    def __init__(self, file_path: str | Path) -> None:
        self._path = Path(file_path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = asyncio.Lock()

    # ─── Public API ─────────────────────────────────────────────────────

    async def get_or_create_memory_id(self, memory_id: str | None) -> str:
        """Return `memory_id` if it already has a memory space, else mint a new one.

        A brand-new memory_id (whether passed in but unknown, or None) gets
        an empty memory space created for it so later reads/writes succeed.
        """
        async with self._lock:
            data = self._read()
            if memory_id and memory_id in data:
                return memory_id

            new_id = memory_id or f"MEM-{uuid.uuid4().hex[:12].upper()}"
            data.setdefault(new_id, {})
            self._write(data)
            return new_id

    async def get_context(self, memory_id: str, agent_key: str) -> list[Turn]:
        """Return the stored turns for `agent_key` within `memory_id`'s space.

        Returns an empty list if the memory space or agent key doesn't
        exist yet (e.g. first time this agent runs in this conversation).
        """
        async with self._lock:
            data = self._read()
            space = data.get(memory_id, {})
            return list(space.get(agent_key, []))

    async def append_turn(
        self,
        memory_id: str,
        agent_key: str,
        input_content: str | None,
        ai: str | None,
        input_role: str = "human",
    ) -> None:
        """Append an input/ai turn pair to `agent_key`'s history within `memory_id`.

        `input_role` distinguishes a literal user utterance ("human") from
        kernel/engine-constructed input that triggered this call but was
        never something the user typed ("system") — e.g. the error summary
        or merged result handed to supervisor.validate_result. Either side
        may be omitted — only non-empty turns are recorded.
        """
        if not input_content and not ai:
            return

        async with self._lock:
            data = self._read()
            space = data.setdefault(memory_id, {})
            turns: list[Turn] = space.setdefault(agent_key, [])

            if input_content:
                turns.append({"role": input_role, "content": input_content})
            if ai:
                turns.append({"role": "ai", "content": ai})

            self._write(data)

    # ─── File I/O ───────────────────────────────────────────────────────

    def _read(self) -> dict[str, Any]:
        if not self._path.exists():
            return {}
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                content = f.read().strip()
                return json.loads(content) if content else {}
        except (json.JSONDecodeError, OSError):
            # Corrupt or unreadable file — treat as empty rather than crash
            # the kernel over a dev-phase fallback store.
            return {}

    def _write(self, data: dict[str, Any]) -> None:
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
