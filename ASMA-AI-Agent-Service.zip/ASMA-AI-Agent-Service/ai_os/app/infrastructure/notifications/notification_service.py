"""Outbound notification for human-in-the-loop approval/input requests.

The kernel calls this the moment it suspends an execution waiting on a
human — see AIKernel._await_human_input. The backend, per the project's
architecture, runs as a SEPARATE HTTP service; this is the "kernel calls
out to the backend" hop, which then pushes the question into the user's
chat however that service does so. This module never talks to a frontend
directly — only to the backend.
"""

import logging
from abc import ABC, abstractmethod
from typing import Any

import httpx

logger = logging.getLogger("ai_os.kernel.notifications")


class NotificationService(ABC):
    """Minimal interface AIKernel depends on to raise a human-input request."""

    @abstractmethod
    async def notify_human_input_required(
        self,
        execution_id: str,
        request_id: str,
        task_id: str | None,
        question: str,
    ) -> None:
        """Notify the backend that a human's input/approval is needed.

        Implementations should not raise on delivery failure — a failed
        notification should not crash the kernel's suspension; it should
        be logged and swallowed, since the human-in-the-loop timeout will
        still eventually let the execution continue on its own even if
        the human never sees the question.
        """
        raise NotImplementedError


class LoggingNotificationService(NotificationService):
    """Dev-phase fallback — logs the request instead of calling a real backend.

    Used when no webhook URL is configured (see Settings.human_input_webhook_url),
    so the kernel is fully runnable without a real backend service present.
    """

    async def notify_human_input_required(
        self,
        execution_id: str,
        request_id: str,
        task_id: str | None,
        question: str,
    ) -> None:
        logger.info(
            "HUMAN_INPUT_REQUIRED (no webhook configured — logging only): "
            "executionId=%s requestId=%s taskId=%s question=%r",
            execution_id,
            request_id,
            task_id,
            question,
        )


class WebhookNotificationService(NotificationService):
    """Posts the human-input request to the backend's webhook URL.

    The backend (a separate HTTP service, per the project's architecture)
    is expected to relay this into the user's chat and, once the human
    responds, call back into this kernel's POST /api/v1/kernel/human-input/
    {requestId} route with the answer.
    """

    def __init__(self, webhook_url: str, timeout_seconds: float = 10.0) -> None:
        if not webhook_url:
            raise ValueError("WebhookNotificationService requires a non-empty webhook_url")
        self._webhook_url = webhook_url
        self._timeout_seconds = timeout_seconds

    async def notify_human_input_required(
        self,
        execution_id: str,
        request_id: str,
        task_id: str | None,
        question: str,
    ) -> None:
        payload: dict[str, Any] = {
            "executionId": execution_id,
            "requestId": request_id,
            "taskId": task_id,
            "question": question,
        }
        try:
            async with httpx.AsyncClient(timeout=self._timeout_seconds) as client:
                response = await client.post(self._webhook_url, json=payload)
                response.raise_for_status()
        except httpx.HTTPError as exc:
            # Deliberately swallowed — see NotificationService docstring.
            # The human-input timeout still applies even if the human
            # never actually sees the question because delivery failed.
            logger.warning(
                "Failed to deliver human-input notification for requestId=%s: %s",
                request_id,
                exc,
            )
