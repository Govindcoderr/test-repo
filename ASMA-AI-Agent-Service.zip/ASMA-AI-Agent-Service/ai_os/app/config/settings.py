from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict

from ai_os.app.domain.models.model_configuration import ModelConfiguration


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "AI OS Kernel"
    app_version: str = "0.2.0"
    debug: bool = False

    # Request handling
    default_request_timeout_seconds: int = 30
    default_max_retries: int = 2
    default_retry_delay_seconds: float = 0.5
    retry_backoff_multiplier: float = 2.0

    # Logging
    log_level: str = "INFO"
    mask_sensitive_logs: bool = True

    # Supervisor and Planning are NOT backend-configurable — per the
    # project's design, only Agent Runtime workers receive their
    # ModelConfiguration from the backend (agentDefinition/subAgents).
    # Supervisor and Planning each get a fixed ModelConfiguration built
    # from these env vars and resolved into an ILLMClient once at startup
    # by the Model engine (see main.py and
    # infrastructure/engines/Model/model_engine.py).
    supervisor_model_provider: str = "openai"
    supervisor_model_name: str = "gpt-4.1"
    supervisor_model_api_key: str = ""
    supervisor_model_base_url: str = "https://api.openai.com/v1"
    supervisor_model_temperature: float = 0.2
    supervisor_model_max_tokens: int = 4096

    planning_model_provider: str = "openai"
    planning_model_name: str = "gpt-4.1"
    planning_model_api_key: str = ""
    planning_model_base_url: str = "https://api.openai.com/v1"
    planning_model_temperature: float = 0.2
    planning_model_max_tokens: int = 4096

    # Default endpoint for self-hosted/in-house models — used only when a
    # ModelConfiguration has isInternal=true AND doesn't set its own
    # baseUrl. Per-request baseUrl always takes priority, so different
    # workers/sub-agents can point at different internal servers without
    # touching this default. See
    # infrastructure/engines/Model/providers/internal_provider.py.
    internal_model_base_url: str = ""
    internal_model_timeout_seconds: float = 30.0

    # Optional path to a JSON file overriding per-model pricing (USD per
    # million tokens) used to compute LLMResponse.cost. Re-read from disk
    # on every cost calculation, so editing this file takes effect
    # immediately, no restart needed. Empty string (default) means "use
    # only the hardcoded defaults" — see
    # infrastructure/engines/Model/pricing.py and
    # pricing_overrides.example.json for the expected shape.
    model_pricing_overrides_path: str = ""

    # Fallback memory store (JSON file) — development-phase stand-in for a
    # real Memory engine. See infrastructure/memory/json_memory_store.py.
    memory_store_path: str = "ai_os/data/memory.json"

    # Human-in-the-loop: how long the kernel waits (in-process, suspended,
    # not polling) for a human's response before giving up and continuing
    # without approval. See kernel/human_input/pending_input_registry.py.
    human_input_timeout_seconds: int = 300

    # Webhook URL the kernel POSTs to when a human input/approval request is
    # raised, so the separate backend service can push it into the chat
    # for the user. Empty string means no webhook is configured — the
    # notifier falls back to logging only (dev-phase behavior).
    human_input_webhook_url: str = ""
    human_input_webhook_timeout_seconds: float = 10.0

    def supervisor_model_configuration(self) -> ModelConfiguration:
        """Fixed ModelConfiguration Supervisor uses for its whole lifetime.

        Built once, at startup, from env vars — Supervisor never receives
        a ModelConfiguration from the backend/kernel. See main.py.
        """
        return ModelConfiguration(
            provider=self.supervisor_model_provider,
            modelName=self.supervisor_model_name,
            apiKey=self.supervisor_model_api_key,
            baseUrl=self.supervisor_model_base_url,
            temperature=self.supervisor_model_temperature,
            maxTokens=self.supervisor_model_max_tokens,
        )

    def planning_model_configuration(self) -> ModelConfiguration:
        """Fixed ModelConfiguration Planning uses for its whole lifetime. See main.py."""
        return ModelConfiguration(
            provider=self.planning_model_provider,
            modelName=self.planning_model_name,
            apiKey=self.planning_model_api_key,
            baseUrl=self.planning_model_base_url,
            temperature=self.planning_model_temperature,
            maxTokens=self.planning_model_max_tokens,
        )


@lru_cache
def get_settings() -> Settings:
    return Settings()
