# AI OS Kernel Service

The **AI Kernel** is the operating-system layer of the Enterprise Agentic AI Platform. It sits between the backend and all engines (Supervisor, Planning, Agent Runtime, Model, Knowledge, Memory, Tool), routing every request and response through a single hub.

```text
Backend  →  AI KERNEL  →  Engine  →  AI KERNEL  →  Backend
```

Engines never communicate directly with each other.

---

## Documentation

**Full platform guide (share with your team):**

📄 **[docs/AI_KERNEL_PLATFORM.md](docs/AI_KERNEL_PLATFORM.md)**

Covers:

- Architecture and kernel responsibilities
- **ExecutionRequest** input contract (backend → kernel)
- **ExecutionResponse** output contract (kernel → backend)
- End-to-end execution flow and RFQ example
- Engine registration and future roadmap
- API endpoints, validation, and testing

---

## Quick Start

```powershell
pip install -r requirements.txt
$env:PYTHONPATH="."
uvicorn ai_os.app.main:app --reload
```

- API docs: http://localhost:8000/docs
- Health: http://localhost:8000/api/v1/kernel/health

### Execute

```powershell
curl -X POST http://localhost:8000/api/v1/kernel/execute `
  -H "Content-Type: application/json" `
  -d "@examples/demo_request.json"
```

### Validate

```powershell
.\venv\Scripts\python.exe -m pytest tests/ -v
.\venv\Scripts\python.exe scripts\trace_demo.py
```

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/v1/kernel/execute` | Full execution |
| `POST` | `/api/v1/kernel/dispatch` | Single engine call via kernel |
| `GET` | `/api/v1/kernel/registry` | Capabilities & resources |
| `GET` | `/api/v1/kernel/health` | Health check |

---

## Examples

| File | Description |
|------|-------------|
| `examples/demo_request.json` | Full ExecutionRequest with agent |
| `examples/rfq_kernel_os_flow.json` | RFQ scenario (kernel-only, `enableAgent: false`) |

---

## Project Layout

```text
ai_os/app/
├── api/              # FastAPI routes
├── kernel/           # OS layer (routing, orchestration, policy)
├── domain/           # Request/response models, interfaces
├── infrastructure/   # Mock engines, repos, gateway
└── config/
docs/
└── AI_KERNEL_PLATFORM.md   # Team architecture document
```

---

## Adding Engines

Register engines by capability — no kernel core changes required. See [docs/AI_KERNEL_PLATFORM.md §7](docs/AI_KERNEL_PLATFORM.md#7-how-engine-registration-works).
